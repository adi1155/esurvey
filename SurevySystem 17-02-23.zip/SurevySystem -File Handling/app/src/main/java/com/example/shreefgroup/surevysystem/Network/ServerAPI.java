package com.example.shreefgroup.surevysystem.Network;




import com.example.shreefgroup.surevysystem.Model.CheckSurvey;
import com.example.shreefgroup.surevysystem.Model.CircleModel.CricleResponse;
import com.example.shreefgroup.surevysystem.Model.Grower.GrowerModel;
import com.example.shreefgroup.surevysystem.Model.MobileModel.MobileResponse;
import com.example.shreefgroup.surevysystem.Model.ResponseModel.ResultResponse;
import com.example.shreefgroup.surevysystem.Model.SurveyResult;
import com.example.shreefgroup.surevysystem.Model.Sync.SyncModel;
import com.example.shreefgroup.surevysystem.Model.UnitModel.UnitResponse;
import com.example.shreefgroup.surevysystem.Model.UserModel.UserResponse;
import com.example.shreefgroup.surevysystem.Utils.AppController;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;

/**
 * Created by mRashid on 21/09/2020.
 */

public interface ServerAPI {


    

    @Multipart
    @POST(UrlUtils.uploadImage)
    Call<UserInfo> upload_Arrival_data
            (@Part MultipartBody.Part fil);






  @FormUrlEncoded
    @POST(UrlUtils.check_survey)
    Call<CheckSurvey>  check_survey(
            @Field("LAT") String lat,
            @Field("LNG") String lng
    );
 @FormUrlEncoded
    @POST(UrlUtils.check_survey)
    Call<CheckSurvey>  check_survey1(
            @Field("LAT") String lat,
            @Field("LNG") String lng,
            @Field("SURVEY_TYPE") String type
    );

  @FormUrlEncoded
    @POST(UrlUtils.GET_UNIT_LIST)
    Call<UnitResponse>  get_unit(
            @Field("APP_ID") String app_id
    );


    @FormUrlEncoded
    @POST(UrlUtils.GET_USER_LIST)
    Call<UserResponse>  get_user(
            @Field("APP_ID") String app_id,
            @Field("UNIT_ID") String unit_id
    );


 @FormUrlEncoded
    @POST(UrlUtils.GET_CIRCLE_LIST)
    Call<CricleResponse>  get_circle(
            @Field("APP_ID") String app_id,
            @Field("UNIT_ID") String unit_id
    );


@FormUrlEncoded
    @POST(UrlUtils.GET_SYCN_DATA)
    Call<SyncModel>  sync_data(
/*

        :17
        :6
        :9
        :10
        PLANTATION:7
        SURVEY_TYPE:8
*/

        @Field("UNIT_ID") String unitId,
            @Field("LOOKUP_ID") String lookUp,
            @Field("CROP_CONDITION") String cropCondition,
            @Field("CROP_VARITY") String verity,
            @Field("PLANTATION") String plantation,
            @Field("SURVEY_TYPE") String  surveyType
    );



    @FormUrlEncoded
    @POST(UrlUtils.GET_GROWER_INFO)
    Call<GrowerModel>  get_grower_info(
            @Field("UNIT_ID") String unitId
    );



 @FormUrlEncoded
    @POST(UrlUtils.GET_MOBILE_LIST)
    Call<MobileResponse>  get_mobile(
            @Field("UNIT_ID") String unit_id
    );



    @Multipart
    @POST(UrlUtils.ADD_GROWER_DATA)
    Call<ResultResponse> post_grower_data
            (@Part MultipartBody.Part fil,
             @Part("UNIT_CODE") RequestBody  UNIT_CODE,
             @Part("CIRCLE_CODE") RequestBody  CIRCLE_CODE,
             @Part("VILLAGE_CODE") RequestBody  VILLAGE_CODE,

             @Part("PASSBOOK_NO") RequestBody  PASSBOOK_CODE,
             @Part("GROWER_CODE") RequestBody  GROWER_CODE,
             @Part("GROWER_NAME") RequestBody  CIRCLE_NAME,

             @Part("GROWER_F_NAME") RequestBody  GROWER_FATHER_NAME,
             @Part("GROWER_CNIC") RequestBody  GROWER_CNIC,
             @Part("GROWER_CASTE") RequestBody  CIRCLE_CAST,

             @Part("GPS_LAT") RequestBody  GPS_LAT,
             @Part("GPS_LONG") RequestBody  GPS_LONG,
             @Part("FILENAME1") RequestBody  FILE1,

             @Part("SURVEIER_ID") RequestBody  SURVERY_ID,
             @Part("SURVERY_UUID") RequestBody  UUID


            );



    @FormUrlEncoded
    @POST(UrlUtils.ADD_CONFIG)
    Call<ResultResponse>  add_config(


            @Field("BASE_URL") String baseUrl,
            @Field("UNIT_ID") String unit_id,
            @Field("USER_ID") String user_id,
            @Field("DEVICE_ID") String deviceId,
            @Field("APP_ID") String appId,
            @Field("CIRCLE_ID") String circleId,
            @Field("UUID") String uuid
    );







    @FormUrlEncoded
    @POST(UrlUtils.check_imei)
    Call<CheckSurvey>  get_imei_number(

            @Field("IMEI_NO") String lat,
            @Field("mob_app_id") String lng,
            @Field("mob_app_version") String app_version
    );







}
