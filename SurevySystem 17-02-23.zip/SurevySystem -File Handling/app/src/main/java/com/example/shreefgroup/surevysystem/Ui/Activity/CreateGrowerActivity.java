package com.example.shreefgroup.surevysystem.Ui.Activity;

import static com.example.shreefgroup.surevysystem.Service.GpsUtils.checkGPSStatus;
import static com.example.shreefgroup.surevysystem.Service.ImageUtils.qrCode;
import static com.example.shreefgroup.surevysystem.Ui.Fragment.home.HomeFragment.LAT;
import static com.example.shreefgroup.surevysystem.Ui.Fragment.home.HomeFragment.LNG;
import static java.security.AccessController.getContext;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.shreefgroup.surevysystem.DataBase.DatabaseHelper;
import com.example.shreefgroup.surevysystem.InterFace.LocationManagerInterface;
import com.example.shreefgroup.surevysystem.Model.CircleModel.CircleResult;
import com.example.shreefgroup.surevysystem.Model.Grower.GrowerModel;
import com.example.shreefgroup.surevysystem.Model.Grower.GrowerResult;
import com.example.shreefgroup.surevysystem.Model.ResponseModel.ResultResponse;
import com.example.shreefgroup.surevysystem.Model.Sync.Village;
import com.example.shreefgroup.surevysystem.Network.ServerCallback;
import com.example.shreefgroup.surevysystem.Network.ServerError;
import com.example.shreefgroup.surevysystem.Network.ServerTask;
import com.example.shreefgroup.surevysystem.Network.UrlUtils;
import com.example.shreefgroup.surevysystem.R;
import com.example.shreefgroup.surevysystem.Service.ImageUtils;
import com.example.shreefgroup.surevysystem.Ui.Fragment.home.HomeFragment;
import com.example.shreefgroup.surevysystem.Utils.Constants;
import com.example.shreefgroup.surevysystem.Utils.NetworkUtil;
import com.google.android.gms.location.LocationRequest;


import com.isapanah.awesomespinner.AwesomeSpinner;
import com.preference.PowerPreference;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.StringTokenizer;

import de.hdodenhof.circleimageview.CircleImageView;
import io.kredibel.picker.Picker;
import io.kredibel.picker.PickerListener;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;

public class CreateGrowerActivity extends AppCompatActivity  {

    EditText  mName,mFather,mCnic,mPasbook,mCast,mCode;
    String mCurrentName="",mCurrentFName="",mCurrentCnic="",mCurrentPass="",mCurrentCast="",mCurrentCode="",
        mCurrentCircle="",mCurrentVillage="",mVillageCode="",mCircleCode="";

    File mGrowerFileImage = null;

    final static String grower_path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM) + "/E_survey" + "/New_grower/";


    public ProgressDialog mProgressDialog;

    Picker picker;
    String uuid ="00";


    Button mSubmit;

    AwesomeSpinner mCircleSpinner,mVillageSpinner;
    CircleImageView mGrowerImage;

    List<CircleResult> mCircleList = new ArrayList<>();
    List<Village> mVillageList = new ArrayList<>();
    DatabaseHelper databaseHelper ;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_grower);

        mName = findViewById(R.id.create_grower_name);
        mFather = findViewById(R.id.create_grower_father_name);
        mCnic = findViewById(R.id.create_grower_cnic);
        mCast = findViewById(R.id.create_grower_cast);
        mCode = findViewById(R.id.create_grower_code);
        mPasbook = findViewById(R.id.create_grower_passbook);
        mCircleSpinner = findViewById(R.id.create_grower_circle_spinner);
        mVillageSpinner = findViewById(R.id.create_grower_village_spinner);
        mSubmit = findViewById(R.id.create_grower_submit_btn);
        mGrowerImage = findViewById(R.id.create_grower_image_view);

        databaseHelper = new DatabaseHelper(getApplicationContext());
        picker = new Picker(CreateGrowerActivity.this);





        mCircleList = databaseHelper.get_circle_List();
        List<String> tempCircleList = new ArrayList<>();

        for(int i = 0 ; i< mCircleList.size();i++){
            String result = mCircleList.get(i).getDescription();
            tempCircleList.add(result);

        }


        ArrayAdapter<String> circleAdoper = new
                ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_spinner_item, tempCircleList);

        mCircleSpinner.setAdapter(circleAdoper);


        mCircleSpinner.setOnSpinnerItemClickListener((position, itemAtPosition) -> {

            try {
                mCurrentCircle = mCircleList.get(position).getDescription();
                String lookupCode = mCircleList.get(position).getLookupCode();

                try{
                    StringTokenizer stringTokenizer = new StringTokenizer(lookupCode,"-");
                    String hard = stringTokenizer.nextToken();
                    mCircleCode = stringTokenizer.nextToken();
                }catch (Exception e){e.printStackTrace();}
                if(!mCurrentCircle.equals("")){

                    mVillageList = databaseHelper.get_village_List(mCurrentCircle);

                    List<String> tempVillage = new ArrayList<>();

                    for(int i  = 0 ; i< mVillageList.size(); i++ ){
                        String  desc = mVillageList.get(i).getDescription();
                        tempVillage.add(desc);

                    }
                    ArrayAdapter<String> villageAdoper = new
                            ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_spinner_item, tempVillage);
                    mVillageSpinner.setAdapter(villageAdoper);


                }
            }catch (Exception e){e.printStackTrace();}

        });




        mVillageSpinner.setOnSpinnerItemClickListener((position, itemAtPosition) -> {

            try {
                mCurrentVillage = mVillageList.get(position).getDescription();
                mVillageCode = mVillageList.get(position).getLookupCode();


            }catch (Exception e){e.printStackTrace();}

        });



        mGrowerImage.setOnClickListener(view -> callCamera());

         mSubmit.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {

                 if (!validate()) {
                     onLoginFailed();
                     return;
                 }

                 if(  checkGPSStatus(getApplicationContext())) {

                     if (NetworkUtil.isNetworkAvailable(getApplicationContext())) {

                         uploadData();
                      }else {
                         Alert("NO Internet Available");
                     }
                 }else {
                     Alert("Please TurnON Your Location");
                 }

             }
         });





    }


    @Override
    public void onStart() {
        super.onStart();
        HomeFragment.turnGPSOn(getApplicationContext());

    }




    private void callCamera() {


        if(  checkGPSStatus(getApplicationContext())) {

            if (NetworkUtil.isNetworkAvailable(getApplicationContext())) {

                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd_hhmmss", Locale.getDefault());
          String   timeStamp = dateFormat.format(new Date());


                String unit_id = PowerPreference.getDefaultFile().getString(Constants.USER_UNIT);
                String user_id = PowerPreference.getDefaultFile().getString(Constants.USER_ID);
                String myfileName = user_id + ("-") + unit_id + ("-") + timeStamp  ;




                picker.pickCamera((uri, file, bitmap) -> {
                    //do something.
                    String qrcodeString = " Survey Grower \n"+ unit_id +"\n"+ user_id;

                    Bitmap qrcode = qrCode(qrcodeString);
                    Bitmap bitmap1 = ImageUtils.addWatermark(qrcode, bitmap);


                    mGrowerFileImage =  ImageUtils.saveImage(bitmap1,grower_path);
                 //   file1 = mGrowerFileImage.getName();
                 //   mFilePath1 = mGrowerFileImage.getPath();


                    // mGrowerFileImage = file;

                    Glide.with(getApplicationContext()).
                            load(mGrowerFileImage)
                            .error(R.drawable.survey)
                            .into(mGrowerImage);


                });


            }else {
                Alert("Internet Connection Not Available");
            }

        } else  {
            Alert("Please TurnOn Your Location");

        }


    }



    public boolean validate() {
        boolean valid = true;

        mCurrentName = mName.getText().toString();
        mCurrentFName = mFather.getText().toString();
        mCurrentCnic = mCnic.getText().toString();
        mCurrentCast = mCast.getText().toString();
        mCurrentPass = mPasbook.getText().toString();
        mCurrentCode = mCode.getText().toString();


       if (mCurrentName.isEmpty()) {
            mName.setError("Please enter your name ");
            valid = false;
        } else {
            mName.setError(null);
        }

        if (mCurrentPass.isEmpty()) {
            mPasbook.setError("Enter Your PassBook No ");
            valid = false;
        } else {
            mPasbook.setError(null);
        }


        if (mCurrentFName.isEmpty()) {
            mFather.setError("Enter Your Father Name ");
            valid = false;
        } else {
            mFather.setError(null);
        }

      if(mCurrentCast.isEmpty()) {
            mCast.setError("Enter Your cast ");
            valid = false;
        } else {
            mCast.setError(null);
        }

        if(mCurrentCode.isEmpty()) {
            mCode.setError("Enter Your Grower code ");
            valid = false;
        } else {
            mCode.setError(null);
        }


        if(mCurrentCnic.isEmpty()) {
            mCnic.setError("Enter Your CNIC NO  ");
            valid = false;
        } else {
            mCnic.setError(null);
        }
        if(mGrowerFileImage !=null){
            Toast.makeText(getApplicationContext(), "Please take image first", Toast.LENGTH_SHORT).show();
        }



        return valid;
    }


    @SuppressLint("HardwareIds")
    private void uploadData()  {


        mProgressDialog = new ProgressDialog(CreateGrowerActivity.this);
        mProgressDialog.setTitle("Creating New Grower");
        mProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        mProgressDialog.setCancelable(false);
        mProgressDialog.setMessage("Data Uploading.....");
        mProgressDialog.setCanceledOnTouchOutside(false);
        mProgressDialog.show();


        uuid = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);




   String unit_id =     PowerPreference.getDefaultFile().getString(Constants.USER_UNIT,"");
     String mobile_id =    PowerPreference.getDefaultFile().getString(Constants.DEVICE_ID,"");
      String user_id =  PowerPreference.getDefaultFile().getString(Constants.USER_ID,"");
        String baseUrl= PowerPreference.getDefaultFile().getString(Constants.BASE_URL_NEW, UrlUtils.SERVER_DOMAIN);

        Log.d("lat", "lat" +LAT+"\n"+LNG+"\n circle"+mCurrentCircle);


        if (mCurrentCircle != null && LAT != 0.0 && LNG != 0.0) {




            RequestBody mFile = RequestBody.create( mGrowerFileImage,MediaType.parse("multipart/form-data"));
            MultipartBody.Part fileToUpload1 = MultipartBody.Part.createFormData("file1", mGrowerFileImage.getName(), mFile);


            RequestBody filename1 = RequestBody.create(mGrowerFileImage.getName(),MediaType.parse("text/plain"));


            RequestBody t_unit_code = RequestBody.create(unit_id,MediaType.parse("text/plain"));
            RequestBody t_uuid = RequestBody.create(uuid,MediaType.parse("text/plain"));

            RequestBody t_lat = RequestBody.create( String.valueOf(LAT),MediaType.parse("text/plain"));
            RequestBody t_lng = RequestBody.create( String.valueOf(LNG),MediaType.parse("text/plain"));
            RequestBody t_circle = RequestBody.create(mCircleCode,MediaType.parse("text/plain") );

            RequestBody t_village = RequestBody.create(MediaType.parse("text/plain"), mVillageCode);
            RequestBody t_passBook = RequestBody.create(MediaType.parse("text/plain"), mCurrentPass);
            RequestBody t_cast = RequestBody.create(MediaType.parse("text/plain"), mCurrentCast);

            RequestBody t_father_name = RequestBody.create( String.valueOf(mCurrentFName),MediaType.parse("text/plain"));
            RequestBody t_survey_id = RequestBody.create( user_id,MediaType.parse("text/plain"));
            RequestBody t_cnic = RequestBody.create( mCurrentCnic,MediaType.parse("text/plain"));

            RequestBody t_name = RequestBody.create( mCurrentName,MediaType.parse("text/plain"));
             RequestBody t_code = RequestBody.create( mCurrentCode,MediaType.parse("text/plain"));



            Call<ResultResponse> fileUpload = ServerTask.getInstance().getServices().post_grower_data(
                    fileToUpload1,
                    t_unit_code,t_circle,t_village,
                    t_passBook,t_code,t_name,
                    t_father_name,t_cnic,t_cast,t_lat,t_lng,
                    filename1,t_survey_id,t_uuid
            );

            fileUpload.enqueue(new ServerCallback<>() {
                @Override
                public void onFailure(ServerError restError) {

                    mProgressDialog.dismiss();
                    try {
                        Alert(" APi Time Out ");
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void onSuccess(retrofit2.Response<ResultResponse> response) {
                    mProgressDialog.dismiss();
                }

                @Override
                public void onResponse(retrofit2.Response<ResultResponse> response) {


                    try {
                        assert response.body() != null;
                        String status = response.body().getStatus();
                        if (status.equals("0")) {


                            //   if (finalI == listSize) {

                            try {
                                mProgressDialog.dismiss();
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            final AlertDialog.Builder alertDialogBuilder = new AlertDialog.
                                    Builder(CreateGrowerActivity.this);
                            alertDialogBuilder.setTitle("Grower Record Enter Successfully!");
                            alertDialogBuilder
                                    .setCancelable(false)
                                    .setPositiveButton("Ok", (dialog, id) -> {

                                        GrowerResult growerModel = new GrowerResult();

                                        growerModel.setGrowerCaste(mCurrentCast);
                                        growerModel.setGrowerName(mCurrentName);
                                        growerModel.setGrowerFName(mCurrentFName);
                                        growerModel.setCircleCode(mCircleCode);
                                        growerModel.setVillageCode(mVillageCode);
                                        growerModel.setUnitCode(unit_id);
                                        growerModel.setPassbookNo(mCurrentPass);
                                        growerModel.setGrowerCnic(mCurrentCnic);
                                        growerModel.setGrowerCode(mCurrentCode);
                                        growerModel.setmFile(Constants.IMAGE_URL+ mGrowerFileImage.getName());

                                        DatabaseHelper databaseHelper = new DatabaseHelper(getApplicationContext());

                                        databaseHelper.insert_growerInfo(growerModel);

                                        Intent i12 = new Intent(CreateGrowerActivity.this, MainActivity.class);
                                        startActivity(i12);
                                        finish();

                                    });

                            AlertDialog alertDialog = alertDialogBuilder.create();
                            alertDialog.show();
                            // }

                        } else if (status.equals("1")) {

                            final AlertDialog.Builder alertDialogBuilder = new AlertDialog.
                                    Builder(CreateGrowerActivity.this);
                            alertDialogBuilder.setTitle("Server Error");
                            alertDialogBuilder
                                    .setCancelable(false)
                                    .setPositiveButton("Ok", (dialog, id) -> {


                                        Intent i12 = new Intent(CreateGrowerActivity.this, MainActivity.class);
                                        startActivity(i12);
                                        finish();

                                    });

                            AlertDialog alertDialog = alertDialogBuilder.create();
                            alertDialog.show();

                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }


                }
            });






        }else {
            mProgressDialog.dismiss();
            Toast.makeText(getApplicationContext(), "EE", Toast.LENGTH_SHORT).show();
        }
    }


    private void Alert(String msg) {

        try {
            AlertDialog.Builder builder = new AlertDialog.Builder(getBaseContext());
            builder.setTitle("E - SURVEY")
                    .setMessage(msg)
                    .setCancelable(false)
                    .setPositiveButton("OKEY", (dialog, id) -> {

                        /*{


                        String user_id =  PowerPreference.getDefaultFile().getString(Constants.USER_ID,"empty");
                        String unit_id  =  PowerPreference.getDefaultFile().getString(Constants.USER_UNIT);

                        String baseUrl =      PowerPreference.getDefaultFile().getString(Constants.BASE_URL_NEW);
                        String lp_code =      PowerPreference.getDefaultFile().getString(Constants.USER_LP_CODE);
                        String deviceID  =     PowerPreference.getDefaultFile().getString(Constants.DEVICE_ID);


                        DatabaseAccess databaseAccess =  DatabaseAccess.getInstance(getApplicationContext());
                        databaseAccess.open();
                        if( databaseAccess.deleteUser(user_id)){
                            PowerPreference.clearAllData();
                            PowerPreference.clearAllDataAsync();
                            PowerPreference.getDefaultFile().setBoolean(Constants.SETTING_SCREEN, true);
                            PowerPreference.getDefaultFile().setString(Constants.USER_UNIT, unit_id);
                            PowerPreference.getDefaultFile().setString(Constants.BASE_URL_NEW, baseUrl);
                            PowerPreference.getDefaultFile().setString(Constants.USER_LP_CODE, lp_code);
                            PowerPreference.getDefaultFile().setString(Constants.DEVICE_ID, deviceID);
*/
                            Intent intent = new Intent( CreateGrowerActivity.this, MainActivity.class);
                            startActivity(intent);
                            finish();
                     //   }





                    });
            AlertDialog alert = builder.create();
            alert.show();
        }catch (Exception e){e.printStackTrace();}
    }


   /* @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == CustomCamera.IMAGE_SAVE_REQUEST) {

            //       if (requestCode == RESULT_OK) {


            try {

                String path = data.getStringExtra(CustomCamera.IMAGE_PATH);
                Bitmap tempBitmap = BitmapFactory.decodeFile(path);
                String qrcodeString = " Survey     ";

                Bitmap qrcode = qrCode(qrcodeString);
                Bitmap bitmap1 = ImageUtils.addWatermark(qrcode, tempBitmap);

                bitmap1 = ImageUtils.rotateImage(bitmap1,path);

                File saveFile =  ImageUtils.saveImage(bitmap1);
                file1 = saveFile.getName();
                mFilePath1 = saveFile.getPath();


                if(saveFile.exists()){
                    File f = new File(path);
                    f.delete();
                }
                Glide.with(getApplicationContext()).
                        load(saveFile)
                        .error(R.drawable.survey)
                        .into(mGrowerImage);






            } catch (Exception e) {
                e.printStackTrace();
            }






        }


    }

*/
    public void onLoginFailed() {
        Toast.makeText(getApplicationContext(), "Please Check Your fields", Toast.LENGTH_LONG).show();
    }





}