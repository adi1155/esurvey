
package com.example.shreefgroup.surevysystem.Model;

import java.io.Serializable;
import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class SurveyResult implements Serializable {

    @SerializedName("PolyResult")
    @Expose
    private String polyResult;
    @SerializedName("LatResult")
    @Expose
    private List<String> latResult = null;
    @SerializedName("LngResult")
    @Expose
    private List<String> lngResult = null;
    @SerializedName("InfoResult")
    @Expose
    private InfoResult infoResult;

    public String getPolyResult() {
        return polyResult;
    }

    public void setPolyResult(String polyResult) {
        this.polyResult = polyResult;
    }

    public List<String> getLatResult() {
        return latResult;
    }

    public void setLatResult(List<String> latResult) {
        this.latResult = latResult;
    }

    public List<String> getLngResult() {
        return lngResult;
    }

    public void setLngResult(List<String> lngResult) {
        this.lngResult = lngResult;
    }

    public InfoResult getInfoResult() {
        return infoResult;
    }

    public void setInfoResult(InfoResult infoResult) {
        this.infoResult = infoResult;
    }

}
