package com.example.shreefgroup.surevysystem.Ui.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.shreefgroup.surevysystem.Adopter.GAdopter.GrowerAdopter;
import com.example.shreefgroup.surevysystem.DataBase.DatabaseHelper;
import com.example.shreefgroup.surevysystem.Model.Grower.GrowerResult;
import com.example.shreefgroup.surevysystem.R;
import com.example.shreefgroup.surevysystem.Ui.Fragment.home.HomeFragment;

import java.util.ArrayList;
import java.util.List;

public class GrowerActivity extends AppCompatActivity  {


    Button mGrowerSync,mNewGrower,mSearchBtn;

    EditText mCnicSearch,mCodeSearch;
    RecyclerView mRecycleView;
    LinearLayout mBackBtn;

    List<GrowerResult> growerList = new ArrayList<>();
    public GrowerAdopter growerAdopter;

    DatabaseHelper databaseHelper ;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grower);
        databaseHelper = new DatabaseHelper(getApplicationContext());


        mNewGrower = findViewById(R.id.create_new_grower);
        mGrowerSync = findViewById(R.id.grower_sync_btn);
        mCnicSearch = findViewById(R.id.grower_search_by_cnic);
        mCodeSearch = findViewById(R.id.grower_search_by_code);
        mRecycleView = findViewById(R.id.grower_recycle_view);
        mBackBtn = findViewById(R.id.grower_back_btn);
        mSearchBtn = findViewById(R.id.grower_search_btn);


        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        layoutManager.setAutoMeasureEnabled(true);
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);

        mRecycleView.setLayoutManager(layoutManager);

        growerList = databaseHelper.get_grower_info();

        growerAdopter = new GrowerAdopter(growerList);
        mRecycleView.setAdapter(growerAdopter);
        growerAdopter.notifyDataSetChanged();


        mBackBtn.setOnClickListener(view -> finish());
        mGrowerSync.setOnClickListener(view -> HomeFragment.SyncGrower(getApplicationContext()));
        mNewGrower.setOnClickListener(view -> {
             Intent i = new Intent(getApplicationContext(),CreateGrowerActivity.class);
              startActivity(i);
         });




    }
}