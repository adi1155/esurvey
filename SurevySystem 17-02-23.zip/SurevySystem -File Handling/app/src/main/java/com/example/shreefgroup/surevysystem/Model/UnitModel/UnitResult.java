
package com.example.shreefgroup.surevysystem.Model.UnitModel;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class UnitResult   implements Serializable {

    @SerializedName("B_UNIT_ID")
    @Expose
    private String bUnitId;
    @SerializedName("B_UNIT_DESC")
    @Expose
    private String bUnitDesc;

    public String getBUnitId() {
        return bUnitId;
    }

    public void setBUnitId(String bUnitId) {
        this.bUnitId = bUnitId;
    }

    public String getBUnitDesc() {
        return bUnitDesc;
    }

    public void setBUnitDesc(String bUnitDesc) {
        this.bUnitDesc = bUnitDesc;
    }

}
