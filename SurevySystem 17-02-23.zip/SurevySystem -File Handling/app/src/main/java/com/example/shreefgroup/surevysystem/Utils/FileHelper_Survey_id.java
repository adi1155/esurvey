package com.example.shreefgroup.surevysystem.Utils;

/**
 * Created by ashfaq on 4/6/2017.
 */

import android.os.Environment;
import android.util.Log;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;

/**
 * Created by ashfaq on 11/27/2016.
 */

public class FileHelper_Survey_id {


    final static String fileSID = "SURVEY_ID";
    final static String path =AppController.getInstance().path+ "/ESurvey"+"/";
    final static String TAG = FileHelper_Settings.class.getName();



    public static boolean saveToFile(String data) {

        try {
            new File(path).mkdir();

            File gpxfile = new File(path, fileSID);

            FileWriter writer = new FileWriter(gpxfile,true);
            writer.append(data+"\n");
            writer.flush();
            writer.close();


            return true;
        } catch (IOException ex) {
            ex.printStackTrace();
            Log.d(TAG, ex.getMessage());
        }
        return false;
    }



}