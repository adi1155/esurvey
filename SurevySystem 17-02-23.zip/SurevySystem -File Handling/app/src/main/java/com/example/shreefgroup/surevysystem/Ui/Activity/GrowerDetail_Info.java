package com.example.shreefgroup.surevysystem.Ui.Activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedList;

import static android.content.ContentValues.TAG;

import com.example.shreefgroup.surevysystem.R;
import com.example.shreefgroup.surevysystem.Utils.AppController;

public class GrowerDetail_Info extends Activity {
    private TextView tv1, tv2, tv3, tv4, tv5, tv6, tv7, tv8, tv9, tv10,tv11,tv12;
    private AppController application;
    Button b;
    public static LinkedList<String> arraydetail=new LinkedList<String>();
    private String
            textv,textv2,textv3,textv4,textv5,textv6,textv7,textv8,textv9,textv10,textv11,
            textv12,textv13,textv14,textv15,textv16,textv17,textv18,textv19;
   public final static String path = AppController.getInstance().path + "/ESurvey" + "/";
   public final static String file_growerdetail = "Grower_detail.txt";
    private TextView tv13;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_popup);
        application = (AppController) getApplicationContext();
        tv1 = (TextView) findViewById(R.id.t1);
        tv2 = (TextView) findViewById(R.id.t2);
        tv3 = (TextView) findViewById(R.id.t13);
        tv4 = (TextView) findViewById(R.id.t3);
        tv5 = (TextView) findViewById(R.id.t4);
        tv6 = (TextView) findViewById(R.id.t5);
        tv7 = (TextView) findViewById(R.id.t6);
        tv8 = (TextView) findViewById(R.id.t7);
        tv9 = (TextView) findViewById(R.id.t8);
        tv10 = (TextView) findViewById(R.id.t9);
        tv11 = (TextView) findViewById(R.id.t10);
        tv12 = (TextView) findViewById(R.id.t11);
        tv13 = (TextView) findViewById(R.id.t12);

         b=(Button) findViewById(R.id.btn_view);
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        int Width = dm.widthPixels;
        int height = dm.heightPixels;

        getWindow().setLayout((int) (Width * 1), (int) (height * 1));
        ReadFile(GrowerDetail_Info.this);

        for (int i = 0; i < arraydetail.size(); i++) {
            if (arraydetail.indexOf(0) != 0) {
                textv = arraydetail.get(0).toString();
                textv2 = arraydetail.get(1).toString();
                textv3 = arraydetail.get(2).toString();
                textv4 = arraydetail.get(3).toString();
                textv5 = arraydetail.get(4).toString();
                textv6 = arraydetail.get(5).toString();
                textv7 = arraydetail.get(6).toString();
                textv8 = arraydetail.get(7).toString();
                textv9 = arraydetail.get(8).toString();
                textv10 = arraydetail.get(9).toString();
                textv11= arraydetail.get(10).toString();
                textv12 = arraydetail.get(11).toString();
                textv13 = arraydetail.get(12).toString();
                i = i + 39;

            }
        }
        tv1.setText(textv);
        tv2.setText(textv2);
        tv3.setText(textv3);
        tv4.setText(textv4);
        tv5.setText(textv5);
        tv6.setText(textv6);
        tv7.setText(textv7);
        tv8.setText(textv8);
        tv9.setText(textv9);
        tv10.setText(textv10);
        tv11.setText(textv11);
        tv12.setText(textv12);
        tv13.setText(textv13);

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent I = new Intent(GrowerDetail_Info.this, MapActivity.class);
                startActivity(I);


            }
        });
    }

    public static String ReadFile(Context context) {
        String line = null;
        arraydetail.clear();
        try {
            FileInputStream fileInputStream = new FileInputStream(new File(path + file_growerdetail));
            InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream);
            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
            StringBuilder stringBuilder = new StringBuilder();

            while ((line = bufferedReader.readLine()) != null) {
                arraydetail.add(line);
                stringBuilder.append(line + System.getProperty("line.separator"));
            }
            fileInputStream.close();
            line = stringBuilder.toString();


            bufferedReader.close();
        } catch (FileNotFoundException ex) {
            Log.d(TAG, ex.getMessage());
        } catch (IOException ex) {
            Log.d(TAG, ex.getMessage());
        }
        return line;
    }


}