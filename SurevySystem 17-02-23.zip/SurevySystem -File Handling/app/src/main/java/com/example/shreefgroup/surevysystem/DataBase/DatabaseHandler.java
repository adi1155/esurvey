package com.example.shreefgroup.surevysystem.DataBase;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHandler extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "Surevy_and_Survey1";


    public static final String TABLE_GPS = "GPS_Final";
    public static final String TABLE_Master = "Master_Final";

    public static final String TABLE_CIRCLE = "CIRCLES";
    public static final String TABLE_VILLAGE = "VILLAGE";
    public static final String TABLE_CROP_CONDITION = "CROP_CONDITION";
    public static final String TABLE_CROP_VARVITY = "CROP_VARVITY";
    public static final String TABLE_PLANTATION = "PLANTATION";
    public static final String TABLE_SURVEY_TYPE = "SURVEY_TYPE";
    public static final String TABLE_GROWER = "GROWER";
    public static final String TABLE_SOWING = "SOWING";





    public static final String KEY_GROWER_ID= "GROWER_ID";
    public static final String KEY_SOWING_DISTANCE= "SOWING_DISTANCE";
    public static final String KEY_SOWING_ID= "SOWING_ID";
    public static final String KEY_GROWER_NAME= "GROWER_NAME";
    public static final String KEY_GROWER_CODE= "GROWER_CODE";
    public static final String KEY_GROWER_FATHER_NAME= "GROWER_FATHER_NAME";
    public static final String KEY_GROWER_CNIC= "GROWER_CNIC";
    public static final String KEY_GROWER_CAST= "GROWER_CAST";
    public static final String KEY_GROWER_PASSBOOK_NO= "GROWER_PASSBOOK_NO";
    public static final String KEY_GROWER_CIRCLE_CODE= "GROWER_CIRCLE_CODE";
    public static final String KEY_GROWER_VIlLAGE_CODE= "GROWER_VILLAGE_CODE";
    public static final String KEY_GROWER_UNIT_CODE= "GROWER_UNIT_CODE";
    public static final String KEY_GROWER_IMAGE= "GROWER_IMAGE";




    public static final String KEY_FileName = "FileName";
    public static final String KEY_FileName2 = "FileName2";
    public static final String KEY_FileName3 = "FileName3";
    public static final String KEY_FileName4 = "FileName4";
    /*********************************************/
    public static final String KEY_Serial = "SERIALID";
    public static final String KEY_ID = "id";


    public static final String KEY_CIRCLE_ID= "CIRCLE_ID";
    public static final String KEY_CIRCLE_NAME= "CIRCLE_NAME";
    public static final String KEY_CIRCLE_CODE= "CIRCLE_CODE";

  public static final String KEY_CROP_ID= "CROP_ID";
    public static final String KEY_CROP_NAME= "CROP_NAME";
    public static final String KEY_CROP_DESC= "CROP_DESC";


    public static final String KEY_CROP_VARRITY_ID= "VARRITY_ID";
    public static final String KEY_CROP_VARRITY_NAME= "VARRITY_NAME";
    public static final String KEY_CROP_VARRITY_DESC= "VARRITY_DESC";


   public static final String KEY_PLANTATION_ID= "PLANTATION_ID";
    public static final String KEY_PLANTATION_NAME= "PLANTATION_NAME";
    public static final String KEY_PLANTATION_DESC= "PLANTATION_DESC";

    public static final String KEY_SURVEY_ID= "SURVEY_ID";
    public static final String KEY_SURVEY_NAME= "SURVEY_NAME";
    public static final String KEY_SURVEY_DESC= "SURVEY_DESC";




    public static final String KEY_VILLAGE_ID= "VILLAGE_ID";
    public static final String KEY_VILLAGE_NAME= "VILLAGE_NAME";
    public static final String KEY_VILLAGE_CODE= "VILLAGE_CODE";

    public static final String KEY_Survey_type = "Survey_type";
    public static final String KEY_CNIC = "CNIC_NO";
    public static final String KEY_Grower_name = "NAME";
    public static final String KEY_Father_name = "FATHER_NAME";
    public static final String KEY_Grower_code = "GROWER_CODE";
    public static final String KEY_CASTE = "CASTE";
    public static final String KEY_CIRCLE = "CIRCLE";
    public static final String KEY_VILLAGE = "VILLAGE";
    public static final String KEY_TOTAL_ACRAGE = "ACRAGE";
    public static final String KEY_TOTAL_YIELD = "YIELD";
    public static final String KEY_SQRNO = "SQURE_NO";
    public static final String KEY_SOWING = "SWOING_DISTANCE";
    public static final String KEY_CROP_COND = "CROP_CONDITION";
    public static final String KEY_VERIETY = "VERIETY";
    public static final String KEY_PLANTATION = "PLANTATION";
    public static final String KEY_No = "NO_";
    public static final String KEY_Mob_id = "MOB_ID";
    public static final String KEY_Latitude = "get_Latitude";
    public static final String KEY_Longitude = "get_Longitude";
    public static final String KEY_IMEI = "IMEI";
    public static final String KEY_TRAN_DATE = "TRAN_DATE";
    public static final String KEY_Flag = "FLAG";
    public static final String KEY_MAP_AREA = "MAP_AREA";
    public static final String KEY_Killa = "KILLA_NO";
    public static String KEY_NOTE = "NOTE";
    private static final int VERSION =115;



    private static final String CREATE_TABLE_CIRCLE = "CREATE TABLE " + TABLE_CIRCLE + " ("
            + KEY_CIRCLE_ID + " INTEGER PRIMARY KEY,"
            + KEY_CIRCLE_NAME + " TEXT,"
            + KEY_CIRCLE_CODE + " TEXT"
            + ")";

private static final String CREATE_TABLE_SOWING = "CREATE TABLE " + TABLE_SOWING + " ("
            + KEY_SOWING_ID + " INTEGER PRIMARY KEY,"
            + KEY_SOWING_DISTANCE + " TEXT"
            + ")";



    private static final String CREATE_TABLE_VILLAGE = "CREATE TABLE " + TABLE_VILLAGE + " ("
            + KEY_VILLAGE_ID + " INTEGER PRIMARY KEY,"
            + KEY_VILLAGE_NAME + " TEXT,"
            + KEY_VILLAGE_CODE + " TEXT,"
            + KEY_CIRCLE_NAME + " TEXT"
            + ")";


    private static final String CREATE_TABLE_CROP = "CREATE TABLE " + TABLE_CROP_CONDITION + " ("
            + KEY_CROP_ID + " INTEGER PRIMARY KEY,"
            + KEY_CROP_NAME + " TEXT,"
            + KEY_CROP_DESC + " TEXT"
            + ")";



    private static final String CREATE_TABLE_CROP_VARRVITY = "CREATE TABLE " + TABLE_CROP_VARVITY + " ("
            + KEY_CROP_VARRITY_ID + " INTEGER PRIMARY KEY,"
            + KEY_CROP_VARRITY_NAME + " TEXT,"
            + KEY_CROP_VARRITY_DESC + " TEXT"
            + ")";


    private static final String CREATE_TABLE_PLANTATION = "CREATE TABLE " + TABLE_PLANTATION + " ("
            + KEY_PLANTATION_ID + " INTEGER PRIMARY KEY,"
            + KEY_PLANTATION_NAME + " TEXT,"
            + KEY_PLANTATION_DESC + " TEXT"
            + ")";

    private static final String CREATE_TABLE_SURVEY = "CREATE TABLE " + TABLE_SURVEY_TYPE + " ("
            + KEY_SURVEY_ID + " INTEGER PRIMARY KEY,"
            + KEY_SURVEY_NAME + " TEXT,"
            + KEY_SURVEY_DESC + " TEXT"
            + ")";


private static final String CREATE_TABLE_GROWER = "CREATE TABLE " + TABLE_GROWER + " ("
            + KEY_GROWER_ID + " INTEGER PRIMARY KEY,"
            + KEY_GROWER_NAME + " TEXT,"
            + KEY_GROWER_FATHER_NAME + " TEXT,"
            + KEY_GROWER_CNIC + " TEXT,"
            + KEY_GROWER_CAST + " TEXT,"
            + KEY_GROWER_CODE+ " TEXT,"
            + KEY_GROWER_VIlLAGE_CODE + " TEXT,"
            + KEY_GROWER_CIRCLE_CODE + " TEXT,"
            + KEY_GROWER_PASSBOOK_NO + " TEXT,"
            + KEY_GROWER_UNIT_CODE + " TEXT,"
            + KEY_GROWER_IMAGE + " TEXT"
            + ")";








    private static final String CREATE_TABLE_GPS = "CREATE TABLE " + TABLE_GPS + " ("
            + KEY_ID + " INTEGER PRIMARY KEY,"
            + KEY_Mob_id + " TEXT,"
            + KEY_Latitude + " TEXT,"
            + KEY_Longitude + " TEXT,"
            + KEY_IMEI + " TEXT,"
            + KEY_TRAN_DATE + " TEXT,"
            + KEY_No + " TEXT,"
            + KEY_Flag + " TEXT"
            + ")";
    /*******************************************************/
    private static final String CREATE_TABLE_MASTER = "CREATE TABLE " + TABLE_Master + "("
            + KEY_ID + " INTEGER PRIMARY KEY,"
            + KEY_Mob_id + " TEXT,"
            + KEY_Survey_type + " TEXT,"
            + KEY_IMEI + " TEXT,"
            + KEY_CNIC + " TEXT,"
            + KEY_Grower_code + " TEXT,"
            + KEY_Grower_name + " TEXT,"
            + KEY_Father_name + " TEXT,"
            + KEY_CASTE + " TEXT,"
            + KEY_CIRCLE + " TEXT,"
            + KEY_VILLAGE + " TEXT,"
            + KEY_TOTAL_ACRAGE + " TEXT,"
            + KEY_TOTAL_YIELD + " TEXT,"
            + KEY_Killa + " TEXT,"
            + KEY_SQRNO + " TEXT,"
            + KEY_SOWING + " TEXT,"
            + KEY_CROP_COND + " TEXT,"
            + KEY_VERIETY + " TEXT,"
            + KEY_PLANTATION + " TEXT,"
            + KEY_NOTE + " TEXT ,"
            + KEY_FileName + " TEXT ,"
            + KEY_FileName2 + " TEXT ,"
            + KEY_FileName3 + " TEXT ,"
            + KEY_FileName4 + " TEXT ,"
            + KEY_Flag + " TEXT ,"
            + KEY_MAP_AREA + " TEXT "
            + ")";


    public DatabaseHandler(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_MASTER);
        db.execSQL(CREATE_TABLE_GPS);
        db.execSQL(CREATE_TABLE_CIRCLE);
        db.execSQL(CREATE_TABLE_VILLAGE);
        db.execSQL(CREATE_TABLE_SURVEY);
        db.execSQL(CREATE_TABLE_PLANTATION);
        db.execSQL(CREATE_TABLE_CROP_VARRVITY);
        db.execSQL(CREATE_TABLE_CROP);
        db.execSQL(CREATE_TABLE_GROWER);
        db.execSQL(CREATE_TABLE_SOWING);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_Master);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_GPS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CIRCLE);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_VILLAGE);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_SURVEY_TYPE);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PLANTATION);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CROP_VARVITY);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CROP_CONDITION);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_GROWER);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_SOWING);
        onCreate(db);
    }

}
