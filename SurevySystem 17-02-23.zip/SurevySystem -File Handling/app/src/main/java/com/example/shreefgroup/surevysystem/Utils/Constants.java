package com.example.shreefgroup.surevysystem.Utils;


import android.app.Activity;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.telephony.TelephonyManager;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;


import com.google.android.material.snackbar.Snackbar;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.NetworkInterface;
import java.util.Collections;
import java.util.List;

public class Constants {

    public static String FILE_NAME_SHARED_PREF = "ELP";
    public static String ENTRY_FILE_NAME = "ENTRY_FILE_NAME";
    public static String USER_TYPE = "TYPE";
    public static String USER_ID = "ID";
    public static String DEVICE_ID = "DEVICE_ID";
    public static String SERVICE_TYPE = "SERVICE_type";
    public static String SETTING_SCREEN = "SETTING_SCREEN_T";

    public static String USER_LAT = "LAT";
    public static String BASE_URL_NEW = "BASE_ULR_NEW";
    public static String PING_SUCCESS = "PING_SUCCESS";
    public static String USER_FIRST_IMAGE = "FIRST_IMAGE";
    public static String USER_LONG = "LNG";
    public static String CIRCLE_CODE = "CIRCLE_CODE";
    public static String MILL_LAT = "MILL_LAT";
    public static String MILL_LNG = "MILL_LNG";
    public static String USER_NAME = "userName";
    public static String APP_LOGO = "APP_LOGO";
    public static String APP_BACKGROUND = "APP_BACKGROUND";
    public static String APP_DEVELOP_BY = "APP_DEVELOP_BY";
    public static String APP_NAME = "APP_NEMAWW";
    public static String  REG = "type";
    public static String  FIRST_IMAGE_STATUS = "FIRST_IMAGE_STATUS";
    public static String USER_radius = "radius";
    public static String USER_mode = "mode";
    public static String USER_UNIT = "unit_id";
    public static String USER_LP_CODE = "LP_CODE";
    public static String USER_DEVICE_ID = "device_id";
    public static String LP_TRANSFER = "LP_TRANSFER";
    public static String USER_PASSWORD = "userPassword";
    public static String DATE = "date";
    public static String SURVEY_TYPE = "";
    public static String BASEURL = "http://scorpio.sgroup.pk:8085/elp_22.1/";
    public static String IMAGE_URL = "http://scorpio.sgroup.pk:8085/Esurvey_22.1/NewSurvey/";


    public static String BASEURL2 = "http://scorpio.sgroup.pk:8085/elp/Registration/";
    public static String BASEURL3 = "http://scorpio.sgroup.pk:8085/elp/Arrival/";

    public static final String C_PREFERENCE_MAGICAL_CAMERA = "MCPreference";
    public static final String C_PREFERENCE_MC_DIRECTORY_NAME = "MCDirecto2ryName";
    public static final String C_PREFERENCE_MC_PHOTO_NAME = "MCPhotoName";
    public static final String C_PREFERENCE_MC_SELECTED_PICTURE = "MCTitleSelectPicture";
    public static final String C_PREFERENCE_MC_QUALITY_PICTURE = "MCQualityPicture";
    public static final String C_PREFERENCE_MC_FORMAT = "MCFormat";
    public static final String C_PREFERENCE_MC_AUTO_IC_NAME = "MCAutoincrementName";
    public static final String C_PREFERENCE_MC_FACIAL_RECOGNITION_THICK = "MCFacialRecognitionThick";
    public static final String C_PREFERENCE_MC_FACIAL_RECOGNITION_COLOR = "MCFacialRecognitionColor";

    public static final String C_PNG = "png";
    public static final String C_JPG = "jpg";
    public static final String C_WEBP = "webp";

    public static Bitmap magicalCameraBitmap;



    public static Bitmap imageRotate(Context context, String selectedImage)
            throws IOException {
        int MAX_HEIGHT = 460;
        int MAX_WIDTH = 400;

        // First decode with inJustDecodeBounds=true to check dimensions
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        InputStream imageStream = context.getContentResolver().openInputStream(Uri.fromFile(new File(selectedImage)));
        BitmapFactory.decodeStream(imageStream, null, options);
        imageStream.close();

        // Calculate inSampleSize
        options.inSampleSize = calculateInSampleSize(options, MAX_WIDTH, MAX_HEIGHT);

        // Decode bitmap with inSampleSize set
        options.inJustDecodeBounds = false;
        imageStream = context.getContentResolver().openInputStream(Uri.fromFile(new File(selectedImage)));
        Bitmap img = BitmapFactory.decodeStream(imageStream, null, options);

        img = rotateImageIfRequired(img, selectedImage);
        return img;
    }

    private static int calculateInSampleSize(BitmapFactory.Options options,
                                             int reqWidth, int reqHeight) {
        // Raw height and width of image
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;

        if (height > reqHeight || width > reqWidth) {

            // Calculate ratios of height and width to requested height and width
            final int heightRatio = Math.round((float) height / (float) reqHeight);
            final int widthRatio = Math.round((float) width / (float) reqWidth);

            // Choose the smallest ratio as inSampleSize value, this will guarantee a final image
            // with both dimensions larger than or equal to the requested height and width.
            inSampleSize = Math.min(heightRatio, widthRatio);

            // This offers some additional logic in case the image has a strange
            // aspect ratio. For example, a panorama may have a much larger
            // width than height. In these cases the total pixels might still
            // end up being too large to fit comfortably in memory, so we should
            // be more aggressive with sample down the image (=larger inSampleSize).

            final float totalPixels = width * height;

            // Anything more than 2x the requested pixels we'll sample down further
            final float totalReqPixelsCap = reqWidth * reqHeight * 2;

            while (totalPixels / (inSampleSize * inSampleSize) > totalReqPixelsCap) {
                inSampleSize++;
            }
        }
        return inSampleSize;
    }

    private static Bitmap rotateImageIfRequired(Bitmap img, String selectedImage) throws IOException {

        ExifInterface ei = new ExifInterface(selectedImage);
        int orientation = ei.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);

        switch (orientation) {
            case ExifInterface.ORIENTATION_ROTATE_90:
                return rotateImage(img, 90);
            case ExifInterface.ORIENTATION_ROTATE_180:
                return rotateImage(img, 180);
            case ExifInterface.ORIENTATION_ROTATE_270:
                return rotateImage(img, 270);
            default:
                return img;
        }
    }
    private static Bitmap rotateImage(Bitmap img, int degree) {
        Matrix matrix = new Matrix();
        matrix.postRotate(degree);
        Bitmap rotatedImg = Bitmap.createBitmap(img, 0, 0, img.getWidth(), img.getHeight(), matrix, true);
        img.recycle();
        return rotatedImg;
    }


    public static String getMacAddress() {
        try {
            List<NetworkInterface> all = Collections.list(NetworkInterface.getNetworkInterfaces());
            for (NetworkInterface networkInterface : all) {
                if (!networkInterface.getName().equalsIgnoreCase("wlan0")) continue;

                byte[] macBytes = networkInterface.getHardwareAddress();
                if (macBytes == null) {
                    return "";
                }

                StringBuilder res1 = new StringBuilder();
                Log.e("get mac", "getMacAddr: "+res1.toString() );
                for (byte b : macBytes) {
                    // res1.append(Integer.toHexString(b & 0xFF) + ":");
                    res1.append(String.format("%02X:",b));
                }

                if (res1.length() > 0) {
                    res1.deleteCharAt(res1.length() - 1);
                }
                return res1.toString().replace(":","-");
            }
        } catch (Exception ex) {
            Log.e("TAG", "getMacAddr: ", ex);
        }
        return "";
    }









    public static void openScheme(Activity activity, String scheme, String id, String url, String errorMessage){
        Uri uri = Uri.parse(scheme);
        try {
            uri = ContentUris.withAppendedId(uri, Long.parseLong(id));
        }catch(Exception ev){
            uri = Uri.parse(scheme + id);
        }
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        try {
            activity.startActivity(intent);
        }catch(Exception ev){
            try {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                activity.startActivity(browserIntent);
            }catch(Exception ex){
                Toast.makeText(activity,errorMessage,Toast.LENGTH_LONG).show();
            }
        }
    }

    public static String getBase64String(Bitmap bitmap)
    {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();

        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);

        byte[] imageBytes = baos.toByteArray();

        String base64String = Base64.encodeToString(imageBytes, Base64.NO_WRAP);

        return base64String;
    }


    public static boolean checkMobileDataIsEnabled(Context context){
        boolean mobileYN = false;

        TelephonyManager tm = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        if (tm.getSimState() == TelephonyManager.SIM_STATE_READY) {
            TelephonyManager tel = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
//          if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN_MR1)
//          {
//              mobileYN = Settings.Global.getInt(context.getContentResolver(), "mobile_data", 0) == 1;
//          }
//          else{
//              mobileYN = Settings.Secure.getInt(context.getContentResolver(), "mobile_data", 0) == 1;
//          }
            int dataState = tel.getDataState();
            Log.v("mobile_data","tel.getDataState() : "+ dataState);
            if(dataState != TelephonyManager.DATA_DISCONNECTED){
                mobileYN = true;
            }

        }

        return mobileYN;
    }


}
