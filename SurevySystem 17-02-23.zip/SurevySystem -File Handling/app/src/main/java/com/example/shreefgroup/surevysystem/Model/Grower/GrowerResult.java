
package com.example.shreefgroup.surevysystem.Model.Grower;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;


public class GrowerResult  implements Serializable {

    @SerializedName("UNIT_CODE")
    @Expose
    private String unitCode;
    @SerializedName("CIRCLE_CODE")
    @Expose
    private String circleCode;
    @SerializedName("VILLAGE_CODE")
    @Expose
    private String villageCode;
    @SerializedName("PASSBOOK_NO")
    @Expose
    private String passbookNo;
    @SerializedName("GROWER_CODE")
    @Expose
    private String growerCode;
    @SerializedName("GROWER_NAME")
    @Expose
    private String growerName;
    @SerializedName("GROWER_F_NAME")
    @Expose
    private String growerFName;
    @SerializedName("GROWER_CNIC")
    @Expose
    private String growerCnic;
    @SerializedName("GROWER_CASTE")
    @Expose
    private String growerCaste;

    @SerializedName("FILENAME1")
    @Expose
    private String mFile;

    public String getmFile() {
        return mFile;
    }

    public void setmFile(String mFile) {
        this.mFile = mFile;
    }

    public String getUnitCode() {
        return unitCode;
    }

    public void setUnitCode(String unitCode) {
        this.unitCode = unitCode;
    }

    public String getCircleCode() {
        return circleCode;
    }

    public void setCircleCode(String circleCode) {
        this.circleCode = circleCode;
    }

    public String getVillageCode() {
        return villageCode;
    }

    public void setVillageCode(String villageCode) {
        this.villageCode = villageCode;
    }

    public String getPassbookNo() {
        return passbookNo;
    }

    public void setPassbookNo(String passbookNo) {
        this.passbookNo = passbookNo;
    }

    public String getGrowerCode() {
        return growerCode;
    }

    public void setGrowerCode(String growerCode) {
        this.growerCode = growerCode;
    }

    public String getGrowerName() {
        return growerName;
    }

    public void setGrowerName(String growerName) {
        this.growerName = growerName;
    }

    public String getGrowerFName() {
        return growerFName;
    }

    public void setGrowerFName(String growerFName) {
        this.growerFName = growerFName;
    }

    public String getGrowerCnic() {
        return growerCnic;
    }

    public void setGrowerCnic(String growerCnic) {
        this.growerCnic = growerCnic;
    }

    public String getGrowerCaste() {
        return growerCaste;
    }

    public void setGrowerCaste(String growerCaste) {
        this.growerCaste = growerCaste;
    }

}
