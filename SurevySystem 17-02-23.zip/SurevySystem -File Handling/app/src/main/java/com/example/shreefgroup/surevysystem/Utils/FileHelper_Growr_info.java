package com.example.shreefgroup.surevysystem.Utils;

/**
 * Created by ashfaq on 11/27/2016.
 */


import android.content.Context;
import android.os.Environment;
import android.util.Log;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * Created by Tan on 2/18/2016.
 */
public class FileHelper_Growr_info {

    final static String fileName22 = "Grower_data";
    final static String path = AppController.getInstance().path + "/ESurvey"+"/";
  //final static String path =Environment.getDataDirectory().getPath()+"/";
    final static String TAG = FileHelper_Settings.class.getName();

    public static  String ReadFile( Context context){
        String line = null;

        try {
            FileInputStream fileInputStream = new FileInputStream (new File(path + fileName22));
            InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream);
            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
            StringBuilder stringBuilder = new StringBuilder();

            while ( (line = bufferedReader.readLine()) != null )
            {
                stringBuilder.append(line + System.getProperty("line.separator"));
            }
            fileInputStream.close();
            line = stringBuilder.toString();

            bufferedReader.close();
        }
        catch(FileNotFoundException ex) {
            Log.d(TAG, ex.getMessage());
        }
        catch(IOException ex) {
            Log.d(TAG, ex.getMessage());
        }
        return line;
    }



    public static boolean saveToFile(String data) {

        try {
            new File(path).mkdir();

            File gpxfile = new File(path, fileName22);

            FileWriter writer = new FileWriter(gpxfile,true);
            writer.append(data+"\n");
            writer.flush();
            writer.close();


            return true;
        } catch (IOException ex) {
            ex.printStackTrace();
            Log.d(TAG, ex.getMessage());
        }
        return false;
    }



}