
package com.example.shreefgroup.surevysystem.Model.Sync;

import com.example.shreefgroup.surevysystem.Model.CircleModel.CircleResult;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;


public class SyncResult {

    @SerializedName("village")
    @Expose
    private List<Village> village = null;
    @SerializedName("crop_condtion")
    @Expose
    private List<CropCondtion> cropCondtion = null;
    @SerializedName("crop_varrity")
    @Expose
    private List<CropVarrity> cropVarrity = null;
    @SerializedName("plantation")
    @Expose
    private List<Plantation> plantation = null;
    @SerializedName("survey_types")
    @Expose
    private List<SurveyType> surveyTypes = null;


    @SerializedName("Circles")
    @Expose
    private List<CircleResult> circles = null;

    public List<CircleResult> getCircles() {
        return circles;
    }

    public void setCircles(List<CircleResult> circles) {
        this.circles = circles;
    }

    @SerializedName("sowing Distance")
    @Expose
    private List<SowingDistance> sowingDistance = null;

    public List<SowingDistance> getSowingDistance() {
        return sowingDistance;
    }

    public void setSowingDistance(List<SowingDistance> sowingDistance) {
        this.sowingDistance = sowingDistance;
    }

    public List<Village> getVillage() {
        return village;
    }

    public void setVillage(List<Village> village) {
        this.village = village;
    }

    public List<CropCondtion> getCropCondtion() {
        return cropCondtion;
    }

    public void setCropCondtion(List<CropCondtion> cropCondtion) {
        this.cropCondtion = cropCondtion;
    }

    public List<CropVarrity> getCropVarrity() {
        return cropVarrity;
    }

    public void setCropVarrity(List<CropVarrity> cropVarrity) {
        this.cropVarrity = cropVarrity;
    }

    public List<Plantation> getPlantation() {
        return plantation;
    }

    public void setPlantation(List<Plantation> plantation) {
        this.plantation = plantation;
    }

    public List<SurveyType> getSurveyTypes() {
        return surveyTypes;
    }

    public void setSurveyTypes(List<SurveyType> surveyTypes) {
        this.surveyTypes = surveyTypes;
    }

}
