package com.example.shreefgroup.surevysystem.Network;

/**
 * Created by mRashid on 1/06/2019.
 */

public interface UrlUtils {
    String SERVER_DOMAIN = "http://scorpio.sgroup.pk:8085";



     String uploadImage = "/Esurvey_22.1/upload.php";
     String check_survey = "/Esurvey_22.1/check_survey_exist.PHP";
     String check_imei = "/servey_system/IMEI_NO_REGISTER.PHP";

     String GET_UNIT_LIST = "/Esurvey_22.1/GET_UNIT_LIST.php";
     String GET_USER_LIST = "/Esurvey_22.1/GET_USER_LIST.php";
     String GET_MOBILE_LIST = "/Esurvey_22.1/GET_MOBILE_LIST.php";
     String GET_CIRCLE_LIST = "/Esurvey_22.1/GET_CIRCLE_LIST.php";
     String GET_SYCN_DATA = "/Esurvey_22.1/get_circle_villege_list.php";
     String GET_GROWER_INFO = "/Esurvey_22.1/get_grower_list.php";
     String ADD_CONFIG = "/Esurvey_22.1/DEVICE_CONFIG.php";
     String ADD_GROWER_DATA = "/Esurvey_22.1/post_grower_data.php";





}
