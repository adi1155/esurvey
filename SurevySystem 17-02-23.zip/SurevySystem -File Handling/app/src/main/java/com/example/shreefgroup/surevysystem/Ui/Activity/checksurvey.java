package com.example.shreefgroup.surevysystem.Ui.Activity;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonArrayRequest;
import com.example.shreefgroup.surevysystem.R;
import com.example.shreefgroup.surevysystem.Utils.AppController;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashSet;


public class checksurvey extends Activity {
    AppController application;
    String item;
    ArrayList<String> values = new ArrayList<String>();
    HashSet<String> hashSet = new HashSet<String>();
    ProgressDialog loading = null;
    ArrayList<String> arraylist = new ArrayList<String>();
    private ProgressDialog pDialog;
    private Object jsonResponse = "";
    private String middle3;
    private ListView list;
    private ArrayAdapter adapter;
    private String reg;
    public static InputStream is = null;
    public static JSONObject jObj = null;
    private String tv, tv2, tv3, tv4, tv5, tv6, tv7, tv8;
    ArrayList<String> arrayList5 = new ArrayList<String>();
    final static String path = AppController.getInstance().path + "/ESurvey" + "/";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checksurveyinfo);
        list = (ListView) findViewById(R.id.spinner1);
      //  application = (AppController) getApplicationContext();
        readfileSatting();
        for (int i = 0; i < arrayList5.size(); i++) {
            tv = arrayList5.get(0).toString();
            tv2 = arrayList5.get(1).toString();
            tv3 = arrayList5.get(2).toString();
            tv4 = arrayList5.get(3).toString();
            tv5 = arrayList5.get(4).toString();
            tv6 = arrayList5.get(5).toString();
            tv7 = arrayList5.get(6).toString();
            tv8 = arrayList5.get(7).toString();
            i = i + 8;
        }

        try {
            CheckVehicalRegistration(tv5);

        } catch (JSONException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        adapter = new ArrayAdapter<String>(this, R.layout.list_item2, R.id.UnitName, arraylist);
        list.setAdapter(adapter);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @TargetApi(Build.VERSION_CODES.M)
            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                item = parent.getItemAtPosition(position).toString();
                int parse=item.length();
                reg = item.substring(0,15);
                dilouge();


            }
        });

    }

    private void dilouge() {
        new AlertDialog.Builder(this)
                .setTitle("Delete entry")
                .setMessage("Are you sure you want to delete this entry?")
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        deleteData(reg);
                        finish();
                      startActivity(getIntent());
                       //list.invalidateViews();
                    }


                })
                .setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // do nothing

                    }
                })
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();

    }

    private void deleteData(String item) {
        pDialog = ProgressDialog.show(this, "Please wait...", "Deleting...", false, false);
        String url =application.baseUrl+application.DELETE_LIST_ITEM + "?CNIC_NO="+item.trim();
        final JsonArrayRequest req = new JsonArrayRequest(url,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        String rsponse=response.toString();
                        Toast.makeText(checksurvey.this, "Status:"+rsponse, Toast.LENGTH_SHORT).show();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d("volly", "Error: " + error.getMessage());
                Toast.makeText(getApplicationContext(),
                     error.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });
        pDialog.dismiss();
        AppController.getInstance().addToRequestQueue(req);

    }

    public void CheckVehicalRegistration(String sr_coed) throws JSONException, IOException {
        loading = new ProgressDialog(this);
        loading.setCancelable(true);
        loading.setMessage("Loading Please Wait");
        loading.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        loading.show();
        String URL = application.baseUrl+application.getsurvey_responce+"?SURVEYOR_CODE="+sr_coed.trim();
        JSONObject object = new JSONObject(String.valueOf((getJSONUrl(URL))));
        JSONArray Jarray = object.getJSONArray("Result");
        try {
            for (int i = 0; i < Jarray.length(); i++) {
                JSONObject jsonObject = Jarray.getJSONObject(i);
                String REGNO = jsonObject.getString("RES");

                jsonResponse = REGNO;
                arrayList11(REGNO);

            }


        } catch (JSONException e) {
            e.printStackTrace();

        }
        loading.cancel();

    }



    public JSONObject getJSONUrl(String url) throws IOException {

        URL url1 = new URL(url);
        String json ="";
        HttpURLConnection conn = (HttpURLConnection) url1.openConnection();
        is = (InputStream) conn .getContent();


        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(
                    is, "iso-8859-1"), 8);
            StringBuilder sb = new StringBuilder();
            String line = null;

            while ((line = reader.readLine()) != null) {
                sb.append(line + "\n");

            }

            is.close();
            json = sb.toString();

        } catch (Exception e) {
            Log.e("Buffer Error", "Error converting result " + e.toString());
        }

        // try parse the string to a JSON object
        try {
            jObj = new JSONObject(json);
        } catch (JSONException e) {
            Log.e("JSON Parser", "Error parsing data " + e.toString());


        }

        // return JSON String
        return jObj;

    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    public void arrayList11(String regno) {
        arraylist.add(regno);
    }
    public void readfileSatting() {


        File file = new File(path, "EsurveySettings");
        StringBuilder text = new StringBuilder();
        arrayList5.clear();
        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            String line;
            while ((line = br.readLine()) != null) {
                String lineWords[] = line.split(" ");
                for (String singleWord : lineWords) {
                    arrayList5.add(singleWord);

                }
            }
            br.close();
        } catch (IOException e) {
        }

    }
    @Override
    public void onBackPressed() {
        finish();
        startActivity(new Intent(checksurvey.this,MainActivity.class));
        super.onBackPressed();
    }
}

