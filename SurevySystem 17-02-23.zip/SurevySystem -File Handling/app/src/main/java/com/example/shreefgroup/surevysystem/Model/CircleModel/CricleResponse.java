package com.example.shreefgroup.surevysystem.Model.CircleModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class CricleResponse {

    @SerializedName("Result")
    @Expose
    private List<CircleResult> result = null;

    @SerializedName("status")
    @Expose
    private String status;

    public List<CircleResult> getResult() {
        return result;
    }

    public void setResult(List<CircleResult> result) {
        this.result = result;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
