
package com.example.shreefgroup.surevysystem.Model.Grower;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class GrowerModel {

    @SerializedName("GrowerResult")
    @Expose
    private List<GrowerResult> growerResult = null;
    @SerializedName("status")
    @Expose
    private String status;

    public List<GrowerResult> getGrowerResult() {
        return growerResult;
    }

    public void setGrowerResult(List<GrowerResult> growerResult) {
        this.growerResult = growerResult;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

}
