package com.example.shreefgroup.surevysystem.Adopter.GAdopter;

import android.content.Context;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.shreefgroup.surevysystem.Model.Grower.GrowerResult;
import com.example.shreefgroup.surevysystem.R;

import de.hdodenhof.circleimageview.CircleImageView;


public class GrowerViewHolder extends RecyclerView.ViewHolder  {



    public GrowerResult mTask;
    public  Context mContex;
    public TextView mName,mFatherName,mCast,mCnic,mPassbook,mCircle,mVillage,mCode;
   public Button mSurveyBtn;

    public CircleImageView image;




    public GrowerViewHolder(View itemView) {
        super(itemView);
        mContex = itemView.getContext();

        init();



/*
        mUrlPostView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String f = mTask.getDescription();
                Intent i = new Intent(mContex, UrlWebView.class);
                i.putExtra("value",f);
                mContex.startActivity(i);

                Toast.makeText(mContex,"view the url ",Toast.LENGTH_LONG).show();
            }
        });*/





    }



    private void init() {

       mName = itemView.findViewById(R.id.grower_item_name);
        mFatherName  = itemView.findViewById(R.id.grower_item_father_name);
        mCnic = itemView.findViewById(R.id.grower_item_cnic_no);
        mCast = itemView.findViewById(R.id.grower_item_cast);
        mCircle = itemView.findViewById(R.id.grower_item_circle);
        mVillage = itemView.findViewById(R.id.grower_item_village_name);
        mPassbook = itemView.findViewById(R.id.grower_item_passbook_no);
        mCode = itemView.findViewById(R.id.grower_item_code);
        image = itemView.findViewById(R.id.grower_item_image_view);
        mSurveyBtn = itemView.findViewById(R.id.item_view_new_survey);




    }





    public void bindTask(GrowerResult task) {
        mTask = task;


        if(mTask.getCircleCode()!=null){
            mCircle.setText(mTask.getCircleCode());
        }else {
            mCircle.setText("");
        }

        if(mTask.getGrowerCode()!=null){
            mCode.setText(mTask.getGrowerCode());
        }else {
            mCode.setText("");
        }

        if(mTask.getPassbookNo()!=null){
            mPassbook.setText(mTask.getPassbookNo());
        }else {
            mPassbook.setText("");
        }

        if(mTask.getGrowerFName()!=null){
            mFatherName.setText(mTask.getGrowerFName());
        }else {
            mFatherName.setText("");
        }

        if(mTask.getGrowerCnic()!=null){
            mCnic.setText(mTask.getGrowerCnic());
        }else {
            mCnic.setText("");
        }

        if(mTask.getVillageCode()!=null){
            mVillage.setText(mTask.getVillageCode());
        }else {
            mVillage.setText("");
        }
        if(mTask.getGrowerCaste()!=null){
            mCast.setText(mTask.getGrowerCaste());
        }else {
            mCast.setText("");
        }

        if(mTask.getGrowerName()!=null){
            mName.setText(mTask.getGrowerName());
        }else {
            mName.setText("");
        }

        String img1 = task.getmFile();

                Glide.with(mContex).
                        load(img1)
                        .error(R.drawable.survey)
                        .into(image);




    }









}

