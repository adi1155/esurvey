package com.example.shreefgroup.surevysystem.Ui.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.shreefgroup.surevysystem.Model.CircleModel.CircleResult;
import com.example.shreefgroup.surevysystem.Model.CircleModel.CricleResponse;
import com.example.shreefgroup.surevysystem.Model.MobileModel.MobileResponse;
import com.example.shreefgroup.surevysystem.Model.MobileModel.MobileResult;
import com.example.shreefgroup.surevysystem.Model.ResponseModel.ResultResponse;
import com.example.shreefgroup.surevysystem.Model.UnitModel.UnitResponse;
import com.example.shreefgroup.surevysystem.Model.UnitModel.UnitResult;
import com.example.shreefgroup.surevysystem.Model.UserModel.UserResponse;
import com.example.shreefgroup.surevysystem.Model.UserModel.UserResult;
import com.example.shreefgroup.surevysystem.Network.ServerCallback;
import com.example.shreefgroup.surevysystem.Network.ServerError;
import com.example.shreefgroup.surevysystem.Network.ServerTask;
import com.example.shreefgroup.surevysystem.R;
import com.example.shreefgroup.surevysystem.Utils.Constants;
import com.example.shreefgroup.surevysystem.Utils.NetworkUtil;
import com.isapanah.awesomespinner.AwesomeSpinner;
import com.preference.PowerPreference;

import java.util.ArrayList;
import java.util.List;

import me.impa.pinger.PingInfo;
import me.impa.pinger.Pinger;
import retrofit2.Call;

public class SettingActivity extends AppCompatActivity {

    EditText mBaseUrl,mUUID,mPortNumber;
    String mC_url , mC_UUId,mC_port_number;
    Button mSend,mBack;

    AwesomeSpinner mUnitSpinner,mUserSpinner,mMobileSpinner,mCircleSpinner;
    public  String  mUnitId ="",mUserID ="",mMobileDevice="",mCircleCode="";


    List<UnitResult> mUnitList = new ArrayList<>();
    List<UserResult> mUserList = new ArrayList<>();
    List<CircleResult> mCircleList = new ArrayList<>();
    List<MobileResult> mMobileList = new ArrayList<>();



    String  DeviceId="00";


    String role="";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);

        mBaseUrl = findViewById(R.id.setting_base_url);
        mBaseUrl.setText("scorpio.sgroup.pk");
        pingIp("scorpio.sgroup.pk");
        mUUID = findViewById(R.id.setting_uuid);
        mUUID.setEnabled(false);
        mPortNumber = findViewById(R.id.setting_port);
        mPortNumber.setText("8085");

        mUnitSpinner =  findViewById(R.id.setting_unit_spinner);
        mUserSpinner =  findViewById(R.id.setting_user_spinner);
        mMobileSpinner =  findViewById(R.id.setting_mobile_spinner);
        mCircleSpinner =  findViewById(R.id.setting_circle_spinner);
        mSend = findViewById(R.id.setting_send);
        mBack = findViewById(R.id.setting_back_btn);


        getDeviceId();

        mUUID.setText(DeviceId);


        mBaseUrl.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                if (NetworkUtil.isNetworkAvailable(SettingActivity.this)) {

                    final Handler handler = new Handler(Looper.getMainLooper());
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            pingIp(s.toString());
                        }
                    }, 4000);
                } else {
                    showAlert("NO Internet available");

                }
            }
        });



        mUnitSpinner.setOnSpinnerItemClickListener((position, itemAtPosition) -> {

            try {
                mUnitId = mUnitList.get(position).getBUnitId();

                if(!mUnitId.equals("")){
                    Log.d("new_",mUnitId);
                    if(NetworkUtil.isNetworkAvailable(getApplicationContext())) {

                        mCircleSpinner.clearSelection();
                        mUserSpinner.clearSelection();
                        mMobileSpinner.clearSelection();
                        mMobileDevice="";
                        mUserID ="";
                        mCircleCode = "";
                        getUserList(mUnitId,"124");
                        getCircleList(mUnitId,"124");



                    }else {
                        Toast.makeText(SettingActivity.this, "No Internet Available", Toast.LENGTH_SHORT).show();
                      }
                }
            }catch (Exception e){e.printStackTrace();}
        });


        mUserSpinner.setOnSpinnerItemClickListener((position, itemAtPosition) -> {

            try {
                mUserID = mUserList.get(position).getUserId();

                if(!mUserID.equals("")){

                    if(NetworkUtil.isNetworkAvailable(getApplicationContext())) {

                        getMobileList(mUnitId);

                    }else {
                        Toast.makeText(SettingActivity.this, "NO Internet Available", Toast.LENGTH_SHORT).show();

                    }

                }
            }catch (Exception e){e.printStackTrace();}

        });

        mMobileSpinner.setOnSpinnerItemClickListener((position, itemAtPosition) -> {
            try {
                mMobileDevice = mMobileList.get(position).getDeviceId();
            }catch (Exception e){e.printStackTrace();}
        });



        mCircleSpinner.setOnSpinnerItemClickListener((position, itemAtPosition) -> {
            try {
                mCircleCode = mCircleList.get(position).getLookupCode();
            }catch (Exception e){e.printStackTrace();}
        });

        mSend.setOnClickListener(view -> {

            if (!validate()) {
                onLoginFailed();
                return;
            }
            boolean ss = PowerPreference.getDefaultFile().getBoolean(Constants.PING_SUCCESS,false);
            if(ss ==false){

                showAlert("please verified Base URl First");
            }else{
                if(NetworkUtil.isNetworkAvailable(getApplicationContext())) {

                    settingAPI();
                }else {
                    Toast.makeText(this, "No InterNet Available", Toast.LENGTH_SHORT).show();
                       }
            }
        });




    }

    public void onLoginFailed() {
        Toast.makeText(getApplicationContext(), "Please Check the Empty Columns", Toast.LENGTH_LONG).show();
    }


    private void pingIp(String toString) {


        Pinger pinger = new Pinger();
        pinger.setOnPingListener(new Pinger.OnPingListener() {

            @Override
            public void OnStart(@NonNull PingInfo pingInfo) {

                //   Toasty.info(getApplicationContext(),"ping start ").show();
                Log.i("PING", String.format("Pinging %s [%s]", pingInfo.ReverseDns, pingInfo.RemoteIp));

            }

            @Override
            public void OnStop(@NonNull PingInfo pingInfo) {
                Log.i("PING", "Ping complete");
                PowerPreference.getDefaultFile().setBoolean(Constants.PING_SUCCESS, true);
                getUnitList();



            }

            @Override
            public void OnSendError(@NonNull PingInfo pingInfo, int sequence) {
                //    Toasty.error(getApplicationContext(),"ping error ").show();

            }

            @Override
            public void OnReplyReceived(@NonNull PingInfo pingInfo, int sequence, int timeMs) {


                Log.i("PING",  String.format("#%d: Reply from %s: bytes=%d time=%d TTL=%d", sequence, pingInfo.RemoteIp, pingInfo.Size, timeMs, pingInfo.Ttl));


                if (sequence >= 3) {
                    pingInfo.Pinger.Stop(pingInfo.PingId);
                }
            }

            @Override
            public void OnTimeout(@NonNull PingInfo pingInfo, int sequence) {
                Log.i("PING", String.format("#%d: Timeout!", sequence));

                if (sequence >= 3)
                    pingInfo.Pinger.Stop(pingInfo.PingId);

            }

            @Override
            public void OnException(@NonNull PingInfo pingInfo, @NonNull Exception e, boolean isFatal) {

            }
        });
        pinger.Ping(toString);
    }


    private void showAlert(String msg) {

        try {
            AlertDialog.Builder builder = new AlertDialog.Builder(SettingActivity.this);
            builder.setTitle("الیکٹرانک لوڈنگ پوائنٹ")
                    .setMessage(msg)
                    .setCancelable(false)
                    .setPositiveButton("ٹھیک ہے", (dialog, id) -> {

                        finish();

                    });
            AlertDialog alert = builder.create();
            alert.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @SuppressLint("HardwareIds")
    private void getDeviceId() {
        DeviceId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
    }


    public boolean validate() {
        boolean valid = true;

        mC_url = mBaseUrl.getText().toString();
        mC_UUId = mUUID.getText().toString();
        mC_port_number = mPortNumber.getText().toString();

        if (mC_url.isEmpty()) {
            mBaseUrl.setError("Please enter the Base Url");
            valid = false;
        } else {
            mBaseUrl.setError(null);
        }

        if (mC_port_number.isEmpty()) {
            mPortNumber.setError(" Please enter the Port Number ");
            valid = false;
        } else {
            mPortNumber.setError(null);
        }


        return valid;
    }



    private void settingAPI(){

        Call<ResultResponse> getAPIData = ServerTask.getInstance().getServices().add_config(mC_url,mUnitId,mUserID,mMobileDevice,"124",mCircleCode,mC_UUId);


        getAPIData.enqueue(new ServerCallback<>() {
            @Override
            public void onFailure(ServerError restError) {
                //   mProgressDialog.dismiss();
            }

            @Override
            public void onSuccess(retrofit2.Response<ResultResponse> response) {

            }

            @Override
            public void onResponse(retrofit2.Response<ResultResponse> response) {


                try {

                    assert response.body() != null;
                    String status = response.body().getStatus();


                    if (status.equals("0")) {



                        PowerPreference.getDefaultFile().setBoolean(Constants.SETTING_SCREEN,true);
                        PowerPreference.getDefaultFile().setString(Constants.BASE_URL_NEW,"http://"+mC_url+ ":"+mC_port_number);
                        PowerPreference.getDefaultFile().setString(Constants.USER_UNIT,mUnitId);
                        PowerPreference.getDefaultFile().setString(Constants.DEVICE_ID,mMobileDevice);
                        PowerPreference.getDefaultFile().setString(Constants.USER_ID,mUserID);
                        PowerPreference.getDefaultFile().setString(Constants.CIRCLE_CODE,mCircleCode);




                        Intent i = new Intent(getApplicationContext(), MainActivity.class);
                        startActivity(i);
                        finish();


                    } else {
                        Toast.makeText(SettingActivity.this, response.body().getResult(), Toast.LENGTH_SHORT).show();
                    }


                } catch (Exception e) {
                    Toast.makeText(SettingActivity.this, "No crash  Found", Toast.LENGTH_SHORT).show();
                    e.printStackTrace();
                }
            }
        });
    }


    private void getUnitList(){

        Call<UnitResponse> getUnits = ServerTask.getInstance().getServices().get_unit("124");
        getUnits.enqueue(new ServerCallback<UnitResponse>() {
            @Override
            public void onFailure(ServerError restError) {}
            @Override
            public void onSuccess(retrofit2.Response<UnitResponse> response) {}
            @Override
            public void onResponse(retrofit2.Response<UnitResponse> response) {

                String result = response.body().getStatus();

                try{
                    mUnitList.clear();
                   /* if(!role.equals("admin")) {
                        mUnitId = "";
                    }*/
                    List<String> categories = new ArrayList<String>();

                    categories.add("");
                    ArrayAdapter<String> lpAdopter = new
                            ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_item, categories);

                    mUnitSpinner.setAdapter(lpAdopter);


                }catch ( Exception e){e.printStackTrace();}

                if(result.equals("true")){

                    mUnitList.clear();
                   /* if(!role.equals("admin")) {
                        mUnitId = "";
                    }*/

                    mUnitList = response.body().getResult();

                    List<String> categories = new ArrayList<String>();

                    for(int  i = 0 ; i<mUnitList.size(); i++) {
                        categories.add(mUnitList.get(i).getBUnitDesc());
                    }


                    ArrayAdapter<String> categoriesAdapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_item, categories);
                    mUnitSpinner.setAdapter(categoriesAdapter);

             //       if(role.equals("admin")){

                        for(int i  = 0 ; i<mUnitList.size(); i++){
                            String uId =  mUnitList.get(i).getBUnitId();

                            if(uId.equals(mUnitId)){
                                mUnitSpinner.setSelection(i);
                            }
                     //   }

                    }

                }
            }
        });
    }



    private void getUserList(String unitId,String app_id){



        Call<UserResponse> getLpResponse = ServerTask.getInstance().getServices().get_user(app_id,unitId);


        getLpResponse.enqueue(new ServerCallback<UserResponse>() {
            @Override
            public void onFailure(ServerError restError) {
                //   mProgressDialog.dismiss();
            }

            @Override
            public void onSuccess(retrofit2.Response<UserResponse> response) {

            }

            @Override
            public void onResponse(retrofit2.Response<UserResponse> response) {

                String result = response.body().getStatus();

/*
                try{
                    mUserList.clear();
                    List<String> categories = new ArrayList<String>();

                    categories.add("");
                    ArrayAdapter<String> lpAdopter = new
                            ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_item, categories);

                    mUserSpinner.setAdapter(lpAdopter);
                }catch ( Exception e){e.printStackTrace();}

                */

                if(result.equals("true")){

                    mUserList.clear();
                 /*   if(!role.equals("admin")) {
                        mLPCode = "";
                    }*/
                    mUserList = response.body().getResult();

                    List<String> categories = new ArrayList<String>();

                    for(int  i = 0 ; i<mUserList.size(); i++) {
                        categories.add(mUserList.get(i).getUserLogin());


                    }

                    ArrayAdapter<String> lpAdopter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_item, categories);

                    mUserSpinner.setAdapter(lpAdopter);

/*

                 //   if(role.equals("admin")){
                        for(int i  = 0 ; i<mUserList.size(); i++){
                            String uId =  mUserList.get(i).getUserId();

                            try {
                                if (uId.equals(mUserID)) {
                                    mUserSpinner.setSelection(i);
                                }

                            }catch (Exception e){e.printStackTrace();}
                  //      }
*/

               //     }

                }



            }
        });
    }



    private void getMobileList(String unitId){



        Call<MobileResponse> getLpResponse = ServerTask.getInstance().getServices().get_mobile(unitId);


        getLpResponse.enqueue(new ServerCallback<>() {
            @Override
            public void onFailure(ServerError restError) {
                //   mProgressDialog.dismiss();
            }

            @Override
            public void onSuccess(retrofit2.Response<MobileResponse> response) {

            }

            @Override
            public void onResponse(retrofit2.Response<MobileResponse> response) {

                String result = response.body().getStatus();


             /*   try {
                    mMobileList.clear();
                   *//* if(!role.equals("admin")) {
                        mLPCode = "";
                    }*//*
                    List<String> categories = new ArrayList<String>();

                    categories.add("");
                    ArrayAdapter<String> lpAdopter = new
                            ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_item, categories);

                    mMobileSpinner.setAdapter(lpAdopter);
                } catch (Exception e) {
                    e.printStackTrace();
                }*/

                if (result.equals("true")) {

                    mMobileList.clear();
                    mMobileList = response.body().getResult();

                    List<String> categories = new ArrayList<>();


                    for (int i = 0; i < mMobileList.size(); i++) {
                        categories.add(mMobileList.get(i).getMobileModel());


                    }

                    ArrayAdapter<String> lpAdopter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_item, categories);

                    mMobileSpinner.setAdapter(lpAdopter);

/*
                    //   if(role.equals("admin")){
                    for (int i = 0; i < mMobileList.size(); i++) {
                        String uId = mMobileList.get(i).getDeviceId();

                        try {
                            if (uId.equals(mMobileDevice)) {
                                mMobileSpinner.setSelection(i);
                            }

                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        //      }

                    }*/

                }


            }
        });
    }


    private void getCircleList(String unitId,String app_id){



        Call<CricleResponse> getLpResponse = ServerTask.getInstance().getServices().get_circle(app_id,unitId);


        getLpResponse.enqueue(new ServerCallback<CricleResponse>() {
            @Override
            public void onFailure(ServerError restError) {
                //   mProgressDialog.dismiss();
            }

            @Override
            public void onSuccess(retrofit2.Response<CricleResponse> response) {

            }

            @Override
            public void onResponse(retrofit2.Response<CricleResponse> response) {

                String result = response.body().getStatus();

/*
                try{
                    mCircleList.clear();
                   *//* if(!role.equals("admin")) {
                        mLPCode = "";
                    }*//*
                    List<String> categories = new ArrayList<String>();

                    categories.add("");
                    ArrayAdapter<String> lpAdopter = new
                            ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_item, categories);

                    mCircleSpinner.setAdapter(lpAdopter);
                }catch ( Exception e){e.printStackTrace();}*/

                if(result.equals("true")){

                    mCircleList.clear();
                 /*   if(!role.equals("admin")) {
                        mLPCode = "";
                    }*/
                    mCircleList = response.body().getResult();

                    List<String> categories = new ArrayList<String>();
                    int postion =0 ;

                    for(int  i = 0 ; i<mCircleList.size(); i++) {
                        categories.add(mCircleList.get(i).getDescription());


                    }

                    ArrayAdapter<String> lpAdopter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_item, categories);

                    mCircleSpinner.setAdapter(lpAdopter);


                    //   if(role.equals("admin")){
                    for(int i  = 0 ; i<mCircleList.size(); i++){
                        String uId =  mCircleList.get(i).getLookupCode();

                        try {
                            if (uId.equals(mCircleCode)) {
                                mMobileSpinner.setSelection(i);
                            }

                        }catch (Exception e){e.printStackTrace();}
                        //      }

                    }

                }



            }
        });
    }




}