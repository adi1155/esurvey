package com.example.shreefgroup.surevysystem.Model;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.example.shreefgroup.surevysystem.Ui.Activity.SplashScreen;
import com.example.shreefgroup.surevysystem.DataBase.DatabaseHelper;
import com.example.shreefgroup.surevysystem.Utils.AppController;
import com.example.shreefgroup.surevysystem.Utils.Constants;
import com.google.gson.Gson;
import com.preference.PowerPreference;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * Created by Ashfaq.Ahmed on 3/15/2018.
 */

public class Savedata {
    private final Context context;
    private final DatabaseHelper db_helper;
    private final int record;
    ArrayList<String> arrayList5 = new ArrayList<String>();
     String textv17, textv19, textv18, textv20, textv21, textv22,textv23;
     String textv, textv2, textv3, textv4, textv5, textv6, textv7, textv8, textv9, textv10, textv11,
            textv12, textv13, textv14, textv15, textv16;
    private String srv_id;
    private int count = 0;

    public Savedata(Context context) {

        this.context = context;
        db_helper = new DatabaseHelper(context);
        record = db_helper.getItemsCount();

    }

    public void save_data(String srv_id, String textv, String textv2, String textv3,
                          String textv4, String textv5, String textv6, String textv7,
                          String textv8, String textv9, String textv10, String textv11,
                          String textv12, String textv13, String textv14,
                          String textv15, String textv16,
                          String textv17, String textv18, String textv19,
                          String textv20, String textv21, String textv22, String textv23) throws IOException {


        final String cell = "";
        final String SurveyorCode = PowerPreference.getDefaultFile().getString(Constants.USER_ID,"");
        final String Companycode = PowerPreference.getDefaultFile().getString(Constants.USER_UNIT,"");
        final String srvid = srv_id.toString();
        final String Surveytaype = textv.toString();
        final String NIC = textv3.toString();
        final String Grower_code = textv4.toString();
        final String Grower_name = textv5.toString();
        final String father_name = textv6.toString();
        final String Caste = textv7.toString();
        final String circle = textv8.toString();
        final String village = textv9.toString();
        final String T_acreage = textv10.toString();
        final String T_yield = textv11.toString();
        final String Killa = textv12.toString();
        final String Sqr_No = textv13.toString();
        final String sowing_distance = textv14.toString();
        final String crop_condition = textv15.toString();
        final String variety = textv16.toString();
        final String plantation = textv17.toString();
        final String Note = textv18.toString();
        final String imei = textv2.toString();
        final String totalArea = textv23.toString();
        final String mfilename, mfilename2, mfilename3, mfilename4;
        if (textv19 != null) {
            mfilename = textv19.toString();
        } else {
            mfilename = "Nofile";

        }
        if (textv20 != null) {
            mfilename2 = textv20.toString();
        } else {
            mfilename2 = "Nofile";

        }
        if (textv21 != null) {
            mfilename3 = textv21.toString();
        } else {
            mfilename3 = "Nofile";

        }
        if (textv22 != null) {
            mfilename4 = textv22.toString();
        } else {
            mfilename4 = "Nofile";

        }
        String url4 = AppController.baseUrl + AppController.URL2;

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url4,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        Log.d("response",response);




;
                        Gson gson = new Gson();
                        SurveyModel   data= gson.fromJson(response,SurveyModel.class);
                        String    temp_id = data.getResult();

                        db_helper.INSERT_FLAG(new Master("Yes", srvid));
                        count++;
                        Toast.makeText(context, "Master data inserting plz wait...", Toast.LENGTH_SHORT).show();
                        continou();
                        if (count == record) {
                            gpsinsertion(temp_id);
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (volleyError.networkResponse == null) {
                            if (volleyError.getClass().equals(TimeoutError.class)) {
                                Toast.makeText(context, "Oops. Network Timeout error!", Toast.LENGTH_LONG).show();
                            }
                        }
                    }
                }) {


            @Override

            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put(AppController.KEY_survey_id, srvid);
                params.put(AppController.KEY_CompanyCode, Companycode);
                params.put(AppController.KEY_SurveyorCode, SurveyorCode);
                params.put(AppController.KEY_Survey_type, Surveytaype);
                params.put(AppController.KEY_Grower_code, Grower_code);
                params.put(AppController.KEY_KPI_CELLID, cell);
                params.put(AppController.KEY_file, mfilename);
                params.put(AppController.KEY_file2, mfilename2);
                params.put(AppController.KEY_file3, mfilename3);
                params.put(AppController.KEY_file4, mfilename4);
                params.put(AppController.KEY_IME, imei);
                params.put(AppController.KEY_NIC, NIC);
                params.put(AppController.KEY_Name, Grower_name);
                params.put(AppController.KEY_Father_name, father_name);
                params.put(AppController.KEY_Caste, Caste);
                params.put(AppController.KEY_Circle, circle);
                params.put(AppController.KEY_Village, village);
                params.put(AppController.KEY_Totale_Acreage, T_acreage);
                params.put(AppController.KEY_Total_yield, T_yield);
                params.put(AppController.KEY_Killa, Killa);
                params.put(AppController.KEY_Suqure_No, Sqr_No);
                params.put(AppController.KEY_Crop_Condition, crop_condition);
                params.put(AppController.KEY_Variety, variety);
                params.put(AppController.KEY_Plantation, plantation);
                params.put(AppController.KEY_Note, Note);
                params.put(AppController.KEY_MPP_AERA_MOB, totalArea);


                params.put(AppController.KEY_sowing_distance, sowing_distance);

                return params;
            }

        };

        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                50000,
                50000,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        AppController.getInstance().addToRequestQueue(stringRequest, "Tag");

    }

    public void continou() {
        int record = db_helper.getItemsCount();
        List<Master> A = db_helper.getAll_Master();
        for (Master obj : A) {
            srv_id = obj.get_mob_id();
            textv = obj.get_survey_type();
            textv2 = obj.get_cnic();
            textv3 = obj.get_Grower_code();
            textv4 = obj.get_name();
            textv5 = obj.get_father_name();
            textv6 = obj.get_cast();
            textv7 = obj.get_circle();
            textv8 = obj.get_village();
            textv9 = obj.get_acrage();
            textv10 = obj.get_yield();
            textv11 = obj.get_killa();
            textv12 = obj.get_sqr_no();
            textv13 = obj.get_sowing();
            textv14 = obj.get_crop_cond();
            textv15 = obj.get_veriety();
            textv16 = obj.get_plantation();
            textv17 = obj.get_note();
            textv18 = obj.get_imei();
            textv19 = obj.get_filename();
            textv20 = obj.get_filename2();
            textv21 = obj.get_filename3();
            textv22 = obj.get_filename4();
            textv23 = obj.getTotalArea();
            try {
                save_data(srv_id,
                        textv,//mobid
                        textv2,//type
                        textv3,//imei
                        textv4,//cnic
                        textv5,//code
                        textv6,//name
                        textv7,//father
                        textv8,//cast
                        textv9,//circle
                        textv10,//village
                        textv11,//acrage
                        textv12,//yield
                        textv13,//killa
                        textv14,//sqr
                        textv15,//swing
                        textv16,//cond
                        textv17,//veriety
                        textv18,//note
                        textv19,//img
                        textv20,//img
                        textv21, textv22,textv23);
            } catch (IOException e) {
                e.printStackTrace();
            }
            break;
        }
    }

    public void Save_GPS(String serial_id, String mobID, String latitude1, String longitude1, String imei, String timestamp  ,String  SurveryId) throws IOException {



        final String company_code =  PowerPreference.getDefaultFile().getString(Constants.USER_UNIT,"");
        final String sr_id = String.valueOf(serial_id);
        final String mob_id = mobID.toString();
        final String lat_1 = latitude1.toString();
        final String long_1 = longitude1.toString();
        final String imei_no = imei.toString();
        final String timestampp = timestamp.toString();
        final String t_value  = SurveryId.trim().toString();

      //  final String
        String url_gps = AppController.baseUrl + AppController.GetGps;

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url_gps,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.d("response",response);

                        db_helper.INSERT_FLAG2(new GPS("Yes", mob_id, sr_id));
                        gpsinsertion(t_value);
                        Toast.makeText(context, "Inserting please wait...", Toast.LENGTH_SHORT).show();


                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (volleyError.networkResponse == null) {
                            Log.d("response",volleyError.toString());
                            if (volleyError.getClass().equals(TimeoutError.class)) {
                                Toast.makeText(context, "Oops. Network Timeout error!", Toast.LENGTH_LONG).show();
                            }
                        }
                    }
                }) {

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put(AppController.KEY_CompanyCode, company_code);
                params.put(AppController.KEY_LAT, lat_1);
                params.put(AppController.KEY_LNG, long_1);
                params.put(AppController.KEY_survey_id, t_value);
                params.put("MOB_ID", mob_id);
                params.put(AppController.KEY_IMEI_NO, imei_no);
                params.put(AppController.KEY_id, sr_id);
                params.put(AppController.KEY_date, timestampp);
                return params;
            }

        };
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                50000,
                50000,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        MySingleton.getInstance(context).addToRequestQueue(stringRequest);


    }

    public void gpsinsertion(String tempId) {
        try {
            List<GPS> B = db_helper.get_AllGPS();//6
            for (GPS ob : B) {
                String serial_id = ob.get_serial();
                String surveyid = ob.get_mob_id();
                String longitude1 = ob.get_Lat();
                String latitude1 = ob.get_lang();
                String imei = ob.get_imei();
                String timestamp = ob.get_Tran_date();
                Save_GPS(serial_id, surveyid, latitude1, longitude1, imei, timestamp, tempId);
                break;

            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }



}
