package com.example.shreefgroup.surevysystem.Adopter.GAdopter;

import android.content.Context;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.RecyclerView;


import com.example.shreefgroup.surevysystem.Model.Grower.GrowerResult;
import com.example.shreefgroup.surevysystem.R;

import java.util.List;


public class GrowerAdopter extends RecyclerView.Adapter<GrowerViewHolder>{

      List<GrowerResult> mObjectList;
    Context mContex;

    public GrowerAdopter(List<GrowerResult> mObjectList){
        this.mObjectList=mObjectList;
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void onBindViewHolder(GrowerViewHolder holder, int position) {
        GrowerResult task = mObjectList.get(position);
        holder.bindTask(task);

    }

    @Override
    public int getItemCount() {
        return mObjectList.size();
    }

    @Override
    public long getItemId(int position) {
        return position;
    }


    @Override
    public int getItemViewType(int position) {
        return position;
    }

    @NonNull
    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public GrowerViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater;
        inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.grower_item_view, parent, false);
        return new GrowerViewHolder(view);


    }

    /*
     * Method required to update list if new data is fetched or added to list
     * */
    public void updateList(List<GrowerResult> list){
        mObjectList.addAll(list);
    }
}