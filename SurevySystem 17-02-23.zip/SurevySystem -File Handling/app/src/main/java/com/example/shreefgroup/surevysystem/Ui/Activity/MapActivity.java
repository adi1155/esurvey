package com.example.shreefgroup.surevysystem.Ui.Activity;

import static com.example.shreefgroup.surevysystem.Ui.Activity.TakeSurveyActivity.json;
import static com.example.shreefgroup.surevysystem.Ui.Activity.checksurvey.jObj;

import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.example.shreefgroup.surevysystem.R;
import com.example.shreefgroup.surevysystem.Utils.AppController;
import com.example.shreefgroup.surevysystem.Utils.FileHelper_Settings;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polygon;
import com.google.android.gms.maps.model.PolygonOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.maps.android.SphericalUtil;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.osmdroid.api.IGeoPoint;
import org.osmdroid.util.GeoPoint;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentActivity;

public class MapActivity extends FragmentActivity implements
        GoogleMap.OnMapClickListener, GoogleMap.OnMarkerClickListener, OnMapReadyCallback {
    final static String fileSID = "SURVEY_ID";
    final static String path = AppController.getInstance().path + "/ESurvey" + "/";
    final static String TAG = FileHelper_Settings.class.getName();
    List<LatLng> latLngs = new ArrayList<>();
    ArrayList<String> arrayList = new ArrayList<String>();
    GoogleMap googleMap;
    ArrayList<String> survey_id = new ArrayList<String>();
    ArrayList listPoints = new ArrayList();
    boolean isGeometryClosed = false;
    Polygon polygon;
    Context context = MapActivity.this;
    boolean isStartGeometry = false;
    private AppController application;
    private String lat, lng;
    private double Lat1, Lng1;
    private String s_id;
    private GoogleMap map;
    private GoogleApiClient client;
    private boolean checkClick = false;

    public String ReadFile(Context context) {
        String line = null;
        survey_id.clear();
        try {
            FileInputStream fileInputStream = new FileInputStream(new File(path + fileSID));
            InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream);
            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
            StringBuilder stringBuilder = new StringBuilder();

            while ((line = bufferedReader.readLine()) != null) {
                survey_id.add(line);
                stringBuilder.append(line + System.getProperty("line.separator"));
            }
            fileInputStream.close();
            line = stringBuilder.toString();

            bufferedReader.close();
        } catch (FileNotFoundException ex) {
            Log.d(TAG, ex.getMessage());
        } catch (IOException ex) {
            Log.d(TAG, ex.getMessage());
        }
        return line;
    }

    @SuppressLint("ObsoleteSdkInt")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_newpopup);
        ReadFile(MapActivity.this);
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        int Width = dm.widthPixels;
        int height = dm.heightPixels;
        try {
            initilizeMap();
            ActionBar actionBar = this.getActionBar();
            if (actionBar != null) {
                actionBar.setDisplayHomeAsUpEnabled(true);
            }
            assert actionBar != null;
            actionBar.setDisplayShowCustomEnabled(true);
            actionBar.setDisplayShowTitleEnabled(true);
            //  actionBar.setIcon(R.drawable.common_google_signin_btn_icon_dark);
        } catch (Exception e) {
            String ee = e.getMessage();
            // Toast.makeText(this, ee,
            //       Toast.LENGTH_SHORT).show();
        }


        getWindow().setLayout((int) (Width * 1), (int) (height * 1));
        if (Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }

        application = (AppController) getApplicationContext();
        try {
            get_GPS();
        } catch (JSONException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        for (int i = 0; i < arrayList.size(); i++) {
            if (arrayList.indexOf(0) != 0) {
                String l1 = arrayList.get(i).toString();
                Lat1 = Double.parseDouble(l1);
                Lng1 = Double.parseDouble(arrayList.get(i+1).toString());
                i=i+1;
                latLngs.add(new LatLng(Lat1, Lng1));

            }
        }
        SupportMapFragment fm = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        fm.getMapAsync(this);
        googleMap.setMapType(GoogleMap.MAP_TYPE_SATELLITE);

        Draw_Map();
    }

    private void get_GPS() throws JSONException, IOException {
        for (int i = 0; i < survey_id.size(); i++) {
            if (survey_id.indexOf(0) != 0) {
                s_id = survey_id.get(0).toString();
            }
            i = i + 1;
        }
        String url_gps = AppController.baseUrl + AppController.gps.trim() + "?SURVEY_ID=" + s_id.toString().trim();
        try {
            JSONObject object = new JSONObject(String.valueOf((getJSONUrl(url_gps))));
            JSONArray Jarray = object.getJSONArray("Result");
            for (int i = 0; i < Jarray.length(); i++) {
                JSONObject jsonObject = Jarray.getJSONObject(i);
                lat = jsonObject.getString("GPS_LATITUDE");
                lng = jsonObject.getString("GPS_LONGITUDE");
                arrayList.add(lat);
                arrayList.add(lng);

            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public JSONObject getJSONUrl(String url1) throws IOException {
        URL url = new URL(url1);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        InputStream is = (InputStream) conn.getContent();
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(
                    is, "iso-8859-1"), 8);
            StringBuilder sb = new StringBuilder();
            String line = null;
            while ((line = reader.readLine()) != null) {
                sb.append(line + "\n");
            }
            is.close();
            json = sb.toString();
        } catch (Exception e) {
            Log.e("Buffer Error", "Error converting result " + e.toString());
        }

        // try parse the string to a JSON object
        try {
            jObj = new JSONObject(json);
        } catch (JSONException e) {
            Log.e("JSON Parser", "Error parsing data " + e.toString());
        }

        // return JSON String
        return jObj;

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.map_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_normal:
                googleMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
                return true;
            case R.id.action_hybrid:
                googleMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);
                return true;
            case R.id.action_satellite:
                googleMap.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }


    @Override
    public void onStart() {
        super.onStart();
        client.connect();

    }

    @Override
    public void onStop() {
        super.onStop();

        client.disconnect();
    }

    private void initilizeMap() {
        if (googleMap == null) {
            ((MapFragment) getFragmentManager().findFragmentById(R.id.map)).getMapAsync(this);
            if (googleMap == null) {
                Toast.makeText(this, "Sorry! unable to create maps",
                        Toast.LENGTH_SHORT).show();
                return;
            }
            googleMap.getUiSettings().setMyLocationButtonEnabled(true); // set my location
            if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                return;
            }
            map.setTrafficEnabled(true);
            map.setIndoorEnabled(true);
            map.setBuildingsEnabled(true);
            googleMap.setMyLocationEnabled(true);
            googleMap.getUiSettings().setCompassEnabled(false);
            googleMap.getUiSettings().setRotateGesturesEnabled(false);
            // set zooming controll
            googleMap.getUiSettings().setZoomControlsEnabled(true);
            googleMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);
            googleMap.setOnMapClickListener(this);
        }
    }

    public void Draw_Map() {
        googleMap.clear();
        googleMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);
        MarkerOptions markerOptions = new MarkerOptions();
        // markerOptions.title("Position");
        markerOptions = new MarkerOptions();
        markerOptions.position(new LatLng(Lat1, Lng1));
        markerOptions.title("Position");
        double distance = SphericalUtil.computeArea(latLngs) * 0.000247105;
        markerOptions.snippet("Area:" + distance);
        googleMap.addMarker(markerOptions);
        PolygonOptions rectOptions = new PolygonOptions();
        rectOptions.addAll(latLngs);
        rectOptions.strokeColor(Color.BLUE);
        //rectOptions.fillColor(Color.CYAN);
        rectOptions.strokeWidth(7);
        polygon = googleMap.addPolygon(rectOptions);
        googleMap.getProjection().getVisibleRegion();

        // googleMap.animateCamera( CameraUpdateFactory.zoomTo( 7.0f ) );
        googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(Lat1, Lng1), 17));
        // clearCanvas(view);

    }

    @Override
    protected void onResume() {
        super.onResume();

    }

    /**
     * Close the Polygon / join last point to first point
     *
     * @param view
     */
    public void closePolygon(View view) {
        if (latLngs.size() > 0) {
            Draw_Map();
            isGeometryClosed = true;
            isStartGeometry = false;
        }
    }

    /**
     * Close the Polygon / join last point to first point
     *
     * @param view
     */

    public void startDrawing(View view) {
        isStartGeometry = true;
    }

    @Override
    public void onMapClick(LatLng latlan) {
        if (!isGeometryClosed && isStartGeometry) {
            latLngs.add(latlan);
            GeoPoint point = new GeoPoint(latlan.latitude, latlan.longitude);
            listPoints.add((IGeoPoint) point);
            MarkerOptions marker = new MarkerOptions().position(latlan);
            googleMap.addMarker(marker);
            if (latLngs.size() > 1) {
                PolylineOptions polyLine = new PolylineOptions().color(
                        Color.BLUE).width((float) 7.0);
                polyLine.add(latlan);
                LatLng previousPoint = latLngs.get(latLngs.size() - 2);
                polyLine.add(previousPoint);
                googleMap.addPolyline(polyLine);
            }
        }
    }


    /**
     * Clear the all draw lines
     *
     * @param view Current view of activity
     */

    public void clearCanvas(View view) {

        try {
            AlertDialog.Builder alertdalogBuilder = new AlertDialog.Builder(
                    this);

            alertdalogBuilder.setTitle("Clear");
            alertdalogBuilder
                    .setMessage(
                            "Do you really want to clear the geometry? This action can't be undone!")
                    .setCancelable(false)
                    .setPositiveButton("Yes",
                            new DialogInterface.OnClickListener() {

                                @Override
                                public void onClick(DialogInterface dialog,
                                                    int id) {
                                    // polygon.remove();
                                    googleMap.clear();
                                    latLngs = new ArrayList();
                                    listPoints = new ArrayList();
                                    isGeometryClosed = false;
                                }
                            })
                    .setNegativeButton("No",
                            new DialogInterface.OnClickListener() {

                                @Override
                                public void onClick(DialogInterface dialog,
                                                    int which) {
                                    dialog.cancel();
                                }
                            });

            // Create Alert Dialog
            AlertDialog alertdialog = alertdalogBuilder.create();
            // show the alert dialog
            alertdialog.show();

        } catch (Exception e) {
        }

    }

    /**
     * Method for Save Property
     *
     * @param view
     */
    public void savePolygon(View view) {
        try {
            if (isGeometryClosed) {
                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                        this);
                alertDialogBuilder.setTitle("Save");
                alertDialogBuilder
                        .setMessage(
                                "Do you really want to save? This action can't be undone!")
                        .setCancelable(false)
                        .setPositiveButton("Yes",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog,
                                                        int id) {
                                        // if this button is clicked, close
                                        // current activity
                                        // Prop.this.finish();
                                        savePolygonAfterAlert();
                                    }
                                })
                        .setNegativeButton("No",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog,
                                                        int id) {
                                        // if this button is clicked, just close
                                        // the dialog box and do nothing
                                        dialog.cancel();
                                    }
                                });

                // create alert dialog
                AlertDialog alertDialog = alertDialogBuilder.create();

                // show it
                alertDialog.show();
            } else {
                showDialog(this, "Alert", "Close geometry before saving");
            }
        } catch (Exception e) {

        }

    }

    public void savePolygonAfterAlert() {
        // save geometry of polygon
    }

    public void showDialog(Context ctx, String title, String msg) {
        AlertDialog.Builder dialog = new AlertDialog.Builder(ctx);
        dialog.setTitle(title).setMessage(msg).setCancelable(true);
        dialog.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        AlertDialog alertDialog = dialog.create();
        alertDialog.show();
    }

    public void countPolygonPoints() {
        if (latLngs.size() >= 3) {
            checkClick = true;
            PolygonOptions polygonOptions = new PolygonOptions();
            polygonOptions.addAll(latLngs);
            polygonOptions.strokeColor(Color.BLUE);
            polygonOptions.strokeWidth(7);
            polygonOptions.fillColor(Color.CYAN);
            Polygon polygon = googleMap.addPolygon(polygonOptions);
        }

    }

    @Override
    public boolean onMarkerClick(Marker marker) {
        // TODO Auto-generated method stub
        Toast.makeText(this, "Marker lat long=" + marker.getPosition(),
                Toast.LENGTH_SHORT).show();
        if (latLngs.get(0).equals(marker.getPosition())) {
            countPolygonPoints();
        }
        return false;
    }


    @Override
    public void onMapReady(GoogleMap googleMap) {

        map =googleMap;

      //  Draw_Map();
    }
}