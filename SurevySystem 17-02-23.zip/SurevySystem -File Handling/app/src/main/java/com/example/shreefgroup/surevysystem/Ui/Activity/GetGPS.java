package com.example.shreefgroup.surevysystem.Ui.Activity;

import static com.example.shreefgroup.surevysystem.Ui.Activity.MapActivity.TAG;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.StrictMode;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.telephony.gsm.GsmCellLocation;
import android.util.Log;
import android.view.Menu;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.TimeoutError;
import com.android.volley.toolbox.StringRequest;
import com.example.shreefgroup.surevysystem.DataBase.DatabaseHelper;
import com.example.shreefgroup.surevysystem.InterFace.LocationManagerInterface;
import com.example.shreefgroup.surevysystem.Model.GPS;
import com.example.shreefgroup.surevysystem.Model.Grower.GrowerResult;
import com.example.shreefgroup.surevysystem.Model.Master;
import com.example.shreefgroup.surevysystem.Model.Savedata;
import com.example.shreefgroup.surevysystem.Network.ServerError;
import com.example.shreefgroup.surevysystem.Network.ServerTask;
import com.example.shreefgroup.surevysystem.Network.UserInfo;
import com.example.shreefgroup.surevysystem.R;
import com.example.shreefgroup.surevysystem.Service.GPSTracker;
import com.example.shreefgroup.surevysystem.Ui.Fragment.home.HomeFragment;
import com.example.shreefgroup.surevysystem.Utils.AppController;
import com.example.shreefgroup.surevysystem.Utils.Constants;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MapStyleOptions;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolygonOptions;
import com.preference.PowerPreference;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Timer;
import java.util.TimerTask;

import fr.quentinklein.slt.LocationTracker;
import fr.quentinklein.slt.ProviderError;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;

public class GetGPS extends AppCompatActivity implements
        ActivityCompat.OnRequestPermissionsResultCallback , OnMapReadyCallback {

    final static String path =AppController.getInstance().path+ "/ESurvey" + "/";

    final static String SaveGPS = "SaveGPS";

     final static String strSDCardPathName2 = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM) + "/E_survey" +  "/New Survey" + "/";

    private static final int REQUEST_READ_PHONE_STATE = 0;


    public String DeviceId;

    Location mCurrentLocation;
    String resMessage = "";

    AppController application;
    boolean bool = false;
    int mapView  = 0;

    private String lat_ed, lng_ed;

    private double LAT;
    private double LNG;
   // private EditText Accuracy;
     Button btn_done;


    private String textv, textv2, textv3, textv4, textv5, textv6, textv7, textv8, textv9, textv10, textv11,
            textv12, textv13, textv14, textv15, textv16;
    private Button btn_getgps;
    private String textv17, textv19, textv18, textv20, textv21,textv22,textv23;
    private Location mLocal;
    private EditText Edt_Latitude, Edt_Longitude;

    private int count = 0;
    private TextView gps;

    private String srv_id;

    private DatabaseHelper db;
    private String idd;
     DatabaseHelper db_helper;
    public Savedata s;
     GoogleMap maps;
    public LocationTracker locationTracker;



    TextView areaTextView,lengthTextView;
    double totalArea = 0.0;


     BroadcastReceiver latReceiver = new BroadcastReceiver() {
        // we will receive data updates in onReceive method.
        @Override
        public void onReceive(Context context, Intent intent) {
            // Get extra data included in the Intent
            String lat = intent.getStringExtra("lat");
            String lng = intent.getStringExtra("lng");
            // on below line we are updating the data in our text view.

            Toast.makeText(getApplicationContext(),lat,Toast.LENGTH_LONG).show();

            Edt_Latitude.setText(String.valueOf(lat));
            Edt_Longitude.setText(String.valueOf(lng));
        }
    };

    // private ViewOption viewOption;

    public static boolean isNetworkAvailable(Context nContext) {
        boolean isNetAvailable = false;
        if (nContext != null) {
            ConnectivityManager mConnectivityManager = (ConnectivityManager) nContext
                    .getSystemService(Context.CONNECTIVITY_SERVICE);
            if (mConnectivityManager != null) {
                boolean mobileNetwork = false;
                boolean wifiNetwork = false;
                boolean mobileNetworkConnecetd = false;
                boolean wifiNetworkConnecetd = false;
                NetworkInfo mobileInfo = mConnectivityManager
                        .getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
                NetworkInfo wifiInfo = mConnectivityManager
                        .getNetworkInfo(ConnectivityManager.TYPE_WIFI);
                if (mobileInfo != null)
                    mobileNetwork = mobileInfo.isAvailable();
                if (wifiInfo != null)
                    wifiNetwork = wifiInfo.isAvailable();
                if (wifiNetwork == true || mobileNetwork == true) {
                    if (mobileInfo != null)
                        mobileNetworkConnecetd = mobileInfo
                                .isConnectedOrConnecting();
                    wifiNetworkConnecetd = wifiInfo.isConnectedOrConnecting();
                }
                isNetAvailable = (mobileNetworkConnecetd || wifiNetworkConnecetd);
            }
        }
        return isNetAvailable;

    }


    public static void clearFolder2() {
        File dir = new File(strSDCardPathName2);
        if (dir.isDirectory()) {
            String[] children = dir.list();
            for (String child : children != null ? children : new String[0]) {
                new File(dir, child).delete();
            }
        }
    }







    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }


    @SuppressLint({"MissingPermission", "HardwareIds"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.get_gps);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(builder.build());
        builder.detectFileUriExposure();

       // mLocationManager = new SmartLocationManager(getApplicationContext(), this, this, SmartLocationManager.ALL_PROVIDERS, LocationRequest.PRIORITY_HIGH_ACCURACY, 10 * 100, 1 * 100, SmartLocationManager.LOCATION_PROVIDER_RESTRICTION_NONE); // init location manager


        Edt_Latitude =  findViewById(R.id.LAT);
        Edt_Longitude =  findViewById(R.id.LNG);
        //Accuracy =  findViewById(R.id.Accuracy);
        gps =  findViewById(R.id.gpscounter);
        areaTextView =  findViewById(R.id.area_in_meter);
        lengthTextView =  findViewById(R.id.area_in_length);
        btn_done =  findViewById(R.id.btn_done);
        btn_getgps = findViewById(R.id.get_gps);
        Edt_Latitude.setEnabled(false);
        Edt_Longitude.setEnabled(false);
        db_helper = new DatabaseHelper(this);
        db = new DatabaseHelper(this);
        application = (AppController) getApplicationContext();
        s=new Savedata(this);


        locationTracker = new LocationTracker(
                1000L,
                1f,
                true,
                true,
                true);

        if (ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.ACCESS_COARSE_LOCATION);
        }
        locationTracker.startListening(getApplicationContext());

        locationTracker.addListener(new LocationTracker.Listener() {
            @Override
            public void onLocationFound(@NonNull Location location) {

                mLocal = location;
                Log.d("new_value",location.toString());
                LAT = location.getLatitude();
                LNG = location.getLongitude();


                Edt_Latitude.setText(String.valueOf(mLocal.getLongitude()));
                Edt_Longitude.setText(String.valueOf(mLocal.getLatitude()));


               /* if(mapView == 0){

                    SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                            .findFragmentById(R.id.gps_map);
                    assert mapFragment != null;
                    mapFragment.getMapAsync();

                    mapView = 1 ;

                }*/

            }

            @Override
            public void onProviderError(@NonNull ProviderError providerError) {

            }
        });



        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.gps_map);
        assert mapFragment != null;
        mapFragment.getMapAsync(this);






        final int permissionCheck = ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_PHONE_STATE);
        if (permissionCheck != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.READ_PHONE_STATE}, REQUEST_READ_PHONE_STATE);
        }

      try {
          DeviceId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
      }catch (Exception e){
          e.printStackTrace();
        DeviceId = AppController.getUuid(GetGPS.this);
      }






        btn_done.setOnClickListener(v -> {
            if (isNetworkAvailable(GetGPS.this)) {

               //   db.upDateMapArea(String.valueOf(totalArea),idd);

                new UploadAsync(GetGPS.this).execute();


            } else {
             //   db.upDateMapArea(String.valueOf(totalArea),idd);

                finish();
                Intent i = new Intent(GetGPS.this, MainActivity.class);
                startActivity(i);
                Toast.makeText(GetGPS.this, "No Network Data sent to Queue", Toast.LENGTH_LONG).show();
            }


        });

        btn_getgps.setOnClickListener(v -> {
            lat_ed = Edt_Latitude.getText().toString();
            lng_ed = Edt_Longitude.getText().toString();
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("ddMMyyyyhhmmss");
            String timestamp = simpleDateFormat.format(new Date());
            String cnt=String.valueOf(count);
          String idd =   PowerPreference.getDefaultFile().getString(Constants.ENTRY_FILE_NAME, "");
            db.Insert_gps(new GPS(idd, lat_ed, lng_ed, DeviceId, timestamp,cnt ,"No"));
            count++;
            gps.setText(String.valueOf(count));



            if(count >= 3) {

                if (maps != null) {

             /*        final   ViewOption viewOption = getViewOption();
                     calculateAreaAndLength(viewOption);
                     MapUtils.showElements(viewOption, maps, GetGPS.this);
*/
                }else {




                    Toast.makeText(GetGPS.this, "map is null ",
                        Toast.LENGTH_SHORT).show();
                }
            }

    /*googleMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
                                        @Override
                                        public void onMapClick(LatLng latLng) {
                                            Bundle args = new Bundle();
                                            args.putParcelable("optionView", viewOption);
                                            Intent intent = new Intent(getActivity(), MapsActivity.class);
                                            intent.putExtra("args", args);
                                            startActivity(intent);
                                        }
                                    });*/


            Toast.makeText(GetGPS.this, "Done",
                    Toast.LENGTH_SHORT).show();
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    private void upload() {



        try {
            List<Master> A = db_helper.getAll_Master();
            for (Master obj : A) {
                srv_id = obj.get_mob_id();
                textv = obj.get_survey_type();
                textv2 = obj.get_cnic();
                textv3 = obj.get_Grower_code();
                textv4 = obj.get_name();
                textv5 = obj.get_father_name();
                textv6 = obj.get_cast();
                textv7 = obj.get_circle();
                textv8 = obj.get_village();
                textv9 = obj.get_acrage();
                textv10 = obj.get_yield();
                textv11 = obj.get_killa();
                textv12 = obj.get_sqr_no();
                textv13 = obj.get_sowing();
                textv14 = obj.get_crop_cond();
                textv15 = obj.get_veriety();
                textv16 = obj.get_plantation();
                textv17 = obj.get_note();
                textv18 = obj.get_imei();
                textv19 = obj.get_filename();
                textv20 = obj.get_filename2();
                textv21 = obj.get_filename3();
                textv22 = obj.get_filename4();
                textv23 = obj.getTotalArea();



               s.save_data(srv_id,
                        textv,//mobid
                        textv2,//type
                        textv3,//imei
                        textv4,//cnic
                        textv5,//code
                        textv6,//name
                        textv7,//father
                        textv8,//cast
                        textv9,//circle
                        textv10,//village
                        textv11,//acrage
                        textv12,//yield
                        textv13,//killa
                        textv14,//sqr
                        textv15,//swing
                        textv16,//cond
                        textv17,//veriety
                        textv18,//note
                        textv19,//img
                        textv20,//img
                        textv21,
                        textv22,
                        textv23);
                break;
            }



        } catch (
                IOException e)

        {
            e.printStackTrace();
        }
    }



    private void savedata(String srv_id, String textv, String textv2, String textv3,
                          String textv4, String textv5, String textv6, String textv7,
                          String textv8, String textv9, String textv10, String textv11,
                          String textv12, String textv13, String textv14,
                          String textv15, String textv16,
                          String textv17, String textv18, String textv19,
                          String textv20, String textv21, String textv22,String textv23) throws IOException {

        final String cell = "";
        final String SurveyorCode = PowerPreference.getDefaultFile().getString(Constants.USER_ID,"");
        final String Companycode = PowerPreference.getDefaultFile().getString(Constants.USER_UNIT,"");

        final String srvid = srv_id;
        final String Surveytaype = textv;
        final String NIC = textv3;
        final String Grower_code = textv4;
        final String Grower_name = textv5;
        final String father_name = textv6;
        final String Caste = textv7;
        final String circle = textv8;
        final String village = textv9;
        final String T_acreage = textv10;
        final String T_yield = textv11;
        final String Killa = textv12;
        final String Sqr_No = textv13;
        final String sowing_distance = textv14;
        final String crop_condition = textv15;
        final String variety = textv16;
        final String plantation = textv17;
        final String Note = textv18;
        final String imei = textv2;
        final String map_area = textv23;
        final String mfilename, mfilename2, mfilename3, mfilename4;

        mfilename = Objects.requireNonNullElse(textv19, "Nofile");
        mfilename2 = Objects.requireNonNullElse(textv20, "Nofile");
        mfilename3 = Objects.requireNonNullElse(textv21, "Nofile");
        mfilename4 = Objects.requireNonNullElse(textv22, "Nofile");
        String url4 = AppController.baseUrl + AppController.URL2;
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url4,
                response -> {
                    String r = response.toLowerCase();

                    Log.d("response",r);

                    db_helper.INSERT_FLAG(new Master("Yes", srvid));

                    Toast.makeText(getApplicationContext(), "Master data inserting plz wait...", Toast.LENGTH_SHORT).show();

                    continou();

                   // gpsinsertion();







                },
                volleyError -> {
                    if (volleyError.networkResponse == null) {
                        if (volleyError.getClass().equals(TimeoutError.class)) {
                            Toast.makeText(getApplicationContext(), "Oops. Network Timeout error!", Toast.LENGTH_LONG).show();
                        }
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put(AppController.KEY_survey_id, srvid);
                params.put(AppController.KEY_CompanyCode, Companycode);
                params.put(AppController.KEY_SurveyorCode, SurveyorCode);
                params.put(AppController.KEY_Survey_type, Surveytaype);
                params.put(AppController.KEY_Grower_code, Grower_code);
                params.put(AppController.KEY_KPI_CELLID, cell);
                params.put(AppController.KEY_file, mfilename);
                params.put(AppController.KEY_file2, mfilename2);
                params.put(AppController.KEY_file3, mfilename3);
                params.put(AppController.KEY_file4, mfilename4);
                params.put(AppController.KEY_IME, imei);
                params.put(AppController.KEY_NIC, NIC);
                params.put(AppController.KEY_Name, Grower_name);
                params.put(AppController.KEY_Father_name, father_name);
                params.put(AppController.KEY_Caste, Caste);
                params.put(AppController.KEY_Circle, circle);
                params.put(AppController.KEY_Village, village);
                params.put(AppController.KEY_Totale_Acreage, T_acreage);
                params.put(AppController.KEY_Total_yield, T_yield);
                params.put(AppController.KEY_Killa, Killa);
                params.put(AppController.KEY_Suqure_No, Sqr_No);
                params.put(AppController.KEY_Crop_Condition, crop_condition);
                params.put(AppController.KEY_Variety, variety);
                params.put(AppController.KEY_Plantation, plantation);
                params.put(AppController.KEY_Note, Note);
                params.put(AppController.KEY_sowing_distance, sowing_distance);
                params.put(AppController.KEY_MPP_AERA_MOB, map_area);

                return params;
            }

        };

        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                50000,
                50000,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        AppController.getInstance().addToRequestQueue(stringRequest, "Tag");

    }

    public void continou() {
        List<Master> A = db_helper.getAll_Master();

        for (Master obj : A) {
            srv_id = obj.get_mob_id();
            textv = obj.get_survey_type();
            textv2 = obj.get_cnic();
            textv3 = obj.get_Grower_code();
            textv4 = obj.get_name();
            textv5 = obj.get_father_name();
            textv6 = obj.get_cast();
            textv7 = obj.get_circle();
            textv8 = obj.get_village();
            textv9 = obj.get_acrage();
            textv10 = obj.get_yield();
            textv11 = obj.get_killa();
            textv12 = obj.get_sqr_no();
            textv13 = obj.get_sowing();
            textv14 = obj.get_crop_cond();
            textv15 = obj.get_veriety();
            textv16 = obj.get_plantation();
            textv17 = obj.get_note();
            textv18 = obj.get_imei();
            textv19 = obj.get_filename();
            textv20 = obj.get_filename2();
            textv21 = obj.get_filename3();
            textv22 = obj.get_filename4();
            textv23  = obj.getTotalArea();
            try {
                savedata(srv_id,
                        textv,//mobid
                        textv2,//type
                        textv3,//imei
                        textv4,//cnic
                        textv5,//code
                        textv6,//name
                        textv7,//father
                        textv8,//cast
                        textv9,//circle
                        textv10,//village
                        textv11,//acrage
                        textv12,//yield
                        textv13,//killa
                        textv14,//sqr
                        textv15,//swing
                        textv16,//cond
                        textv17,//veriety
                        textv18,//note
                        textv19,//img
                        textv20,//img
                        textv21,
                        textv22,
                        textv23);
            } catch (IOException e) {
                e.printStackTrace();
            }
            break;
        }
    }


    private void showAlert(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Response from Servers")
                .setMessage("File Upload Successfully")
                .setCancelable(false)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        clearFolder2();
                        Intent i = new Intent(getApplicationContext(),MainActivity.class);
                        startActivity(i);
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();
        alert.setCancelable(false);
    }


    @Override
    protected void onStart() {
        super.onStart();
        HomeFragment.turnGPSOn(getApplicationContext());


    }

    @Override
    protected void onStop() {
        super.onStop();

    }

    @Override
    protected void onPause() {
        super.onPause();


    }

    private boolean isGooglePlayServicesAvailable() {
        int status = GooglePlayServicesUtil.isGooglePlayServicesAvailable(this);
        if (ConnectionResult.SUCCESS == status) {
            return true;
        } else {
            GooglePlayServicesUtil.getErrorDialog(status, this, 0).show();
            return false;
        }
    }

    private void updateUI() {
        if (null != mCurrentLocation) {

            Edt_Latitude.setText(String.valueOf(mCurrentLocation.getLongitude()));
            Edt_Longitude.setText(String.valueOf(mCurrentLocation.getLatitude()));

        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();


    }

    @Override
    public void onResume() {
        super.onResume();

    }



    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
        Intent intent = new Intent(GetGPS.this, MainActivity.class);
        startActivity(intent);
    }


    public  void postImage(File file1){

        RequestBody mFile = RequestBody.create(MediaType.parse("multipart/form-data"), file1);
        MultipartBody.Part fileToUpload1 = MultipartBody.Part.createFormData("file1", file1.getName(), mFile);


        Call<UserInfo> fileUpload = ServerTask.getInstance().getServices().upload_Arrival_data(fileToUpload1 );


        fileUpload.enqueue(new com.example.shreefgroup.surevysystem.Network.ServerCallback<UserInfo>() {
            @Override
            public void onFailure(ServerError restError) {

            }

            @Override
            public void onSuccess(retrofit2.Response<UserInfo> response) {

            }

            @Override
            public void onResponse(retrofit2.Response<UserInfo> response) {

                String status = response.body().getStatus();

                if(status.equals("0")){

                    file1.delete();

                    Toast.makeText(getApplicationContext(), response.body().getResult(), Toast.LENGTH_SHORT).show();
                }
            }
        });


    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {

        MapsInitializer.initialize(getApplicationContext());


        maps = googleMap;
        try {
            maps.setOnMapLoadedCallback((GoogleMap.OnMapLoadedCallback) this);
        }catch (Exception e){e.printStackTrace();}
        servicesOK();

        boolean success = googleMap.setMapStyle(new MapStyleOptions(getResources()
                .getString(R.string.style_json)));

        if (!success) {
            Log.e(TAG, "Style parsing failed.");
        }

        maps.setMapType(GoogleMap.MAP_TYPE_NORMAL);

        LatLng sydney = new LatLng(LAT, LNG);


        googleMap.addMarker(new MarkerOptions().position(sydney)
                .title("Current Location "));
        googleMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));

        googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(LAT, LNG), 12.0f));
        googleMap.addMarker(new MarkerOptions().
                position(maps.getCameraPosition().target).title("Near to Sydney"));

        maps.setOnMapLongClickListener(latLng -> {
            MarkerOptions markerOptions = new MarkerOptions();
            markerOptions.position(latLng);
            markerOptions.draggable(true);
            markerOptions.title("Add a hazard here.");
            markerOptions.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED));
            maps.addMarker(markerOptions);
            ///mHazardsMarker = mMap.addMarker(markerOptions);
        });


    }


 /*
   @Override
    public void onMapLoaded() {
        LatLngBounds.Builder builder = new LatLngBounds.Builder();

        String encodedPath = "{k|sFvmgcMf@_DwG_Dg@wBnAwBvGg@nKrIvG_D~CbBoAbLoAbBwBkCwBbBf@jC~CbB~RkCfE{EnK{@vGnA~HsNvBz@vB~MfESnFwQfERvG~H~CRvBoFfOwB~Cf@oAbBnFfEvBcB_DsXf@_D~CnKjHRbB{ES_SjHkCjCgJvG_IzE?bLsIfEkHf@oKzEg@rIoPvGgY{@kHbBk\\~R{@jWcGr{@we@j\\{c@nA~HzJ{JwB?kCfEcBoAz@_IzJkHRnKzEfERvGwBnAsDoFcBz@_DvGfEoFvBnAcLfT~McQkHzOrDoAf@bBRcGjCcBg@fO_Df@bBnAbB{@bBcL{@oFbBkCvBf@RjWoAz@vB~RSbBcGR~Hz@?nAwBvG{YoF?bQz@R?wLjC??rNf@gOjCf@SrDnA_DrDRoAvLbB?RkHjC{@nAbQoKg@?nAfE?RrDsNz@zO?vBsDbBR~HzJoFnFoFg@?wBgJ??nAvL~C{EjHwBSnAvBcBfOkCz@sDnFoF?zEbB?vGoA~CkC?vBz@?bGkHzEz@z@cGbBoF_Df@bGcGrD{JwGvBrDoAnAz@vB{T~HoAwBf@bBkCf@f@wBoFcBsDvQnF{EjCz@nF{@vBrDjC{@g@kCcBRcBwB~H{@jHoFrDS?bG_DbBf@jC~C?fEwBoFnA{@{@vBcBRsInAoAvGz@{@_DjC{@jCjCSnA_DwBvBvG~CSf@_D_DsD~Cg@ScBnF{EnASz@vBgEnAz@rDbBS{@zEz@oAfEf@{@wGf@nFsDg@f@_InAbBoAwGzE~H_DgJR{JbLcVbBsNbGoF~CjRSfOjCbBcBnPvB_NcBjRf@bLcBfEjC{@rDnFgEsDsDz@bGvBbBrIg@zE{@{J?fJjCbBwLRbGjC?zEf@gEf@nASfJsDnAnAz@g@zJsIzObBRwBbGRnArIkRfEjCg@rIvBjCoAsDz@cLsD?{@kCvBcG?zJz@S?cGz@zEjCRwBwB?wG~CS_D{Ez@gE~CoAgEwQrDwBcB{@bBwGgEkHz@ccAsDkR?kR_DoF{@kHvBgTzE{@z@bBsDvLSnKrDoPbBz@oAjMbBwBbBsNkCwGnKz@sIrb@{@zYzEfOfEfEcBbLrDzJ{EbLbBfJoAve@bB~a@{@vBz@z@oAjCf@bBf@_Dz@nAoAjCzEnK{@jHnA~CwBbBnFvGg@fEgEjCf@nF_Df@g@fJoFzO_DS_DnK_Df@g@rDwG~Cg@~HwGRoAzEoFzEnAnFnKcQ~Cz@nA~CoA~MwG~HvBjCnAwBvBRg@fE~CSnAoA?sXnAwB~CbBvB_DvGbBnAgJfJrIvG~M~CvQg@bGvBwBf@sNwG_b@bLoUbB_IrIoKf@{E{EwLvG_IfEsb@cGsNgOgJvGwBnAwBbB{OfE_I~Hc[g@_IsIkMjCg@zJvBkCcBwL{@sNsXbBoAzJrIrNcB_Nz@oKgJ{E?fOwGoKnA?_IvGz@nFwGsInAwB_D?k\\fEkW{@oPfE_DwBwBwB{TbBkC~H~CzEoA?vGnFzEnPgEvGbBnFkHSwGjCf@bB~MbGvGwBz@SrIfEjCsDzO~HsSg@{EvQ{EnAoFR~HoFfEcBvGrDbQbBSbGvLz@fJoAzEvBgESsIbG{@f@nA~CrScBjCz@vQvGzJ_DbB{@bG_DRnFRnAvBoA~W~CkCg@oKbBsIkC_DjC{ES{EjCzERnFvBrDnAg@vBbBSbGrDjHvBkCrIfEnF{JwBf@{JcLbGcGg@cG~CRrDwGf@~H~H~CfEzErSv`@jRjCz@zEwGfh@wBrD_D{@cGfEz@jCbGnAz@zEwBbGRvQ{ErNnAjCwGvGoUzEf@bGwBbBcGSkHgE{Ef@oFoK~C~HoA~CjCg@z@z@cB~HvBz@oAz@R~CnAnFvBz@f@vGgJfEnFRf@~R~CrNoArIoFjH{^fYbL{@wB~HgJrDwGjM_IfEgE{@nAvBgEzE?rDvG_IfTwL?jHgOni@vBcBnUco@fOsSnA{T~C?~C~CnFsDfTfE~CvwAnA~Cf@o{AoAkHvGkf@f@gT~H{EfJg@vGkMoFsXvB_DnUf@fTrIvLbBnFjHnAjHgE~C_Ig@wQrD?wGwVSoAvBvQz@g@bBsSSnP~CwQ?rIvB_IRnAnAf@bQvBoP~HRnAzEg@jHnKoAg@~CfEkCoAkHfEcGnPzE?cGnKbLwBzO~Cf^~CnK?zJ_Ib[_IzO_Dbo@gE~Cg@rXnFkHnFoU?c[nUcQvBjC?sDvBcBfErNoKv`@fEoFf@vGoAjCvBnA?nF~CR~CfEvBbQnFoKf@wL_D_I~WjMgJwGfEoUwGjRwGsD~HgY~CnAvBwBfE{OfEbBvBoAgE{O~Hw[~CgEvGzEnArDvL~CgEoP_I{JwLw[wGsD_D?oFoUoPkHg@wBvBoF~M~CoAoPnA_DnZ~HnAnF~WnAnAnAfJzm@nAwGnFgE?{JvGkMfEwBvGkRoAcQnd@bGg@nFnArD~Cz@nFoA?sIvB?~RvVRrDzJzOg@rIgTbGwLcB?rInAkCnKRfTwGvBbB?rD~CnFnA_Dg@kRfEcLoAoFnFoAnFwG_DcGgEjCg@kCgJcBwBvBoAcB~CkHnFf@fJ{EfOg@fTvGf@jC~RfO?jC~RfE~C~Cf@v[cVRjWbBvGzw@g@vBvBzJ~a@fYg@rDwGfEvBbL_DbBwBg@wBrDvBz@nAnF_IrXnAbGoFb[wG~HgTbBoFnKfEfEnFg@?vG_NrIgJnU?~HfOfOwGvQ?~RfEfEvGz@nFrDoFnAf@jCgEbGg@vGfEjMoUj\\?nPoA~CfEvGoArD_DRg@vBnFjHnAwGvGz@nKgJwLoK?{JfEcB~Cz@~RcLfE_NgE{JvV_Xf@wGoA{EvB{@g@cBgOwGg@sDfEgc@?{OfEcBfEcG~Cg^wBkMnFkWf@fEnAgEvBrDvBg@nAvBvBg@~CfEg@{OvBgTwG{E?gJnFoF~Hg@g@_DfJoF?_IwB{EfOwj@g@kHgEwGnAgOwBcQ_IkHg@{E?sInFcG?_D_IgEwBc[vBf@nAkMwBRg@gJnFz@g@rD~CSvBcGwB_IoFg@g@sDvGwBf@vBnFvB~MoAvQnK~Mg@vBbL~CRf@vLvB{@fJbLnFbBfEbLoFnFg@vBvBS?fE~C{@~CvBvBoAnF~HgEnAgEnFvB~McBjCzEwBvLvGf@_N~HvG~Hf@~HzJvBrIvG~Cf@jCgE~CvLz@g@~CwBRvBjC~CRvBoFfErInAoAg@kRvB?nAjCf@~RnF~C~Cg@vBoK~MjCwBvBvBz@vBcBf@bBwBzJnFrDnK{@f@sD~CzEvGvBvB_DgEgEvGcBfJrI?jCoFsDwBfOf@jCfJ_D~Cf@f@fEfEcGf@oPnAnAf@nU~CbB?gJ~HkM~Cf@nAjHnKzEvB{@~HkHf@sD_N{E?wBvBz@nKwBf@wBwBsN_D?f@kCfJsD?v[~HjWvBf^oFzkAfJbGf@~C?nFwBbB?rNnF{@vBwLf@_]_D{EvBRf@gJnFcG_DSg@sD?wo@nAoAnArDvBf@~C_NoFwQ_Dz@oA~Cg@sIf@kRvBz@vBcBvBgOfERnFgE~Cf@vBvBnAfOnAvBvB?vBoAvGcQoFgEf@wGfERvBjCnPzEnFzJg@rIwBS_DjC?jC_Dz@wBfOwLcGg@~HvBg@fEvBvBjHvGcLnAkHnF~Cf@jH~CsDoAkMvBRnF~MfJzJ~HRfEzJvBf@vBcBg@fTvBR?nKwBnK_Dz@vBz@~HgE?gEvL_XvL~MfEkMwB{@vB_D~H~C~RrX~Hf^vB?~H~HvBrN~RnUvGnAnAfJwBf^nAfh@gJr]_DbB~CvGoFbVwGjHwGvQoFnFgEf@_D~Hf@fJ~CwG?{EnK{E~H_SvGoF~CgTvBcBvBf@oAnKvBzJf@~WvBvBoArI_D??jCfEf@~CcB?ka@wBoAwBcLg@sDvBgE_D{TfE_NvQjz@vBvj@nPfaA~HbQvGrDfOg@nPsInAgEf@gYgEnZoKzJoFz@oK{@oF{EoFkRg@cLoKwj@g@gYwGcj@nAcGfE?g@cB_ISf@sI_IwGf@gTwBkMvB_IgEwGfEoFg@{YfJsI?_IvBgE~WrInKfJfOzO~CzJ~MzOfJ{E~C?fOrIvj@rv@fEvBfTbBg@nUvBwB?gJnZRnKjCnAjCf^rInKbGvQf@nPoF~Cf@nKrD~WjWvVzJvL?vQwGfc@wBfJ_D~CzJ~M~H~C~H~H~H?vB_DvQwBvBgEsDoAbBgEg@g@vBoUzE~HbBnFkC~Cf@nAwBnPg@nFnFg@oU~MgYfE_Df@{EwBRoAfEwBz@oAoAf@{E~HcG?_I~CwGvGzEnFg@vGfEg@fEnF{@rDnAcQwLjCkH_NwBbBzE_IsDfE{JsDoF{@RvBnF{EbB{Eg@SbLkCbGgEf@g@nF_DcBoFR?{EzE{Ef@sDrNkMjCSjCoFf@cQbGw`@fE_g@nFgY~C_DzEbB~CwBz@z@wBrD?vLkCnAkC_D{@bBnK~HbBrISnKgE~HRbB~C{@f@jH~CoFsDgE~CwGSkR~HcBjMzEvGcLSwGvGvBg@nKjCjH?oF~HcGbBjCjCSf@wGvBSz@_DwB{@f@{J~Cf@RfJjMf@vB{@_NjMoAnFgEg@{@fEoFbBnAnF?wBfEg@nA{E~HwBRjHzEfO{@vG_Dg@?vGrDfEsD~RcLf@kCbGvBrSkHRg@{EwBoA_DRoAbGwGsD{@vGjHR{@bBgJoAsDvGkCwBsIf@RvB~CRwBjC?vGkCz@oAbGwG?_DjCf@bB~CoAnAz@rNkMSsIvBcBSwBnFvBRrDbBR{@wGnAsDvL?nF{JvBfJfEcB~Cz@{@~RrDsDf@jCoAzEgJzERvBvBnAf@oAfEbBbGSkCjCz@vLwB?g@nAbBfEoAnFoKbG~H?nFfEcGoAf@fEfJ?wBwBz@kHzE?SwGfEgEvBjMfOsD?cGsIjCwBgJ{Ez@gEjHoAScB{TjCgESkC_DoAwGRfEcGz@cLcBcGjCcLS_DvLcBf@gOfEwLjHcGnAsInK_D_DkH{E?{@fE{@cB?gJzEsIbL{@vBwBvBrXbBg@nAnAwB~CbBnAz@_DrDbBzEvL?jMjCnF{OrIkCvLnASzEoKfJsD?vBgJjHRfEjCnAcB{EbLcLf@{JoFwVgOoZz@_IkH_XR{JkC_N?cGvG?~CgE~Cg@bBfOkC?_DoF{@zEfJfJjC{@nAbQnKrXrIz@~HcBbGcGz@f@g@nKwGnAbGrIcBbLkHrDsDvLjCn_@kHRR~CjCoAjCvBcBnFjC{@{@rNrDbBsI~HcBbG~HfOrDwGbBf@fE{Jg@sDjCgE_I{@_DsSvBcBcBcB~CcGg@gEbB_DnAnA~HsDzEnAvBrDfJgERcGcBsDgE?gEnFgJcB{@oFz@g@bBjCvBcBkC_DvGkHnAoF~Cf@z@kCjCRfJbQgE~CRbV_DbQoK~CcGoAoAnAnFbBnPoA~CsIbG_Df@bQkHf@cBrIfEf@oAcG~CoAbBrDoAvG~CfJbBcBvGbGrDS?jHjCrDSbBkHzEkHoA{@bB~C~HfEwBzE?S{EnFzEsIrNjMf^nKoAbBsDgEoKvB_IzJrDbGrXrDSwBg@cBoF{@_NwBsDwQwGf@wG_ISRcGsD{Jf@sDvGf@bBbGrDvBjMRg@zJnAnAf@bLfEbLzEvBvLgEz@cBbGvB{@cLjCkRoFsSRwLbGoFfTbL{Ez^sD{OSnAz@~RbGvBz@zO~CrDcBr]zJnKRnFzEfJbQbLg@fE{JnAcBwG{J{@gJcGgE?kRsNcBz@oF{@g@z@jRnFbGrIjMfEg@bGjHg@nUrSbB?R{EbGcG~CSzJvGbB~MrDkHjH~CbL{@bGnA?nFkMg@{@~CbBcBvBRRjCrI{@?bG{Ef@jHvB~CfEcBkHvB{ESsDrD?fOgJz@gJvGsDzJcB~RzTgEfJkH{@wGzEcLvBkHjMgEvQgOzJ{J~CkCfJwGbB_D~CnKoAbGwLv[_NvBwQnKcQjRoFnFnArNoKnFg@jCrDbBrI_Nb`@cL?sD~CoKR{EjH~HoFjHf@zEsDnFz@z@vBzEg@nFgJ{Ej\\gJjMoFnPoARz@nKjCvB~C{@f@vBzEz@bBbGf@gErDfEoAzEz@nKsInAcB{@S~HrDvBg@_DrIf@?rDbBbBwB~MnAjC{EzOgEz@_DfEsISkCfJgEkHwLf@wGrNbGkCz@cGrISnAfEfEz@rDgErDbBrIoFbG?nUoP~M~C~HkC~CfEbQ_DzEnFgEbBsDjH_NoAg@z@bG~CvGSjCkCbGbB~CbLjC_DjCg@fJnAg@cL~CsDrN~HzJnA{@nU{JvGgE{@wBzJcGzEkCjMgOoFgEz@_NkMoFfEoPcBkHrIcGvBnArDzO{O~MjC~HwBnKbLfE?fE~CjHRrIzEwB{JbBsIrIoFfOSfEwBfJfJrIrDSbLvBf@nAbLwBbGcQnFcBzJf@fJ_IvGwBrI~CvBbB_IbGwG~CkWjMSbGcGvBsIcBcLrDoF~CsNfc@sIjHrDrIf@jCvL{@vL~C?bBnFgEnF?~CsDrD?bGsIg@cGzE{EwBvBzT{EbBsDcLcBvLjCzJSnFgEvLoFwG_D?vBjCz@nKoA~C{EcB{@z@jH~CbGcBfEbBz@cBg@bLsDjCrDjCnArN~HzOf@oFfEgEfJwBbBwBbLfEfEg@~C~C_DrI_IzE_DrNgEvGg@vLfEoAfJrI?bG~HrN?zO~Hf@fJcBnAnAf@jRoA~HvGwGnFf@wBjHf@zOvGbLvB_NvQRvGrDfOgE~CfTnAz^vGbBnFzEfESnPvGnKgEfESvBnAgEzc@oFnF_If@gEvGf@vLvL~CnAvBwBfEgEbBwGcBoA~C~C{@vBjC~HoAnKgJvLnF~C?fT_Df@kCvBRvG~R~HjCg@~RnAjCvBf@~C_D~CoKfER?vLnAjCvQnFg@vL_IfEoAjCrD~HjCcBwB{EvGoFvBcLg@{EgT_InAgJgEsDgE?_IfOoAoA~C{O~C{EnAcLoAgJvGwVv[_]vGbBbQcL{@_I~CkMkCgYnKbBbQRnK{Jz@fErDbBoAwGbBwLfY_q@nKon@~CoFj\\gErl@Sz@jC~C{@nKbGz@zJ{JzYsIz@gE_I{Ez@{TrXcLnF{O_D{EzJfErb@fYr]SbG_I~HbGcBnAbQnU~Rwe@fJoAoFjCRwBgEsD{@f@cGsDf@S_DcB~CoAgERwG{@RkCzErDnKg@bQkHvBf@jCwBrDsD?sDsIbBwLoAcGSbG{@?oAnFkCg@{@bBbBnA?rIfE~CoAbLoPcLkCf@cBnFcGkCvBfErD?bGgEzEnKvGfErDwBg@{JnA{@zEf@rNrIRnK_IzJgJfYwGfJoA~MwGjMg@rX~CvLwBnFf@~WkM~MbGcBfEbGg@bL~C~HnAfOwBg@wBjHnA~RfEnFvB?vGvL~Cz@~CbLvBjRoFjC_DsDoAvGfEnAfE_D~Hzh@g@~CgORgE~C?vBoP~Cg@jCwQR_D{JwGf@gEvG?~HfErIg@vL_DvB~CbQoU{EfEwVoA_DoF{@_D?oFjHoAzYwG?_D_IoKwBg@vBfJvGg@fJ~HR~H~H~\\zJfEnKgE~Cwe@kC?rDgE~HwBwGoPwBgEnAoFrNgTbLgJ{J_DkHf@cLwB_N~HgToAsIoAoFwGgE_DoK_D_DsXsNkW{@on@oPwj@cVwaBsDogAS_k\\cBoiTfwJ_xNfdGwcFfxBgfFrmBwfGbxCw~@gvCghEglH_{@s~A_xDgdGogA{iBnKsbJvGctO~MwVfYoKnPSvLzEnPf@vLcGnPz@bBgJ{@{@bB{@SkCnKgY~HsDvG_IbGSnUkHb[gOfEcGnKwBvGcGnd@RjHnFrXbGjMgEnUw[rDkWjH{ObBoUbBsXsDoU?kk@kCcVsIk\\jC{|@{@_IvBwBz@wGz@crArNc`@~Hkk@kCoZvB{JvGkHjMgEnAcB{@cB~WcV?cQolFgdGnF{EvBoKfJgEnP{@fEwLvLkM";


        DatabaseHelper databaseHelper = new DatabaseHelper(getApplicationContext());
        List<GPS> list  =   databaseHelper.getAllGPS(idd);
        Log.d("gps_list", list.size()+"");

        List<LatLng> latLngs = new ArrayList<>();
      //  LatLng[] latLngs = new LatLng[list.size()];

        for(int i = 0; i<list.size(); i++){
            GPS gps = list.get(i);
            String lat = gps.get_Lat();
            String lng = gps.get_lang();

            LatLng latLng = new LatLng(Double.parseDouble(lat),Double.parseDouble(lng));
            latLngs.add(latLng);
           }


        PolygonOptions polygonOptions = new PolygonOptions();
        polygonOptions.strokeWidth(5);
        polygonOptions.fillColor(Color.CYAN);

        for (LatLng latLng : latLngs) {
            builder.include(latLng);
        }
        polygonOptions.addAll(latLngs);

        maps.addPolygon(polygonOptions);

        maps.moveCamera(CameraUpdateFactory.newLatLngBounds(builder.build(), 50));
    }

*/
    //}
    @SuppressLint("StaticFieldLeak")
    public class UploadAsync extends AsyncTask<String, Void, Void> {
        // ProgressDialog
        private final ProgressDialog mProgressDialog;

        public UploadAsync(GetGPS activity) {
            mProgressDialog = new ProgressDialog(activity);
            mProgressDialog.setTitle("Uploading");
            mProgressDialog.setMessage("Uploading please wait.....");
            mProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            mProgressDialog.setCancelable(false);

        }

        protected void onPreExecute() {
            super.onPreExecute();
            mProgressDialog.show();
        }

        @Override
        protected Void doInBackground(String... par) {

            // *** Upload all file to Server
            File file = new File(strSDCardPathName2);
            File[] files = file.listFiles();
            for (File sfil : files) {
                if (sfil.isFile()) {
                    postImage(sfil);
              //      callUploadApi(sfil.getAbsolutePath(), AppController.baseUrl + AppController.strURLUpload);
                }

            }

            //*** Upload data
                 upload();




            return null;
        }

        protected void onPostExecute(Void result) {
            super.onPostExecute(result);


//            Log.d("image_result",result);

           //*** Clear Folder

            showAlert(resMessage);
            mProgressDialog.cancel();

        }

    }



/*
 public  ViewOption getViewOption() {



                return new ViewOptionBuilder()
                        // .withMapsZoom(12.0F)
                         .withStyleName(ViewOption.StyleDef.RETRO)
                        .withCenterCoordinates(new LatLng(LAT, LNG))
                         .withPolygons(getPolygon_2(idd,getApplicationContext()))
                         .withPolylines(getPolyline_1(idd,getApplicationContext()))
                         .withForceCenterMap(false)
                          .withMapsZoom(16)
                         .build();
            }


    @SuppressLint("SetTextI18n")
    private void calculateAreaAndLength(ViewOption viewOption) {
        double area = 0.0;
        double length = 0.0;
        for (ExtraPolygon extraPolygon : viewOption.getPolygons()) {
            area += extraPolygon.getArea();
        }

               area = area * 0.000247;
              totalArea = area;
          areaTextView.setText(String.format(Locale.ENGLISH, "%.2f", area) + " Area in acar ");

          db_helper.INSERT_TOTAL_AREA(idd, area+"");

        for (ExtraPolyline extraPolyline : viewOption.getPolylines()) {
            length += extraPolyline.getLength();
        }

        lengthTextView.setText(String.format(Locale.ENGLISH, "%.2f", length) + "Area in Meter ");

    }


    public static ExtraPolyline getPolyline_1(String mobId, Context context) {

        DatabaseHelper databaseHelper = new DatabaseHelper(context);
        List<GPS> list  =   databaseHelper.getAllGPS(mobId);
        Log.d("gps_list", list.size()+"");
        LatLng[] latLngs = new LatLng[list.size()];

        for(int i = 0; i<list.size(); i++){
            GPS gps = list.get(i);
            String lat = gps.get_Lat();
            String lng = gps.get_lang();
            latLngs[i]= new LatLng(Double.parseDouble(lat),Double.parseDouble(lng));
        }
        return new ExtraPolylineBuilder()
                   .setPoints(latLngs)
                   .setzIndex(0)
                   .setStrokeWidth(5)
                   .setStrokeColor(Color.argb(100, 0, 0, 0))
                   .build();
    }

    public  ExtraPolygon getPolygon_2(String mobId, Context context) {

        DatabaseHelper databaseHelper = new DatabaseHelper(context);
        List<GPS> list  =   databaseHelper.getAllGPS(mobId);
        Log.d("gps_list", list.size()+"");
        LatLng[] latLngs = new LatLng[list.size()];

        for(int i = 0; i<list.size(); i++){
            GPS gps = list.get(i);
            String lat = gps.get_Lat();
            String lng = gps.get_lang();
            latLngs[i]= new LatLng(Double.parseDouble(lat),Double.parseDouble(lng));
        }



        return new ExtraPolygonBuilder()
                .setPoints(latLngs)
                .setzIndex(0)
                .setStrokeWidth(5)
                .setStrokeColor(Color.argb(100, 0, 0, 0))
                .setFillColor(Color.argb(100, 0, 100, 100))
                .build();
    }
*/


    public boolean servicesOK() {
        int result = GooglePlayServicesUtil.isGooglePlayServicesAvailable(this);

        if (result == ConnectionResult.SUCCESS) {
            return true;
        } else if (GooglePlayServicesUtil.isUserRecoverableError(result)) {
            Toast.makeText(this, "service not  found", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(this, "service found", Toast.LENGTH_LONG).show();
        }
        return false;
    }


}
