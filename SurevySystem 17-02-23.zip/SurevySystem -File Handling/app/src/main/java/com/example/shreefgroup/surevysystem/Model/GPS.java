package com.example.shreefgroup.surevysystem.Model;

public class GPS {
    String _serial;
    int _id;
    String _mob_id;
    String _flage;
    String _Lat;
    String _lang;
    String _imei;
    String _Tran_date;

    public GPS() {

    }

    public GPS(String _mob_id, String _Lat, String _lang, String _imei, String timestamp, String id, String flag) {
        this._mob_id = _mob_id;
        this._Lat = _Lat;
        this._lang = _lang;
        this._imei = _imei;
        this._Tran_date = timestamp;
        this._serial = id;
        this._flage = flag;

    }


    public GPS(String yes, String info,String sr_id) {
        this._flage = yes;
        this._mob_id = info;
        this._serial = sr_id;
    }


    public int getID() {
        return this._id;
    }

    public void setID(int id) {
        this._id = id;
    }

    public String get_mob_id() {
        return this._mob_id;
    }

    public void set_mob_id(String mob_id) {
        this._mob_id = mob_id;
    }

    public String get_Lat() {
        return this._Lat;
    }

    public void set_Lat(String _Lat) {
        this._Lat = _Lat;
    }

    public String get_imei() {
        return this._imei;
    }

    public void set_imei(String imei) {
        this._imei = imei;
    }

    public String get_Tran_date() {
        return this._Tran_date;
    }

    public void set_Tran_date(String date) {
        this._Tran_date = date;
    }

    public String get_lang() {
        return this._lang;
    }

    public void set_lang(String lang) {
        this._lang = lang;
    }

    public void set_serila(String serila) {
        this._serial = serila;
    }

    public String get_serial() {
        return this._serial;
    }

    public String get_flage() {
        return this._flage;
    }

    public void set_flage(String flage) {
        this._flage = flage;

    }
}