package com.example.shreefgroup.surevysystem.Ui.Activity;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.StrictMode;
import android.telephony.TelephonyManager;
import android.telephony.gsm.GsmCellLocation;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.androidtrip.plugins.searchablespinner.SearchableSpinner;
import com.androidtrip.plugins.searchablespinner.interfaces.IStatusListener;
import com.androidtrip.plugins.searchablespinner.interfaces.OnItemSelectedListener;
import com.example.shreefgroup.surevysystem.DataBase.DatabaseHelper;
import com.example.shreefgroup.surevysystem.Helping.SimpleListAdapter;
import com.example.shreefgroup.surevysystem.Model.CircleModel.CircleResult;
import com.example.shreefgroup.surevysystem.Model.Grower.GrowerResult;
import com.example.shreefgroup.surevysystem.Model.Master;
import com.example.shreefgroup.surevysystem.Model.Sync.CropCondtion;
import com.example.shreefgroup.surevysystem.Model.Sync.CropVarrity;
import com.example.shreefgroup.surevysystem.Model.Sync.Plantation;
import com.example.shreefgroup.surevysystem.Model.Sync.SowingDistance;
import com.example.shreefgroup.surevysystem.Model.Sync.SurveyType;
import com.example.shreefgroup.surevysystem.Model.Sync.Village;
import com.example.shreefgroup.surevysystem.R;
import com.example.shreefgroup.surevysystem.Utils.AppController;
import com.example.shreefgroup.surevysystem.Utils.Constants;
import com.isapanah.awesomespinner.AwesomeSpinner;

import com.preference.PowerPreference;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Random;


public class TakeSurveyActivity extends AppCompatActivity
        implements ActivityCompat.OnRequestPermissionsResultCallback
{

    final static String strSDCardPathName = AppController.path + "/E_survey" +  "/NewSurvey_images" + "/";
    final static String strSDCardPathName2 = AppController.path + "/E_survey" +  "/New Survey" + "/";

    static final int REQUEST_TAKE_PHOTO = 1;
    private static final int REQUEST_READ_PHONE_STATE = 0;
    static InputStream is = null;
    static JSONObject jObj = null;
    static String json = "";
    public String DeviceId, villageCode= "";

    ArrayList<String> arrayList_circle = new ArrayList<>();
    ArrayList<String> arrayList_village = new ArrayList<>();
    ArrayList<String> arrayList_village_code = new ArrayList<>();

    ArrayList<String> arrayList_crop = new ArrayList<>();
    ArrayList<String> arrayList_surveyType = new ArrayList<>();
    ArrayList<String> arrayList_variety = new ArrayList<>();
    ArrayList<String> arrayList_plantation = new ArrayList<>();

    ArrayList<String> arrayList_sowing = new ArrayList<>();
    ArrayList<String> circle_codeList = new ArrayList<>();




    File image;
    int n = 0;
    int max = 1000;
    int min = 0;
    AppController application;

     File photoFile,storageDir;
     Uri uri;
     String myfileName;
     String timeStamp;
    private int count = 0;

     Button btn_Next;
     EditText edt_NIC, edt_Grower_code,
            edt_Name, edt_Caste, edt_Total_Acreage, edt_Father_name, edt_SqrNo,
             edt_Killa, edt_Note, edt_Total_Yield;

    Spinner spinner_circle,  spinner_village,
             spinner_cropcond, spinner_variety, spinner_plantation,spinner_sowing;


    TextView Surveytype;


    private String grower_name, father_name, caste, growercode;
    private String Villagename, circlename;
    private final int size = 5;
    private final int size2 = 7;
    private final int codesize = 8;

    private String var, search;
     String circle_item ="";
     ArrayAdapter<String> adapt_village;
    private DatabaseHelper db;
    private String num;
    private String ID;

    public  void createFolder() {
        File folder = new File(strSDCardPathName);
        try {
            // Create folder

             boolean f =    folder.mkdir();

             if(f){
                 Toast.makeText(getApplicationContext(),"created",Toast.LENGTH_LONG).show();
             }else {
                 Toast.makeText(getApplicationContext(),"not created",Toast.LENGTH_LONG).show();

             }

        } catch (Exception ex) {
            ex.printStackTrace();
        }



    }

    public  void createFolder2() {

        File folder = new File(strSDCardPathName2);


        try {
            // Create folder

                folder.mkdirs();

        } catch (Exception ex) {
            ex.printStackTrace();
        }


    }

    public static boolean isNetworkAvailable(Context nContext) {
        boolean isNetAvailable = false;
        if (nContext != null) {
            ConnectivityManager mConnectivityManager = (ConnectivityManager) nContext
                    .getSystemService(Context.CONNECTIVITY_SERVICE);
            if (mConnectivityManager != null) {
                boolean mobileNetwork = false;
                boolean wifiNetwork = false;
                boolean mobileNetworkConnecetd = false;
                boolean wifiNetworkConnecetd = false;
                NetworkInfo mobileInfo = mConnectivityManager
                        .getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
                NetworkInfo wifiInfo = mConnectivityManager
                        .getNetworkInfo(ConnectivityManager.TYPE_WIFI);
                if (mobileInfo != null)
                    mobileNetwork = mobileInfo.isAvailable();
                if (wifiInfo != null)
                    wifiNetwork = wifiInfo.isAvailable();
                if (wifiNetwork == true || mobileNetwork == true) {
                    if (mobileInfo != null)
                        mobileNetworkConnecetd = mobileInfo
                                .isConnectedOrConnecting();
                    wifiNetworkConnecetd = wifiInfo.isConnectedOrConnecting();
                }
                isNetAvailable = (mobileNetworkConnecetd || wifiNetworkConnecetd);
            }
        }
        return isNetAvailable;

    }

    public void readfile_Cropcondition() {

        List<CropCondtion> cropCondtionList = db.get_crop_List();

        for(int i = 0 ; i<cropCondtionList.size(); i++){
            String name   = cropCondtionList.get(i).getDescription();
            String code   = cropCondtionList.get(i).getLookupCode();
            arrayList_crop.add(name);

        }


        ArrayAdapter ad = new ArrayAdapter(this, android.R.layout.simple_spinner_item, arrayList_circle);
        spinner_cropcond.setAdapter(ad);

        spinner_cropcond.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


    }


    public void readfile_surveyType() {


        List<SurveyType> surveyTypeList = db.get_survey_type_List();

        for(int i = 0 ; i<surveyTypeList.size(); i++){
            String name   = surveyTypeList.get(i).getDescription();
            arrayList_surveyType.add(name);

        }




       /* SimpleListAdapter  mSimpleListAdapter = new SimpleListAdapter(getApplicationContext(),arrayList_surveyType);
         OnItemSelectedListener mOnItemSelectedListener = new OnItemSelectedListener() {
            @Override
            public void onItemSelected(View view, int position, long id) {
                Toast.makeText(getApplicationContext(), "Item on position " + position + " : " + mSimpleListAdapter.getItem(position) + " Selected", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected() {
                Toast.makeText(getApplicationContext(), "Nothing Selected", Toast.LENGTH_SHORT).show();
            }
        };


        Surveytype.setAdapter(mSimpleListAdapter);
        Surveytype.setOnItemSelectedListener(mOnItemSelectedListener);
        Surveytype.setStatusListener(new IStatusListener() {
            @Override
            public void spinnerIsOpening() {
                Surveytype.hideEdit();

            }

            @Override
            public void spinnerIsClosing() {

            }
        });
*/





    }

    public void readfile_Variety() {



        List<CropVarrity> varvityList = db.get_crop_varrvity_List();

        for(int i = 0 ; i<varvityList.size(); i++){
            String name   = varvityList.get(i).getDescription();
             arrayList_variety.add(name);

        }



        ArrayAdapter ad = new ArrayAdapter(
                this,
                android.R.layout.simple_spinner_item,
                arrayList_variety);

        spinner_variety.setAdapter(ad);


        spinner_variety.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


    }

    public void readfile_Plantation() {


        List<Plantation> circleResultList = db.get_plantation_List();

        for(int i = 0 ; i<circleResultList.size(); i++){
            String name   = circleResultList.get(i).getDescription();
             arrayList_plantation.add(name);
           }



        ArrayAdapter ad = new ArrayAdapter(
                this,
                android.R.layout.simple_spinner_item,
                arrayList_plantation);

        spinner_plantation.setAdapter(ad);

        spinner_plantation.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });





    }

    public void readfile_Circle() {


           List<CircleResult> circleResultList = db.get_circle_List();

           for(int i = 0 ; i<circleResultList.size(); i++){
               String name   = circleResultList.get(i).getDescription();
               String code   = circleResultList.get(i).getLookupCode();
               arrayList_circle.add(name);
               circle_codeList.add(code);
           }



        ArrayAdapter ad
                = new ArrayAdapter(
                this,
                android.R.layout.simple_spinner_item,
                arrayList_circle);

         spinner_circle.setAdapter(ad);

         spinner_circle.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
             @Override
             public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {


                 String v = arrayList_circle.get(position).toString();

                 String vl = spinner_circle.getSelectedItem().toString();




             }
             @Override
             public void onNothingSelected(AdapterView<?> parent) {

             }
         });
        /*
        SimpleListAdapter  circleListAdapter = new SimpleListAdapter(getApplicationContext(),arrayList_circle);
        OnItemSelectedListener mOnItemSelectedListener = new OnItemSelectedListener() {
            @Override
            public void onItemSelected(View view, int position, long id) {
                Toast.makeText(getApplicationContext(), "Item on position " + position + " : " + circleListAdapter.getItem(position) + " Selected", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected() {
                Toast.makeText(getApplicationContext(), "Nothing Selected", Toast.LENGTH_SHORT).show();
            }
        };


        spinner_circle.setAdapter(circleListAdapter);
        spinner_circle.setOnItemSelectedListener(mOnItemSelectedListener);
        spinner_circle.setStatusListener(new IStatusListener() {
            @Override
            public void spinnerIsOpening() {
                spinner_circle.hideEdit();

            }

            @Override
            public void spinnerIsClosing() {

            }
        });

*/


    }

    protected boolean shouldAskPermissions() {
        return (Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP_MR1);
    }

    @TargetApi(Build.VERSION_CODES.M)
    protected void askPermissions() {
        String[] permissions = {
                "android.permission.READ_EXTERNAL_STORAGE",
                "android.permission.WRITE_EXTERNAL_STORAGE",
                "android.permission.READ_PHONE_STATE",
                "android.permission.ACCESS_COARSE_LOCATION",
                "android.permission.ACCESS_CAMERA"
        };
        int requestCode = 200;
        requestPermissions(permissions, requestCode);
    }


    @Override
    protected void onRestoreInstanceState(Bundle outState) {
        super.onRestoreInstanceState(outState);
        outState.putParcelable("uri", uri);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_READ_PHONE_STATE) {

        }
    }



    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putParcelable("uri", uri);
    }

    @androidx.annotation.RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_take_survey);



        edt_NIC = findViewById(R.id.NIC);


        edt_Grower_code = findViewById(R.id.Grower_code);
        edt_Name = findViewById(R.id.gr_name);
        edt_Father_name = findViewById(R.id.gr_FatherName);
        edt_Caste = findViewById(R.id.caste);
        edt_Total_Acreage = findViewById(R.id.TotalAcer);
        edt_Total_Yield = findViewById(R.id.Total_Yield);
        edt_Killa = findViewById(R.id.killa);
        edt_SqrNo = findViewById(R.id.suqure);
        edt_Note = findViewById(R.id.Note);
        btn_Next = findViewById(R.id.next);
        Surveytype =  findViewById(R.id.type);
        Surveytype.setText(Constants.SURVEY_TYPE);

        spinner_sowing =  findViewById(R.id.sowingdist);
        spinner_village =  findViewById(R.id.village);
        spinner_cropcond =  findViewById(R.id.crop_condition);
        spinner_circle =  findViewById(R.id.circle);
        spinner_plantation = findViewById(R.id.plantation);
        spinner_variety = findViewById(R.id.Variety);
        edt_NIC.setKeyListener(null);


        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);

        if (shouldAskPermissions()) {
            askPermissions();
        }
        db = new DatabaseHelper(this);

        readfile_Circle();
        readfile_Cropcondition();
        readfile_Sowing();
        ReadFile_village();
        readfile_Variety();
        readfile_Plantation();
        createFolder2();
        createFolder();


         DeviceId = AppController.getUuid(TakeSurveyActivity.this);
         application = (AppController) getApplicationContext();

        try {
            get_survey_is();

        } catch (IOException e) {
            e.printStackTrace();
        }



        edt_NIC.setOnFocusChangeListener((v, hasFocus) -> {
            if (hasFocus) {
                edt_NIC.callOnClick();
            }
        });

        edt_NIC.setOnClickListener(v -> password());


        edt_Grower_code.addTextChangedListener(new TextWatcher() {

            public void onTextChanged(CharSequence s, int start, int before, int count) {

                if (!(edt_Grower_code.getText().toString().length() < 5)) {
                    if (edt_Grower_code.getText().toString().length() == codesize)     //size as per your requirement
                    {
                        edt_Name.requestFocus();
                    }
                }
            }

            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            public void afterTextChanged(Editable s) {}

        });


        edt_Total_Acreage.addTextChangedListener(new TextWatcher() {

            public void onTextChanged(CharSequence s, int start, int before, int count) {

                if (edt_Total_Acreage.getText().toString().length() < 6) {
                    if ((edt_Total_Acreage.getText().toString().length() == 4) || (edt_Total_Acreage.getText().toString().length() == 5))     //size as per your requirement
                    {
                        edt_Total_Yield.requestFocus();
                    }
                } else {
                    edt_Total_Acreage.setError("maximum 10 digit");
                }
            }

            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            public void afterTextChanged(Editable s) {}

        });


        edt_Total_Yield.addTextChangedListener(new TextWatcher() {

            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (edt_Total_Yield.getText().toString().length() < 6) {
                    if ((edt_Total_Yield.getText().toString().length() == 5) || (edt_Total_Yield.getText().toString().length() == 4))     //size as per your requirement
                    {
                        edt_Killa.requestFocus();
                    }
                } else {
                    edt_Total_Yield.setError("maximum 10 digit");
                }
            }

            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {

            }

            public void afterTextChanged(Editable s) {


            }

        });

        edt_Killa.addTextChangedListener(new TextWatcher() {

            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (edt_Killa.getText().toString().length()>0) {
//                    if ((edt_Killa.getText().toString().length() == 4) || (edt_Killa.getText().toString().length() == 5))     //size as per your requirement
//                    {
//                        edt_SqrNo.requestFocus();
//                    }
                } else {
                    edt_Killa.setError("Enter Rquired Fields");
                }
            }

            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {

            }

            public void afterTextChanged(Editable s) {


            }

        });









    /*    try {
            spinner_circle.setOnSpinnerItemClickListener((position, itemAtPosition) -> {

                circle_item = arrayList_circle.get(position);

                if (!circle_item.equals("")) {
                    List<Village> tempVillageList = db.get_village_List(itemAtPosition);
                    List<String> villages = new ArrayList<>();

                    try {
                        if (tempVillageList.size() > 0) {

                            for (int i = 0; i < tempVillageList.size(); i++) {

                                String desc = tempVillageList.get(i).getDescription();
                                villages.add(desc);
                            }
                            Log.d("villages", villages.size() + "");

                          *//*  ArrayAdapter<String> villageAdoper = new
                                    ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_spinner_item, villages);

                            spinner_village.setAdapter(villageAdoper);*//*

                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

            });
        }catch (Exception e){e.printStackTrace();}

*/










        btn_Next.setOnClickListener(v -> {


            if ((edt_Killa.getText().toString().length() != 0) &&
                    (edt_SqrNo.getText().toString().length() != 0) &&
                    (edt_Name.getText().toString().length() != 0) &&
                    (edt_NIC.getText().toString().length() != 0) &&
                    (edt_Father_name.getText().toString().length() != 0) &&
                    (edt_Caste.getText().toString().length() != 0) &&
                    (edt_Total_Yield.getText().toString().length() != 0) &&
                    (edt_Total_Acreage.getText().toString().length() != 0))
            {
                try {
                    write_currntdata();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                capturImage();
            } else {
                Toast.makeText(TakeSurveyActivity.this, "please enter the required credentials", Toast.LENGTH_SHORT).show();
            }


        });

    }


    public void capturImage() {
        count++;
        photoFile = null;
        Intent takePictureIntent;
        takePictureIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {

            try {
                photoFile = createImageFile();

            } catch (IOException ex) {
                ex.printStackTrace();
            }
            if (photoFile != null) {
                startActivityForResult(takePictureIntent, REQUEST_TAKE_PHOTO);

            }

       }
    }

    private File createImageFile() throws IOException {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd_hhmmss", Locale.getDefault());
        timeStamp = dateFormat.format(new Date());
        Random generator = new Random();

        n = generator.nextInt((max - n) + 1) + n;

       /* if (count == 1) {
            ReadFile();

        }
*/

       String unitId = PowerPreference.getDefaultFile().getString(Constants.USER_UNIT,"");
       String deviceID =  PowerPreference.getDefaultFile().getString(Constants.DEVICE_ID,"");
      String userId =   PowerPreference.getDefaultFile().getString(Constants.USER_ID,"");
        String myfileName = unitId + ("-") + userId + ("-") + timeStamp + ("-") + deviceID+ ("-") + n /*+ ".PNG"*/;
        storageDir = new File(strSDCardPathName);
        image = File.createTempFile(myfileName, /* prefix */
                ".png", /* suffix */
                storageDir /* directory */
        );

        return image;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if ((requestCode == REQUEST_TAKE_PHOTO) && (resultCode == RESULT_OK)) {
            Bitmap bmp = (Bitmap) data.getExtras().get("data");
            ByteArrayOutputStream stream = new ByteArrayOutputStream();
            bmp.compress(Bitmap.CompressFormat.JPEG, 100, stream);
            byte[] byteArray = stream.toByteArray();
            FileOutputStream fo = null;



            String unitId = PowerPreference.getDefaultFile().getString(Constants.USER_UNIT,"");
            String deviceID =  PowerPreference.getDefaultFile().getString(Constants.DEVICE_ID,"");
            String userId =   PowerPreference.getDefaultFile().getString(Constants.USER_ID,"");
            ID =   PowerPreference.getDefaultFile().getString(Constants.ENTRY_FILE_NAME,"");
            String name = unitId + ("-") + userId + ("-") + timeStamp + ("-") + deviceID + "-" + count + ".jpg";
            try {
                fo = new FileOutputStream(new File(strSDCardPathName2 + name));
                db.update(new Master(count, ID, name));
                image.delete();

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }

            try {
                fo.write(byteArray);
                fo.flush();
                fo.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            if (count > 3) {
                startActivity(new Intent(TakeSurveyActivity.this, GetGPS.class));
            } else {
                capturImage();
            }

        }
        if (resultCode == RESULT_CANCELED) {
            count--;
            capturImage();
            Toast.makeText(getApplicationContext(),
                    "User cancelled image capture", Toast.LENGTH_SHORT)
                    .show();

        } else {
            Toast.makeText(getApplicationContext(),
                    "save Image", Toast.LENGTH_SHORT)
                    .show();
        }


    }

    public void password() {

        LayoutInflater li = LayoutInflater.from(TakeSurveyActivity.this);
        View promptsView = li.inflate(R.layout.prompts, null);

        final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                TakeSurveyActivity.this);
        alertDialogBuilder.setView(promptsView);

        final EditText userInput = promptsView
                .findViewById(R.id.editTextDialogUserInput);
        final EditText userInput2 = promptsView
                .findViewById(R.id.editTextDialogUserInput2);
        final EditText userInput3 = promptsView
                .findViewById(R.id.editTextDialogUserInput3);
        userInput.addTextChangedListener(new TextWatcher() {

            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (userInput.getText().toString().length() == size)     //size as per your requirement
                {
                    userInput2.requestFocus();
                }

            }

            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            public void afterTextChanged(Editable s) {}

        });
        userInput2.addTextChangedListener(new TextWatcher() {

            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (userInput2.getText().toString().length() == size2)     //size as per your requirement
                {
                    userInput3.requestFocus();
                }

            }

            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            public void afterTextChanged(Editable s) {}

        });
        alertDialogBuilder
                .setCancelable(false)
                .setPositiveButton("OK",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                edt_NIC.setText(userInput.getText().toString() + "-" +
                                        userInput2.getText().toString() + "-" +
                                        userInput3.getText().toString());
                                try {
                                    if (isNetworkAvailable(getApplicationContext())) {
                                     //   OpenTheGrower();
                                    } else {
                                        Toast.makeText(getApplicationContext(), "Internet connection is week:", Toast.LENGTH_SHORT).show();
                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }


                        })
                .setNegativeButton("Cancel", (dialog, id) -> dialog.cancel());

             AlertDialog alertDialog = alertDialogBuilder.create();
             alertDialog.show();
    }

   /* private String decodeFile(String path, int DESIREDWIDTH, int DESIREDHEIGHT) {
        String strMyImagePath = null;
        Bitmap scaledBitmap = null;
        try {
            // Part 1: Decode image
            Bitmap unscaledBitmap = ScalingUtilities.decodeFile(path, DESIREDWIDTH, DESIREDHEIGHT, ScalingUtilities.ScalingLogic.FIT);

            if (!(unscaledBitmap.getWidth() <= DESIREDWIDTH && unscaledBitmap.getHeight() <= DESIREDHEIGHT)) {
                // Part 2: Scale image
                scaledBitmap = ScalingUtilities.createScaledBitmap(unscaledBitmap, DESIREDWIDTH, DESIREDHEIGHT, ScalingUtilities.ScalingLogic.FIT);
            } else {
                unscaledBitmap.recycle();
                return path;

            }
            ReadFile();


            for (int i = 0; i < Growerinf0.size(); i++) {
                ID = Growerinf0.get(0);
            }




            String extr = Environment.getExternalStorageDirectory().toString();
            File mFolder = new File(extr + "/New Survey");
            if (!mFolder.exists()) {
                mFolder.mkdir();
            }
            Random generator = new Random();
            n = generator.nextInt(n);

            for (int i = 0; i < arrayList5.size(); i++) {
                tv = arrayList5.get(0).toString();
                tv2 = arrayList5.get(1).toString();
                tv3 = arrayList5.get(2).toString();
                tv4 = arrayList5.get(3).toString();
                tv5 = arrayList5.get(4).toString();
                tv6 = arrayList5.get(5).toString();
                tv7 = arrayList5.get(6).toString();
                tv8 = arrayList5.get(7).toString();
                i = i + 8;
            }
            if (count == 1) {
                myfileName = tv5 + ("-") + tv6 + ("-") + timeStamp + ("-") + DeviceId.substring(10, 15) + ("-") + n + (".PNG");
                String fistname = myfileName.toString();
                db.update(new Master(count, ID, fistname));
            }
            if (count == 2) {
                myfileName = tv5 + ("-") + tv6 + ("-") + timeStamp + ("-") + DeviceId.substring(10, 15) + ("-") + n + (".PNG");
                String secondname = myfileName.toString();
                db.update(new Master(count, ID, secondname));

            }
            if (count == 3) {
                myfileName = tv5 + ("-") + tv6 + ("-") + timeStamp + ("-") + DeviceId.substring(10, 15) + ("-") + n + (".PNG");
                String third = myfileName.toString();
                db.update(new Master(count, ID, third));

            }
            if (count == 4) {
                myfileName = tv5 + ("-") + tv6 + ("-") + timeStamp + ("-") + DeviceId.substring(10, 15) + ("-") + n + (".PNG");
                String fourth = myfileName.toString();
                db.update(new Master(count, ID, fourth));

            }

            File f = new File(mFolder.getAbsolutePath(), myfileName);

            strMyImagePath = f.getAbsolutePath();
            FileOutputStream fos = null;
            try {
                fos = new FileOutputStream(f);
                scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 90, fos);
                fos.flush();
                fos.close();
                // boolean deleted = f.delete();

            } catch (FileNotFoundException e) {

                e.printStackTrace();
            } catch (Exception e) {

                e.printStackTrace();
            }

            scaledBitmap.recycle();
        } catch (Throwable e) {
            e.printStackTrace();
        }

        if (strMyImagePath == null) {
            return path;
        }
        return strMyImagePath;

    }

    public void CountFolder2() {
        File file = new File(Environment.getExternalStorageDirectory() + "/New Survey" + "/");
        File[] list = file.listFiles();
        //  int counter = 0;
        for (File f : list) {
            String name = f.getName();
            counter++;
            if (name.endsWith(".png") || name.endsWith(".mp3") || name.endsWith(".some media extention")) {

            }
        }
        badge = new BadgeView(this, btnqueue);
        badge.setText("pending:" + counter);
        badge.show();

    }
*/
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }


    public void write_currntdata() {

       // ReadFile();


        try {
            String t1 = Surveytype.getText().toString();
            String t2 = edt_NIC.getText().toString();
            String t3 = edt_Grower_code.getText().toString();
            String t4 = edt_Name.getText().toString();
            String t5 = edt_Father_name.getText().toString();
            String t6 = edt_Caste.getText().toString();

            String t7 = spinner_circle.getSelectedItem().toString();


            String t8 = spinner_village.getSelectedItem().toString();
            String t9 = edt_Total_Acreage.getText().toString();
            String t10 = edt_Total_Yield.getText().toString();
            String t11 = edt_Killa.getText().toString();
            String t12 = edt_SqrNo.getText().toString();
            String t13 = spinner_sowing.getSelectedItem().toString();
            String t14 = spinner_cropcond.getSelectedItem().toString();
            String t15 = spinner_variety.getSelectedItem().toString();
            String t16 = spinner_plantation.getSelectedItem().toString();
            String t17 = edt_Note.getText().toString();

          num = PowerPreference.getDefaultFile().getString(Constants.ENTRY_FILE_NAME,"");

            db.Insert_Master(new Master(num, t1, t2,
                    t3, t4, t5, t6, t7,
                    t8, t9, t10, t11,
                    t12, t13, t14, t15,
                    t16, t17, DeviceId, "No", "0.00"));

        }catch (Exception e){e.printStackTrace();}
    }



    public void ReadFile_village() {


        if(arrayList_circle.size()>0) {

            String circleName = arrayList_circle.get(0);
            List<Village> tempList = db.get_village_List(circleName);


            for (int i = 0; i < tempList.size(); i++) {
                String name = tempList.get(i).getDescription();
                String code = tempList.get(i).getLookupCode();
                Log.d("village_name", name);
                arrayList_village.add(name);
                arrayList_village_code.add(code);

            }


            ArrayAdapter ad = new ArrayAdapter(
                    this,
                    android.R.layout.simple_spinner_item,
                    arrayList_village);

            spinner_village.setAdapter(ad);

            spinner_village.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });


        }



      /*  ArrayAdapter<String> villageAdoper = new
                ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_spinner_item, arrayList_village);

       spinner_village.setAdapter(villageAdoper);*/

    }

    public void readfile_Sowing() {


        List<SowingDistance> sowingList = db.get_sowing_list();

        for(int i = 0 ; i<sowingList.size(); i++){
            String name   = sowingList.get(i).getSowingDistance();

            arrayList_sowing.add(name);

        }


        ArrayAdapter ad = new ArrayAdapter(
                this,
                android.R.layout.simple_spinner_item,
                arrayList_sowing);

        spinner_sowing.setAdapter(ad);

        spinner_sowing.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }

    private void OpenTheGrower() throws JSONException, IOException {
        String cnic_no = edt_NIC.getText().toString();


     /*   DatabaseHelper databaseHelper = new DatabaseHelper(getApplicationContext());

         GrowerResult growerResult = databaseHelper.get_grower_info(cnic_no);

        edt_Grower_code.setText(growerResult.getGrowerCode());
        edt_Name.setText(growerResult.getGrowerName());
        edt_Father_name.setText(growerResult.getGrowerFName());
        edt_Caste.setText(growerResult.getGrowerCaste());
        String temp_t = growerResult.getVillageCode();
*/


        String url = AppController.baseUrl + AppController.GrowerInfo + "?CNIC_NO=" + cnic_no.toString();
        try {
            JSONObject object = new JSONObject(String.valueOf((getJSONUrl(url))));
            JSONArray Jarray = object.getJSONArray("Result");
            for (int i = 0; i < Jarray.length(); i++) {
                JSONObject jsonObject = Jarray.getJSONObject(i);
                grower_name = jsonObject.getString("GROWER_NAME");
                father_name = jsonObject.getString("FATHER_NAME");
                caste = jsonObject.getString("CASTE");
                growercode = jsonObject.getString("GROWER_CODE");
                Villagename = jsonObject.getString("VILLAGE_NAME");
                circlename = jsonObject.getString("CIRCLE_NAME");
                application.circlecode = jsonObject.getString("CIRCLE_CODE");
                application.villagecode = jsonObject.getString("VILLAGE_CODE");
                edt_Grower_code.setText(growercode);
                edt_Name.setText(grower_name);
                edt_Father_name.setText(father_name);

               /*  String temp_t  = application.villagecode +"-"+  Villagename.trim();
                 Log.d("temp_k", "first : "+ temp_t);
                Toast.makeText(getApplicationContext(),temp_t, Toast.LENGTH_SHORT).show();

*/


                edt_Caste.setText(caste);
                if (grower_name != null) {
                    edt_Name.setEnabled(false);
                    edt_Father_name.setEnabled(false);
                    edt_Grower_code.setEnabled(false);
                    edt_Caste.setEnabled(false);

                }
            }
            if (Jarray.length() == 0) {
                edt_Name.setEnabled(true);
                edt_Name.setText("");
                edt_Father_name.setEnabled(true);
                edt_Father_name.setText("");
                edt_Grower_code.setEnabled(true);
                edt_Grower_code.setText("");
                edt_Caste.setEnabled(true);
                edt_Caste.setText("");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public JSONObject getJSONUrl(String url1) throws IOException {
        URL url = new URL(url1);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        is = (InputStream) conn.getContent();
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(
                    is, StandardCharsets.ISO_8859_1), 8);
            StringBuilder sb = new StringBuilder();
            String line = null;
            while ((line = reader.readLine()) != null) {
                sb.append(line + "\n");
            }
            is.close();
            json = sb.toString();
        } catch (Exception e) {
            Log.e("Buffer Error", "Error converting result " + e);
        }

        try {
            jObj = new JSONObject(json);
        } catch (JSONException e) {
            Log.e("JSON Parser", "Error parsing data " + e);
        }

        return jObj;

    }

    protected void onStart() {
        super.onStart();
    }

    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onPause() {
        super.onPause();

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }




    private void get_survey_is() throws IOException {
       // clearTheFile();
        Random generator = new Random();
        int n1 = generator.nextInt((max - n)) + min;
        @SuppressLint("SimpleDateFormat")
        String timeStamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
        String id = DeviceId.substring(11, 15) + "-" + timeStamp + "-" + n1;

        PowerPreference.getDefaultFile().setString(Constants.ENTRY_FILE_NAME, id);
      //  FileHelper_Growr_info.saveToFile(String.valueOf(id));
    }
}