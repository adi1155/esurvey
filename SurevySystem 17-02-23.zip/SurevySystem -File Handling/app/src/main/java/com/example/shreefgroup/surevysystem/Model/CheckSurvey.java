
package com.example.shreefgroup.surevysystem.Model;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;


public class CheckSurvey implements Serializable {

    @SerializedName("SurveyResult")
    @Expose
    private SurveyResult surveyResult;
    @SerializedName("status")
    @Expose
    private String status;

    public SurveyResult getSurveyResult() {
        return surveyResult;
    }

    public void setSurveyResult(SurveyResult surveyResult) {
        this.surveyResult = surveyResult;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

}
