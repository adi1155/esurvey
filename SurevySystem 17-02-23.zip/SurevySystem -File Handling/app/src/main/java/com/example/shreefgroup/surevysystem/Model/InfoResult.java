
package com.example.shreefgroup.surevysystem.Model;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;


public class InfoResult implements Serializable {

    @SerializedName("TRAN_ID")
    @Expose
    private String tranId;
    @SerializedName("TRAN_DATE")
    @Expose
    private String tranDate;
    @SerializedName("SURVEY_ID")
    @Expose
    private String surveyId;
    @SerializedName("SURVEY_TYPE")
    @Expose
    private String surveyType;
    @SerializedName("CNIC_NO")
    @Expose
    private String cnicNo;
    @SerializedName("GROWER_CODE")
    @Expose
    private String growerCode;
    @SerializedName("GROWER_NAME")
    @Expose
    private String growerName;
    @SerializedName("FATHER_NAME")
    @Expose
    private String fatherName;
    @SerializedName("CASTE")
    @Expose
    private String caste;
    @SerializedName("CIRCLE_CODE")
    @Expose
    private Object circleCode;
    @SerializedName("VILLAGE_CODE")
    @Expose
    private Object villageCode;
    @SerializedName("TOTAL_ACR")
    @Expose
    private String totalAcr;
    @SerializedName("TOTAL_YIELD")
    @Expose
    private String totalYield;
    @SerializedName("KILLA")
    @Expose
    private String killa;
    @SerializedName("SQUARE_NO")
    @Expose
    private String squareNo;
    @SerializedName("CROP_CONDITION")
    @Expose
    private String cropCondition;
    @SerializedName("VARIETY")
    @Expose
    private String variety;
    @SerializedName("PLANTATION")
    @Expose
    private String plantation;
    @SerializedName("NOTE")
    @Expose
    private String note;
    @SerializedName("IMEI")
    @Expose
    private String imei;
    @SerializedName("CELL_ID")
    @Expose
    private String cellId;
    @SerializedName("FILENAME")
    @Expose
    private String filename;
    @SerializedName("FILENAME2")
    @Expose
    private String filename2;
    @SerializedName("FILENAME3")
    @Expose
    private String filename3;
    @SerializedName("COMPANY_CODE")
    @Expose
    private String companyCode;
    @SerializedName("SURVEYOR_CODE")
    @Expose
    private String surveyorCode;
    @SerializedName("ACCEPTED")
    @Expose
    private Object accepted;
    @SerializedName("FILENAME4")
    @Expose
    private String filename4;
    @SerializedName("REMARKS")
    @Expose
    private Object remarks;
    @SerializedName("SOWING")
    @Expose
    private Object sowing;
    @SerializedName("SOWING_DISTANCE")
    @Expose
    private String sowingDistance;
    @SerializedName("CREATION_DATE")
    @Expose
    private String creationDate;
    @SerializedName("MODIFICATION_DATE")
    @Expose
    private Object modificationDate;
    @SerializedName("CIRCLE_NAME")
    @Expose
    private String circleName;
    @SerializedName("VILLAGE_NAME")
    @Expose
    private String villageName;
    @SerializedName("MAP_AREA")
    @Expose
    private Object mapArea;
    @SerializedName("SERIAL_NO")
    @Expose
    private Object serialNo;
    @SerializedName("MOB_ID")
    @Expose
    private String mobId;
    @SerializedName("USER_NAME")
    @Expose
    private Object userName;
    @SerializedName("MAP_AREA_MOB")
    @Expose
    private String mapAreaMob;

    public String getTranId() {
        return tranId;
    }

    public void setTranId(String tranId) {
        this.tranId = tranId;
    }

    public String getTranDate() {
        return tranDate;
    }

    public void setTranDate(String tranDate) {
        this.tranDate = tranDate;
    }

    public String getSurveyId() {
        return surveyId;
    }

    public void setSurveyId(String surveyId) {
        this.surveyId = surveyId;
    }

    public String getSurveyType() {
        return surveyType;
    }

    public void setSurveyType(String surveyType) {
        this.surveyType = surveyType;
    }

    public String getCnicNo() {
        return cnicNo;
    }

    public void setCnicNo(String cnicNo) {
        this.cnicNo = cnicNo;
    }

    public String getGrowerCode() {
        return growerCode;
    }

    public void setGrowerCode(String growerCode) {
        this.growerCode = growerCode;
    }

    public String getGrowerName() {
        return growerName;
    }

    public void setGrowerName(String growerName) {
        this.growerName = growerName;
    }

    public String getFatherName() {
        return fatherName;
    }

    public void setFatherName(String fatherName) {
        this.fatherName = fatherName;
    }

    public String getCaste() {
        return caste;
    }

    public void setCaste(String caste) {
        this.caste = caste;
    }

    public Object getCircleCode() {
        return circleCode;
    }

    public void setCircleCode(Object circleCode) {
        this.circleCode = circleCode;
    }

    public Object getVillageCode() {
        return villageCode;
    }

    public void setVillageCode(Object villageCode) {
        this.villageCode = villageCode;
    }

    public String getTotalAcr() {
        return totalAcr;
    }

    public void setTotalAcr(String totalAcr) {
        this.totalAcr = totalAcr;
    }

    public String getTotalYield() {
        return totalYield;
    }

    public void setTotalYield(String totalYield) {
        this.totalYield = totalYield;
    }

    public String getKilla() {
        return killa;
    }

    public void setKilla(String killa) {
        this.killa = killa;
    }

    public String getSquareNo() {
        return squareNo;
    }

    public void setSquareNo(String squareNo) {
        this.squareNo = squareNo;
    }

    public String getCropCondition() {
        return cropCondition;
    }

    public void setCropCondition(String cropCondition) {
        this.cropCondition = cropCondition;
    }

    public String getVariety() {
        return variety;
    }

    public void setVariety(String variety) {
        this.variety = variety;
    }

    public String getPlantation() {
        return plantation;
    }

    public void setPlantation(String plantation) {
        this.plantation = plantation;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public String getCellId() {
        return cellId;
    }

    public void setCellId(String cellId) {
        this.cellId = cellId;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public String getFilename2() {
        return filename2;
    }

    public void setFilename2(String filename2) {
        this.filename2 = filename2;
    }

    public String getFilename3() {
        return filename3;
    }

    public void setFilename3(String filename3) {
        this.filename3 = filename3;
    }

    public String getCompanyCode() {
        return companyCode;
    }

    public void setCompanyCode(String companyCode) {
        this.companyCode = companyCode;
    }

    public String getSurveyorCode() {
        return surveyorCode;
    }

    public void setSurveyorCode(String surveyorCode) {
        this.surveyorCode = surveyorCode;
    }

    public Object getAccepted() {
        return accepted;
    }

    public void setAccepted(Object accepted) {
        this.accepted = accepted;
    }

    public String getFilename4() {
        return filename4;
    }

    public void setFilename4(String filename4) {
        this.filename4 = filename4;
    }

    public Object getRemarks() {
        return remarks;
    }

    public void setRemarks(Object remarks) {
        this.remarks = remarks;
    }

    public Object getSowing() {
        return sowing;
    }

    public void setSowing(Object sowing) {
        this.sowing = sowing;
    }

    public String getSowingDistance() {
        return sowingDistance;
    }

    public void setSowingDistance(String sowingDistance) {
        this.sowingDistance = sowingDistance;
    }

    public String getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(String creationDate) {
        this.creationDate = creationDate;
    }

    public Object getModificationDate() {
        return modificationDate;
    }

    public void setModificationDate(Object modificationDate) {
        this.modificationDate = modificationDate;
    }

    public String getCircleName() {
        return circleName;
    }

    public void setCircleName(String circleName) {
        this.circleName = circleName;
    }

    public String getVillageName() {
        return villageName;
    }

    public void setVillageName(String villageName) {
        this.villageName = villageName;
    }

    public Object getMapArea() {
        return mapArea;
    }

    public void setMapArea(Object mapArea) {
        this.mapArea = mapArea;
    }

    public Object getSerialNo() {
        return serialNo;
    }

    public void setSerialNo(Object serialNo) {
        this.serialNo = serialNo;
    }

    public String getMobId() {
        return mobId;
    }

    public void setMobId(String mobId) {
        this.mobId = mobId;
    }

    public Object getUserName() {
        return userName;
    }

    public void setUserName(Object userName) {
        this.userName = userName;
    }

    public String getMapAreaMob() {
        return mapAreaMob;
    }

    public void setMapAreaMob(String mapAreaMob) {
        this.mapAreaMob = mapAreaMob;
    }

}
