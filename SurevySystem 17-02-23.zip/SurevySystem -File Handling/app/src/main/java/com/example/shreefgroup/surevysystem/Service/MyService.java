package com.example.shreefgroup.surevysystem.Service;

/**
 * Created by ashfaq on 7/20/2017.
 */

import android.app.ProgressDialog;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.StrictMode;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.example.shreefgroup.surevysystem.DataBase.DatabaseHelper;

import com.example.shreefgroup.surevysystem.Model.Master;
import com.example.shreefgroup.surevysystem.Model.GPS;
import com.example.shreefgroup.surevysystem.Model.MySingleton;
import com.example.shreefgroup.surevysystem.Utils.AppController;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MyService extends Service {
    final static String SaveGps = "SaveGPS.txt";
    final static String path = Environment.getExternalStorageDirectory() + "/ESurvey" + "/";
    final static String fileName = "Grower_data.txt";
    final static String SaveGPS = "SaveGPS.txt";
    final static String strSDCardPathName = Environment.getExternalStorageDirectory() + "/NewSurvey_images" + "/";
    final static String strSDCardPathName2 = Environment.getExternalStorageDirectory() + "/New Survey" + "/";
    final static String file = "SaveGPS.txt";
    static String json = "";
    static InputStream is = null;
    static JSONObject jObj = null;
    private static final String TAG = "MyService";
    private final int runTime = 3000;
    AppController application;
    ArrayList<String> arrayList5 = new ArrayList<String>();
    ArrayList<String> arrayList6 = new ArrayList<String>();
    int i = 0;
    private final ArrayList<String> Growerinf0 = new ArrayList<String>();
    private String mfilename2, mfilename, mfilename3, mfilename4;
    private Runnable runnable;
    private ProgressDialog pDialog;
    private final StringRequest stringRequest = null;
    private DatabaseHelper db_helper;
    private String saleperson_id, party_code, Title, Address, region;
    private String title;
    private String pcode;
    private String pAddress;
    private String salePid;
    private String regionid;
    private String itemcode;
    private String itemname;
    private String sale;
    private String replace;
    private String Return;
    private String Foc;
    private String Dis;
    private String rate;
    private String net;
    private String Areaid;
    private String total;
    private String Order;
    private String Tran_date;
    private final int flage = 0;
    private String DeviceId;
    private AppController Application;
    private String descrip;
    private String terms;
    private String info;
     String tv, tv2, tv3, tv4, tv5, tv6, tv7, tv8, tv9, tv10, tv11, tv12, tv13, tv14, tv15, tv16,
            textv, textv2, textv3, textv4, textv5, textv6, textv7, textv8, textv9, textv10, textv11,
            textv12, textv13, textv14, textv15, textv16,textv17, textv19, textv18, textv20, textv21,
             textv22, srv_id;
     int divider = 0;

    public static boolean isNetworkAvailable(Context nContext) {
        boolean isNetAvailable = false;
        if (nContext != null) {
            ConnectivityManager mConnectivityManager = (ConnectivityManager) nContext
                    .getSystemService(Context.CONNECTIVITY_SERVICE);
            if (mConnectivityManager != null) {
                boolean mobileNetwork = false;
                boolean wifiNetwork = false;
                boolean mobileNetworkConnecetd = false;
                boolean wifiNetworkConnecetd = false;
                NetworkInfo mobileInfo = mConnectivityManager
                        .getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
                NetworkInfo wifiInfo = mConnectivityManager
                        .getNetworkInfo(ConnectivityManager.TYPE_WIFI);
                if (mobileInfo != null)
                    mobileNetwork = mobileInfo.isAvailable();
                if (wifiInfo != null)
                    wifiNetwork = wifiInfo.isAvailable();
                if (wifiNetwork == true || mobileNetwork == true) {
                    if (mobileInfo != null)
                        mobileNetworkConnecetd = mobileInfo
                                .isConnectedOrConnecting();
                    wifiNetworkConnecetd = wifiInfo.isConnectedOrConnecting();
                }
                isNetAvailable = (mobileNetworkConnecetd || wifiNetworkConnecetd);
            }
        }
        return isNetAvailable;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        divider = 0;
        db_helper = new DatabaseHelper(this);
        application = (AppController) getApplicationContext();
        if (android.os.Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy =
                    new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }
        application.handler = new Handler();

        runnable = new Runnable() {
            @Override
            public void run() {
                if (isNetworkAvailable(MyService.this)) {
                    application.handler.postDelayed(runnable, runTime);
                    int record = db_helper.getItemsCount();
                    if (record > 0) {
                        list_data();
                    } else {
                        application.handler.removeCallbacksAndMessages(null);
                    }
                  /*  try {
                        Thread.sleep(5000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }*/
                    int record2 = db_helper.Count_ITEM_LIST();
                    if (record2 > 0) {
                        insert_gps();
                    } else {
                        application.handler.removeCallbacksAndMessages(null);
                    }
                }
            }
        };
        application.handler.post(runnable);

    }

    public void ReadFile() {
        StringBuilder text = new StringBuilder();
        Growerinf0.clear();
        try {
            BufferedReader br = new BufferedReader(new FileReader(path + fileName));
            String line;
            while ((line = br.readLine()) != null) {
                String[] lineWords = line.split(",");
                for (String singleWord : lineWords) {
                    Growerinf0.add(singleWord);
                }
            }
            br.close();
        } catch (IOException e) {
        }

    }

    public void list_data() {
        readfile();
        ReadFile();
        try {
            List<Master> A = db_helper.getAll_Master();
            for (Master obj : A) {
                srv_id = obj.get_mob_id();
                textv = obj.get_survey_type();
                textv2 = obj.get_cnic();
                textv3 = obj.get_Grower_code();
                textv4 = obj.get_name();
                textv5 = obj.get_father_name();
                textv6 = obj.get_cast();
                textv7 = obj.get_circle();
                textv8 = obj.get_village();
                textv9 = obj.get_acrage();
                textv10 = obj.get_yield();
                textv11 = obj.get_killa();
                textv12 = obj.get_sqr_no();
                textv13 = obj.get_sowing();
                textv14 = obj.get_crop_cond();
                textv15 = obj.get_veriety();
                textv16 = obj.get_plantation();
                textv17 = obj.get_note();
                textv18 = obj.get_imei();
                textv19 = obj.get_filename();
                textv20 = obj.get_filename2();
                textv21 = obj.get_filename3();
                textv22 = obj.get_filename4();
                savedata(srv_id,
                        textv,//mobid
                        textv2,//type
                        textv3,//imei
                        textv4,//cnic
                        textv5,//code
                        textv6,//name
                        textv7,//father
                        textv8,//cast
                        textv9,//circle
                        textv10,//village
                        textv11,//acrage
                        textv12,//yield
                        textv13,//killa
                        textv14,//sqr
                        textv15,//swing
                        textv16,//cond
                        textv17,//veriety
                        textv18,//note
                        textv19,//img
                        textv20,//img
                        textv21, textv22);

            }

        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    public void insert_gps() {

        List<GPS> B = db_helper.get_AllGPS();
        for (GPS ob : B) {
            String serial_id = ob.get_serial();
            String surveyid = ob.get_mob_id();
            String longitude1 = ob.get_Lat();
            String latitude1 = ob.get_lang();
            String imei = ob.get_imei();
            String timestamp = ob.get_Tran_date();
            try {
                SaveGPS(serial_id, surveyid, latitude1, longitude1, imei, timestamp);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void SaveGPS(String serial_id, final String surveyid, String latitude1, String longitude1, String imei, String timestamp) throws IOException {
        final String sr_id = String.valueOf(serial_id);
        final String mob_id = surveyid;
        final String lat_1 = latitude1;
        final String long_1 = longitude1;
        final String imei_no = imei;
        final String timestampp = timestamp;
        String url_gps = AppController.baseUrl + AppController.GetGps;
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url_gps,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                      //  db_helper.INSERT_FLAG2(new GPS("Yes", mob_id));

                        Toast.makeText(getApplicationContext(), "Inserting please wait...", Toast.LENGTH_SHORT).show();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (volleyError.networkResponse == null) {
                            if (volleyError.getClass().equals(TimeoutError.class)) {
                                Toast.makeText(getApplicationContext(), "Oops. Network Timeout error!", Toast.LENGTH_LONG).show();
                            }
                        }
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put(AppController.KEY_LAT, lat_1);
                params.put(AppController.KEY_LNG, long_1);
                params.put(AppController.KEY_survey_id, mob_id);
                params.put(AppController.KEY_IMEI_NO, imei_no);
                params.put(AppController.KEY_id, sr_id);
                params.put(AppController.KEY_date, timestampp);
                return params;
            }

        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {

            }
        });
        MySingleton.getInstance(getApplicationContext()).addToRequestQueue(stringRequest);


    }

    public void readfile() {

        String sdcard = Environment.getExternalStorageDirectory() + "/ESurvey" + "/";
        File file = new File(sdcard, "EsurveySettings.txt");
        StringBuilder text = new StringBuilder();
        arrayList5.clear();
        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            String line;
            while ((line = br.readLine()) != null) {
                String[] lineWords = line.split(" ");
                Collections.addAll(arrayList5, lineWords);
            }
            br.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private void savedata(final String srv_id, String textv, String textv2, String textv3,
                          String textv4, String textv5, String textv6, String textv7,
                          String textv8, String textv9, String textv10, String textv11,
                          String textv12, String textv13, String textv14,
                          String textv15, String textv16,
                          String textv17, String textv18, String textv19,
                          String textv20, String textv21, String textv22) throws IOException {

        for (int i = 0; i < arrayList5.size(); i++) {
            if (arrayList5.indexOf(0) != 0) {
                tv = arrayList5.get(0);
                tv2 = arrayList5.get(1);
                tv3 = arrayList5.get(2);
                tv4 = arrayList5.get(3);
                tv5 = arrayList5.get(4);
                tv6 = arrayList5.get(5);
                tv7 = arrayList5.get(6);
                tv8 = arrayList5.get(7);
                i = i + 8;

            }
        }
        final String cell = tv3;
        final String SurveyorCode = tv5;
        final String Companycode = tv6;
        final String srvid = srv_id;
        final String Surveytaype = textv;
        final String NIC = textv3;
        final String Grower_code = textv4;
        final String Grower_name = textv5;
        final String father_name = textv6;
        final String Caste = textv7;
        final String circle = textv8;
        final String village = textv9;
        final String T_acreage = textv10;
        final String T_yield = textv11;
        final String Killa = textv12;
        final String Sqr_No = textv13;
        final String sowing_distance = textv14;
        final String crop_condition = textv15;
        final String variety = textv16;
        final String plantation = textv17;
        final String Note = textv18;
        final String imei = textv2;

        if (textv19 != null) {
            mfilename = textv19;
        } else {
            mfilename = "Nofile";

        }
        if (textv20 != null) {
            mfilename2 = textv20;
        } else {
            mfilename2 = "Nofile";

        }
        if (textv21 != null) {
            mfilename3 = textv21;
        } else {
            if (textv19 != null) {
                mfilename3 = textv19;
            } else {
                mfilename3 = "Nofile";
            }
        }
        if (textv22 != null) {
            mfilename4 = textv22;
        } else {
            if (textv20 != null) {
                mfilename4 = textv20;
            } else {
                mfilename4 = "Nofile";
            }
        }
        String url4 = AppController.baseUrl + AppController.URL2;
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url4,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                            db_helper.INSERT_FLAG(new Master("Yes", srvid));
                        Toast.makeText(getApplicationContext(), "Master data Seved sucessfully ...", Toast.LENGTH_SHORT).show();

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (volleyError.networkResponse == null) {
                            if (volleyError.getClass().equals(TimeoutError.class)) {
                                Toast.makeText(getApplicationContext(), "Oops. Network Timeout error!", Toast.LENGTH_LONG).show();
                            }
                        }
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put(AppController.KEY_survey_id, srvid);
                params.put(AppController.KEY_CompanyCode, Companycode);
                params.put(AppController.KEY_SurveyorCode, SurveyorCode);
                params.put(AppController.KEY_Survey_type, Surveytaype);
                params.put(AppController.KEY_Grower_code, Grower_code);
                params.put(AppController.KEY_KPI_CELLID, cell);
                params.put(AppController.KEY_file, mfilename);
                params.put(AppController.KEY_file2, mfilename2);
                params.put(AppController.KEY_file3, mfilename3);
                params.put(AppController.KEY_file4, mfilename4);
                params.put(AppController.KEY_IME, imei);
                params.put(AppController.KEY_NIC, NIC);
                params.put(AppController.KEY_Name, Grower_name);
                params.put(AppController.KEY_Father_name, father_name);
                params.put(AppController.KEY_Caste, Caste);
                params.put(AppController.KEY_Circle, circle);
                params.put(AppController.KEY_Village, village);
                params.put(AppController.KEY_Totale_Acreage, T_acreage);
                params.put(AppController.KEY_Total_yield, T_yield);
                params.put(AppController.KEY_Killa, Killa);
                params.put(AppController.KEY_Suqure_No, Sqr_No);
                params.put(AppController.KEY_Crop_Condition, crop_condition);
                params.put(AppController.KEY_Variety, variety);
                params.put(AppController.KEY_Plantation, plantation);
                params.put(AppController.KEY_Note, Note);
                params.put(AppController.KEY_sowing_distance, sowing_distance);

                return params;
            }

        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {

            }
        });
        AppController.getInstance().addToRequestQueue(stringRequest);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        if (application.handler != null) {
            application.handler.removeCallbacks(runnable);
        }
        super.onDestroy();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public void onStart(Intent intent, int startId) {
        super.onStart(intent, startId);
        Log.d(TAG, "FirstService started");
        //this.stopSelf();
    }


    public JSONObject getJSONUrl(String url1) throws IOException {
        URL url = new URL(url1);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        is = (InputStream) conn.getContent();
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(
                    is, StandardCharsets.ISO_8859_1), 8);
            StringBuilder sb = new StringBuilder();
            String line = null;
            while ((line = reader.readLine()) != null) {
                sb.append(line + "\n");
            }
            is.close();
            json = sb.toString();
        } catch (Exception e) {
            Log.e("Buffer Error", "Error converting result " + e);
        }

        // try parse the string to a JSON object
        try {
            jObj = new JSONObject(json);
        } catch (JSONException e) {
            Log.e("JSON Parser", "Error parsing data " + e);
        }

        // return JSON String
        return jObj;

    }

}