package com.example.shreefgroup.surevysystem.Ui.Activity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.util.Log;
import android.view.Window;
import android.widget.Toast;

import com.example.shreefgroup.surevysystem.BuildConfig;
import com.example.shreefgroup.surevysystem.R;
import com.example.shreefgroup.surevysystem.Utils.AppController;
import com.example.shreefgroup.surevysystem.Utils.Constants;
import com.example.shreefgroup.surevysystem.Utils.FileHelper_currntdata_backup;
import com.example.shreefgroup.surevysystem.Utils.NetworkUtil;
import com.google.android.gms.common.api.*;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResult;
import com.google.android.gms.location.LocationSettingsStatusCodes;
import com.nabinbhandari.android.permissions.PermissionHandler;
import com.nabinbhandari.android.permissions.Permissions;
import com.preference.PowerPreference;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;

import static com.example.shreefgroup.surevysystem.Ui.Activity.MapActivity.TAG;
import static com.example.shreefgroup.surevysystem.Ui.Activity.TakeSurveyActivity.json;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;


@SuppressLint({"NewApi", "CustomSplashScreen"})
public class SplashScreen extends AppCompatActivity implements ActivityCompat.OnRequestPermissionsResultCallback {
    public final static String fileName22 = "IMEI_NO";
   public final static String path = AppController.getInstance().path+ "/ESurvey" + "/";
    private static final int REQUEST_READ_PHONE_STATE = 0;
    private final int SPLASH_DISPLAY_LENGTH = 1500;
     String DeviceId= "0.0";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().requestFeature(Window.FEATURE_ACTION_BAR);

        setContentView(R.layout.activity_splash);



        String[] permissions = {
               Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.CAMERA,
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.INTERNET,
               Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.ACCESS_COARSE_LOCATION,
              /*  Manifest.permission.ACCESS_NETWORK_STATE,*/
              /*  Manifest.permission.INSTALL_PACKAGES*/

        };
        Permissions.check(this, permissions, null,null, new
                PermissionHandler() {
                    @Override
                    public void onGranted() {
                        // do your task.

                        CallScreen();
                  }
                });



      /*
        String pattern = "dd-MMM-yy";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
        currunt_date = simpleDateFormat.format(new Date());
        try {
            date = simpleDateFormat.parse(currunt_date);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        */

      /*  LocationManager locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);


        if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            Toast.makeText(this, "GPS is Enabled in your device", Toast.LENGTH_SHORT).show();
        }
        */


 /*       application = (AppController) getApplicationContext();
        try {
            new File(path).mkdir();
            file = new File(path + fileName22);
            if (!file.exists()) {
                file.createNewFile();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

        readfile_curruntdata();
        for (int i = 0; i < arrayIndex.size(); i++) {
            if (arrayIndex.indexOf(0) != 0) {
                indexid = arrayIndex.get(0).toString();

            }
        }
*/


    /*    if (indexid == null) {
            showDialog();
        }
        */

      /*  try {
            readfile_curruntdata();
            for (int i = 0; i < arrayIndex.size(); i++) {
                if (arrayIndex.indexOf(0) != 0) {
                    indexid = arrayIndex.get(0).toString();

                }
            }
            if (indexid != null) {
                date2 = simpleDateFormat.parse(indexid);
            }

        } catch (ParseException e) {
            e.printStackTrace();
        }


        if ((indexid != null) && (date2.compareTo(date) < 0)) {
            Toast.makeText(this, "Sorry! No access\n Only Authenticated user allowed here ", Toast.LENGTH_LONG).show();
            finish();
        } else {
            if (indexid != null) {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {

                        Intent intent = new Intent(SplashScreen.this, HomeActivity.class);
                        SplashScreen.this.startActivity(intent);
                        //  Toast.makeText(SplashScreen.this, "WELCOM TO E-SURVEY APP  ", Toast.LENGTH_LONG).show();
                        SplashScreen.this.finish();
                    }
                }, SPLASH_DISPLAY_LENGTH);
               }

        }*/

    }

    private void CallScreen() {

        new Handler().postDelayed(() -> {

            boolean setting = PowerPreference.getDefaultFile().getBoolean(Constants.SETTING_SCREEN,false);

            Intent intent;
            if(!setting){
                intent = new Intent(getApplicationContext(), SettingActivity.class);
            }else {
                intent = new Intent(getApplicationContext(), MainActivity.class);

            }
            startActivity(intent);
            finish();
        }, SPLASH_DISPLAY_LENGTH);




    }






    @Override
    protected void onStart() {
        super.onStart();

    }

    @Override
    protected void onResume() {
        super.onResume();

    }

    protected void onStop() {
        super.onStop();
        finish();


    }

    @Override
    protected void onPause() {
        super.onPause();


    }

    @Override
    protected void onDestroy() {
        super.onDestroy();


    }



}