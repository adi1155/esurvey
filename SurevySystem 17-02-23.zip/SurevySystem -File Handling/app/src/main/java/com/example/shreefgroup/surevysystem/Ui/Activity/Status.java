package com.example.shreefgroup.surevysystem.Ui.Activity;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.appcompat.widget.LinearLayoutCompat;

import com.example.shreefgroup.surevysystem.DataBase.DatabaseHelper;
import com.example.shreefgroup.surevysystem.Model.Master;
import com.example.shreefgroup.surevysystem.R;
import com.example.shreefgroup.surevysystem.Utils.AppController;

import java.util.ArrayList;
import java.util.List;


public class Status extends Activity implements AdapterView.OnItemSelectedListener {


    private AppController application;
    private DatabaseHelper db_helper;
    private CheckBox checkBox;
    TextView tv, qty;
    private ImageButton addBtn;
    private ImageButton minusBtn;
    private String order, party_id;
    ArrayList<String> array = new ArrayList<String>();
    ArrayList<String> array2 = new ArrayList<String>();
    private TextView SrNo;
    private TextView tv4;
    private String Tran_date;
    private String flag;
    private String date;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.importdata);
        application = (AppController) getApplicationContext();
        db_helper = new DatabaseHelper(this);
        init();

    }
    public void init() {
        TableLayout ll = (TableLayout) findViewById(R.id.table_main);
        ll.removeAllViews();
        List<Master> B = db_helper.getMaster();

        for (Master obj : B) {
            order = obj.get_father_name();
            flag=obj.get_flage();
            date=obj.get_mob_id();
            array.add(order);
            array.add(date);
            array.add(flag);
        }
        for (int i = 0; i < array.size(); i++) {
            TableRow row = new TableRow(this);
            row.setLayoutParams(new LinearLayoutCompat.LayoutParams(
                    RelativeLayout.LayoutParams.MATCH_PARENT,
                    RelativeLayout.LayoutParams.MATCH_PARENT));
          /*  SrNo = new TextView(getActivity());
            SrNo.setText(String.valueOf(i));
            SrNo.setTextColor(Color.WHITE);
            SrNo.setPadding(25, 5, 5, 5);*/
            tv = new TextView(this);
            tv4 = new TextView(this);
            qty = new TextView(this);
            tv.setText(String.valueOf(array.get(i)));
            tv.setTextColor(Color.WHITE);
            tv.setPadding(20, 5, 5, 5);
            tv.setGravity(Gravity.LEFT);
            tv4.setText(String.valueOf(array.get(i + 1)));
            tv4.setTextColor(Color.WHITE);
            tv4.setPadding(20, 5, 5, 5);
            if(array.get(i + 2)!=null) {
                if(array.get(i + 2).equals("Yes")){
                    qty.setText(String.valueOf(array.get(i + 2)));
                    qty.setTextColor(Color.GREEN);
                }else if(array.get(i + 2).equals("No")){
                    qty.setText(String.valueOf(array.get(i + 2)));
                    qty.setTextColor(Color.RED);
                }
            }
            qty.setPadding(150, 5, 0, 5);
            qty.setGravity(Gravity.RIGHT);
            row.addView(tv4);
            row.addView(tv);
            row.addView(qty);
            ll.addView(row);


            i = i + 2;
        }

    }


    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {


    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }


    @Override
    public void onResume() {
        super.onResume();


    }


}


