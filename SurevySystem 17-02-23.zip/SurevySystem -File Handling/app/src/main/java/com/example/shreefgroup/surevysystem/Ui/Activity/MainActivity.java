package com.example.shreefgroup.surevysystem.Ui.Activity;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.Menu;
import android.widget.TextView;

import com.example.shreefgroup.surevysystem.R;
import com.example.shreefgroup.surevysystem.Utils.Constants;
import com.example.shreefgroup.surevysystem.databinding.ActivityMain3Binding;
import com.google.android.material.navigation.NavigationView;
import com.preference.PowerPreference;

import androidx.annotation.NonNull;
import androidx.core.view.GravityCompat;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity  implements NavigationView.OnNavigationItemSelectedListener{

    private AppBarConfiguration mAppBarConfiguration;

    DrawerLayout drawer;
    NavigationView navigationView;
    public NavController navController;
    AlertDialog.Builder mBuilder ;
    AlertDialog mCustomDialog;
     ActivityMain3Binding binding ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMain3Binding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        drawer  = binding.drawerLayout;
        navigationView = binding.navView;

        View headerView = binding.navView.getHeaderView(0);

        String  userName = PowerPreference.getDefaultFile().getString(Constants.USER_NAME, "empty");
        TextView navUsername = headerView.findViewById(R.id.header_textView);
        navUsername.setText(userName);



        setSupportActionBar(binding.appBarMain.toolbar);

        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.nav_home, R.id.nav_gallery, R.id.nav_slideshow)
                .setOpenableLayout(drawer)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main2);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);

    }

    /*@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }*/

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main2);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }




    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main2);
        return NavigationUI.onNavDestinationSelected(item, navController)
                || super.onOptionsItemSelected(item);
    }


    @Override
    public void onBackPressed() {
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }



    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

        menuItem.setChecked(true);

        drawer.closeDrawers();

        int id = menuItem.getItemId();
        String user_id =  PowerPreference.getDefaultFile().getString(Constants.USER_ID,"empty");
        String unit_id  =  PowerPreference.getDefaultFile().getString(Constants.USER_UNIT);

        String baseUrl =      PowerPreference.getDefaultFile().getString(Constants.BASE_URL_NEW);
        String lp_code =      PowerPreference.getDefaultFile().getString(Constants.USER_LP_CODE);
        String deviceID  =     PowerPreference.getDefaultFile().getString(Constants.DEVICE_ID);



        switch (id) {

            case R.id.nav_home:
                navController.navigate(R.id.nav_home);
                break;
/*

            case R.id.nav_last_entry:
                navController.navigate(R.id.nav_last_entry);
                break;

            case R.id.nav_history:
                navController.navigate(R.id.nav_history);
                break;


            case R.id.nav_setting:
                //navController.navigate(R.id.nav_transaction);
                customDialog("1");

                break;

            case R.id.nav_logout:


                DatabaseAccess databaseAccess =  DatabaseAccess.getInstance(getApplicationContext());
                databaseAccess.open();
                if( databaseAccess.deleteUser(user_id)){
                    PowerPreference.clearAllData();
                    PowerPreference.clearAllDataAsync();
                    PowerPreference.getDefaultFile().setBoolean(Constants.SETTING_SCREEN, true);
                    PowerPreference.getDefaultFile().setString(Constants.USER_UNIT, unit_id);
                    PowerPreference.getDefaultFile().setString(Constants.BASE_URL_NEW, baseUrl);
                    PowerPreference.getDefaultFile().setString(Constants.USER_LP_CODE, lp_code);
                    PowerPreference.getDefaultFile().setString(Constants.DEVICE_ID, deviceID);

                    Intent intent = new Intent(MainActivity3.this, SplashScreen.class);
                    startActivity(intent);
                    finish();
                }

                break;


            case R.id.nav_transfer_lp:

                customDialog("2");
                break;

*/


        }
        return true;

    }

}