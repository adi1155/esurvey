package com.example.shreefgroup.surevysystem.DataBase;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.shreefgroup.surevysystem.Model.CircleModel.CircleResult;
import com.example.shreefgroup.surevysystem.Model.GPS;
import com.example.shreefgroup.surevysystem.Model.Grower.GrowerResult;
import com.example.shreefgroup.surevysystem.Model.Master;
import com.example.shreefgroup.surevysystem.Model.Sync.CropCondtion;
import com.example.shreefgroup.surevysystem.Model.Sync.CropVarrity;
import com.example.shreefgroup.surevysystem.Model.Sync.Plantation;
import com.example.shreefgroup.surevysystem.Model.Sync.SowingDistance;
import com.example.shreefgroup.surevysystem.Model.Sync.SurveyType;
import com.example.shreefgroup.surevysystem.Model.Sync.Village;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by ashfaq on 7/14/2017.
 */

public class DatabaseHelper extends DatabaseHandler {
    public static int count;


    public DatabaseHelper(Context context) {
        super(context);
    }

    public int update(Master S) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_Mob_id, S.get_mob_id());
        if (S.get_filename() != null) {
            values.put(KEY_FileName, S.get_filename());
        }
        if (S.get_filename2() != null) {
            values.put(KEY_FileName2, S.get_filename2());
        }
        if (S.get_filename3() != null) {
            values.put(KEY_FileName3, S.get_filename3());
        }
        if (S.get_filename4() != null) {
            values.put(KEY_FileName4, S.get_filename4());
        }
        return db.update(TABLE_Master, values, KEY_Mob_id + " LIKE ?",
                new String[]{String.valueOf(S.get_mob_id())});


    }



    public int upDateMapArea(String  S ,String mobId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_MAP_AREA, S);

          return db.update(TABLE_Master, values, KEY_Mob_id ,
                new String[]{String.valueOf(mobId)});


    }


    public void Insert_Master(Master S) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_Mob_id, S.get_mob_id());
        values.put(KEY_Survey_type, S.get_survey_type());
        values.put(KEY_CNIC, S.get_cnic());
        values.put(KEY_Grower_code, S.get_Grower_code());
        values.put(KEY_Grower_name, S.get_name());
        values.put(KEY_Father_name, S.get_father_name());
        values.put(KEY_CASTE, S.get_cast());
        values.put(KEY_CIRCLE, S.get_circle());
        values.put(KEY_VILLAGE, S.get_village());
        values.put(KEY_TOTAL_ACRAGE, S.get_acrage());
        values.put(KEY_TOTAL_YIELD, S.get_yield());
        values.put(KEY_Killa, S.get_killa());
        values.put(KEY_SQRNO, S.get_sqr_no());
        values.put(KEY_SOWING, S.get_sowing());
        values.put(KEY_CROP_COND, S.get_crop_cond());
        values.put(KEY_VERIETY, S.get_veriety());
        values.put(KEY_PLANTATION, S.get_plantation());
        values.put(KEY_NOTE, S.get_note());
        values.put(KEY_IMEI, S.get_imei());
        values.put(KEY_Flag, S.get_flage());
        values.put(KEY_MAP_AREA, S.getTotalArea());
        db.insert(TABLE_Master, null, values);
        db.close();
    }



    public void insertCircle(String circleName,String code) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_CIRCLE_NAME, circleName);
        values.put(KEY_CIRCLE_CODE, code);
        db.insert(TABLE_CIRCLE, null, values);
        db.close();
    }


    public void insertVillage(String circleName, String   villageName, String code) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_CIRCLE_NAME, circleName);
        values.put(KEY_VILLAGE_NAME, villageName);
        values.put(KEY_VILLAGE_CODE, code);
        db.insert(TABLE_VILLAGE, null, values);
        db.close();
    }


    public void insert_crop_condition(String name,  String code) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_CROP_NAME, name );
        values.put(KEY_CROP_DESC, code);
        db.insert(TABLE_CROP_CONDITION, null, values);
        db.close();
    }

public void insert_crop_varrity(String name,  String code) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_CROP_VARRITY_NAME, name );
        values.put(KEY_CROP_VARRITY_DESC, code);
        db.insert(TABLE_CROP_VARVITY, null, values);
        db.close();
    }

    public void insert_plantation(String name,  String code) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_PLANTATION_NAME, name);
        values.put(KEY_PLANTATION_DESC, code);
        db.insert(TABLE_PLANTATION, null, values);
        db.close();
    }


    public void insert_growerInfo(GrowerResult growerResult ) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_GROWER_NAME, growerResult.getGrowerName());
        values.put(KEY_GROWER_FATHER_NAME,growerResult.getGrowerFName());
        values.put(KEY_GROWER_CNIC,growerResult.getGrowerCnic());
        values.put(KEY_GROWER_CAST,growerResult.getGrowerCaste());
        values.put(KEY_GROWER_PASSBOOK_NO,growerResult.getPassbookNo());
        values.put(KEY_GROWER_VIlLAGE_CODE,growerResult.getVillageCode());
        values.put(KEY_GROWER_CIRCLE_CODE,growerResult.getCircleCode());
        values.put(KEY_GROWER_CODE,growerResult.getGrowerCode());
        values.put(KEY_GROWER_UNIT_CODE,growerResult.getUnitCode());
        values.put(KEY_GROWER_IMAGE,growerResult.getmFile());

        db.insert(TABLE_GROWER, null, values);
        db.close();

    }


    public void insert_survey_type(String name,  String code) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_SURVEY_NAME, name );
        values.put(KEY_SURVEY_DESC, code);
        db.insert(TABLE_SURVEY_TYPE, null, values);
        db.close();
    }


    public void insert_sowing(String name) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_SOWING_DISTANCE, name );

        db.insert(TABLE_SOWING, null, values);
        db.close();
    }




    public void Insert_gps(GPS S) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_Mob_id, S.get_mob_id());
        values.put(KEY_Latitude, S.get_Lat());
        values.put(KEY_Longitude, S.get_lang());
        values.put(KEY_IMEI, S.get_imei());
        values.put(KEY_No, S.get_serial());
        values.put(KEY_TRAN_DATE, S.get_Tran_date());
        values.put(KEY_Flag, S.get_flage());
        db.insert(TABLE_GPS, null, values);
        db.close();
    }


    public int getItemsCount() {

        String selectQuery = "SELECT * FROM " + TABLE_Master + " WHERE " + KEY_Flag + "  Like '%" + "No" + "%'";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        count = cursor.getCount();
        cursor.close();
        return count;
    }





    public List<SowingDistance> get_sowing_list() {
        List<SowingDistance> list = new ArrayList<>();
        String selectQuery = "SELECT * FROM " + TABLE_SOWING;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            do {
                SowingDistance sowingDistance = new SowingDistance();
                String name = cursor.getString(1);
                sowingDistance.setSowingDistance(name);

                list.add(sowingDistance);
            } while (cursor.moveToNext());
        }

        return list;

    }

    public List<CircleResult> get_circle_List() {
        List<CircleResult> list = new ArrayList<>();
        String selectQuery = "SELECT * FROM " + TABLE_CIRCLE;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            do {
                CircleResult circleResult = new CircleResult();
                String name = cursor.getString(1);
                String code = cursor.getString(2);
                circleResult.setDescription(name);
                circleResult.setLookupCode(code);

                list.add(circleResult);
            } while (cursor.moveToNext());
        }

        return list;

    }


    public List<GrowerResult> get_grower_info() {

        List<GrowerResult> list = new ArrayList<>();
        String selectQuery = "SELECT * FROM  "+TABLE_GROWER+" "  ;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            do {
                GrowerResult growerResult = new GrowerResult();

                growerResult.setGrowerName(cursor.getString(1));
                growerResult.setGrowerFName(cursor.getString(2));
                growerResult.setGrowerCnic(cursor.getString(3));
                growerResult.setGrowerCaste(cursor.getString(4));
                growerResult.setGrowerCode(cursor.getString(5));
                growerResult.setVillageCode(cursor.getString(6));
                growerResult.setCircleCode(cursor.getString(7));
                growerResult.setPassbookNo(cursor.getString(8));
                growerResult.setUnitCode(cursor.getString(9));
                growerResult.setmFile(cursor.getString(10));


                list.add(growerResult);
            } while (cursor.moveToNext());
        }

        return list;

    }


    public GrowerResult get_grower_info(String cnic) {

        GrowerResult growerResult = new GrowerResult();
        String selectQuery = "SELECT * FROM  "+TABLE_GROWER+"  WHERE "+ KEY_GROWER_CNIC+" = "+cnic+""  ;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            do {

                growerResult.setGrowerName(cursor.getString(1));
                growerResult.setGrowerFName(cursor.getString(2));
                growerResult.setGrowerCnic(cursor.getString(3));
                growerResult.setGrowerCaste(cursor.getString(4));
                growerResult.setGrowerCode(cursor.getString(5));
                growerResult.setVillageCode(cursor.getString(6));
                growerResult.setCircleCode(cursor.getString(7));
                growerResult.setPassbookNo(cursor.getString(8));



            } while (cursor.moveToNext());
        }

        return growerResult;

    }

    public List<Village> get_village_List(String circleName) {

        List<Village> list = new ArrayList<Village>();
        String selectQuery = "SELECT * FROM " + TABLE_VILLAGE + " WHERE "+ KEY_CIRCLE_NAME +"  Like'%" +circleName + "%'" ;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                Village village = new Village();
                village.setDescription(cursor.getString(1));
                village.setLookupCode(cursor.getString(2));
                village.setCircle(cursor.getString(3));
                list.add(village);
            } while (cursor.moveToNext());
        }

        return list;

    }


    public List<Village> get_village_List() {

        List<Village> list = new ArrayList<Village>();
        String selectQuery = "SELECT * FROM " + TABLE_VILLAGE  ;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                Village village = new Village();
                village.setDescription(cursor.getString(1));
                village.setLookupCode(cursor.getString(2));
                list.add(village);
            } while (cursor.moveToNext());
        }

        return list;

    }


    public List<CropCondtion> get_crop_List() {

        List<CropCondtion> list = new ArrayList<CropCondtion>();
        String selectQuery = "SELECT * FROM " + TABLE_CROP_CONDITION  ;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            do {
                CropCondtion cropCondtion = new CropCondtion();
                cropCondtion.setDescription(cursor.getString(1));
                cropCondtion.setLookupCode(cursor.getString(2));
                list.add(cropCondtion);
            } while (cursor.moveToNext());
        }

        return list;

    }


 public List<CropVarrity> get_crop_varrvity_List() {

        List<CropVarrity> list = new ArrayList<CropVarrity>();
        String selectQuery = "SELECT * FROM " + TABLE_CROP_VARVITY ;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            do {
                CropVarrity cropVarrity = new CropVarrity();
                cropVarrity.setDescription(cursor.getString(1));
                cropVarrity.setLookupCode(cursor.getString(2));
                list.add(cropVarrity);
            } while (cursor.moveToNext());
        }

        return list;

    }



    public List<Plantation> get_plantation_List() {

        List<Plantation> list = new ArrayList<>();
        String selectQuery = "SELECT * FROM " + TABLE_PLANTATION ;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            do {
                Plantation plantation = new Plantation();
                plantation.setDescription(cursor.getString(1));
                plantation.setLookupCode(cursor.getString(2));
                list.add(plantation);
            } while (cursor.moveToNext());
        }

        return list;

    }
    public List<SurveyType> get_survey_type_List() {

        List<SurveyType> list = new ArrayList<>();
        String selectQuery = "SELECT * FROM " + TABLE_SURVEY_TYPE ;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            do {
                SurveyType surveyType = new SurveyType();
                surveyType.setDescription(cursor.getString(1));
                surveyType.setLookupCode(cursor.getString(2));
                list.add(surveyType);
            } while (cursor.moveToNext());
        }

        return list;

    }




    public int Count_ITEM_LIST() {

        String countQuery = "SELECT  * FROM " + TABLE_GPS + " WHERE " + KEY_Flag + "  Like '%" + "No" + "%'";
        ;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        count = cursor.getCount();
        cursor.close();
        return count;
    }

    public void deleteAlldata() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("delete from " + TABLE_Master);
        db.execSQL("delete from " + TABLE_GPS);
        db.close();

    }

    public void delete_Sync_data() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("delete from " + TABLE_VILLAGE);
        db.execSQL("delete from " + TABLE_CIRCLE);
        db.execSQL("delete from " + TABLE_CROP_VARVITY);
        db.execSQL("delete from " + TABLE_CROP_CONDITION);
        db.execSQL("delete from " + TABLE_PLANTATION);
        db.execSQL("delete from " + TABLE_SURVEY_TYPE);
        db.close();

    }
    public void delete_all_grower() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("delete from " + TABLE_GROWER);
        db.close();

    }

    public List<Master> getAllMaster(String mob_id) {
        List<Master> PartyList = new ArrayList<Master>();
        String selectQuery = "SELECT * FROM " + TABLE_Master + " WHERE " + KEY_Mob_id + "  Like '%" + mob_id + "%'";
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            do {
                Master p = new Master();
                p.set_mob_id(cursor.getString(1));
                p.set_suvey_type(cursor.getString(2));
                p.setCNIC(cursor.getString(3));
                p.set_code(cursor.getString(4));
                p.set_Name(cursor.getString(5));
                p.set_Fathername(cursor.getString(6));
                p.set_caste(cursor.getString(7));
                p.set_circle(cursor.getString(8));
                p.set_Village(cursor.getString(9));
                p.set_acrage(cursor.getString(10));
                p.set_yield(cursor.getString(11));
                p.set_killa(cursor.getString(12));
                p.set_sqrno(cursor.getString(13));
                p.set_swing(cursor.getString(14));
                p.set_crop(cursor.getString(15));
                p.set_veriety(cursor.getString(16));
                p.set_Plantation(cursor.getString(17));
                p.set_Note(cursor.getString(18));
                p.set_imei(cursor.getString(19));
                p.set_filename(cursor.getString(20));
                p.set_filename2(cursor.getString(21));
                p.set_filename3(cursor.getString(22));
                p.set_filename4(cursor.getString(23));
                PartyList.add(p);
            } while (cursor.moveToNext());
        }

        return PartyList;
    }

    public List<Master> getAll_Master() {
        List<Master> PartyList = new ArrayList<Master>();
        String selectQuery = "SELECT * FROM " + TABLE_Master + " WHERE " + KEY_Flag + "  Like '%" + "No" + "%'";
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            do {
                Master p = new Master();
                p.set_mob_id(cursor.getString(1));
                p.set_suvey_type(cursor.getString(2));
                p.setCNIC(cursor.getString(3));
                p.set_code(cursor.getString(4));
                p.set_Name(cursor.getString(5));
                p.set_Fathername(cursor.getString(6));
                p.set_caste(cursor.getString(7));
                p.set_circle(cursor.getString(8));
                p.set_Village(cursor.getString(9));
                p.set_acrage(cursor.getString(10));
                p.set_yield(cursor.getString(11));
                p.set_killa(cursor.getString(12));
                p.set_sqrno(cursor.getString(13));
                p.set_swing(cursor.getString(14));
                p.set_crop(cursor.getString(15));
                p.set_veriety(cursor.getString(16));
                p.set_Plantation(cursor.getString(17));
                p.set_Note(cursor.getString(18));
                p.set_imei(cursor.getString(19));
                p.set_filename(cursor.getString(20));
                p.set_filename2(cursor.getString(21));
                p.set_filename3(cursor.getString(22));
                p.set_filename4(cursor.getString(23));
                p.setTotalArea(cursor.getString(25));
                PartyList.add(p);
            } while (cursor.moveToNext());
        }

        return PartyList;
    }

    public List<Master> getMaster() {
        List<Master> PartyList = new ArrayList<Master>();
        String selectQuery = "SELECT * FROM " + TABLE_Master +" ORDER BY "+KEY_Flag+" ASC ";//
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            do {
                Master p = new Master();
                p.set_mob_id(cursor.getString(1));
                p.set_suvey_type(cursor.getString(2));
                p.setCNIC(cursor.getString(3));
                p.set_code(cursor.getString(4));
                p.set_Name(cursor.getString(5));
                p.set_Fathername(cursor.getString(6));
                p.set_caste(cursor.getString(7));
                p.set_circle(cursor.getString(8));
                p.set_Village(cursor.getString(9));
                p.set_acrage(cursor.getString(10));
                p.set_yield(cursor.getString(11));
                p.set_killa(cursor.getString(12));
                p.set_sqrno(cursor.getString(13));
                p.set_swing(cursor.getString(14));
                p.set_crop(cursor.getString(15));
                p.set_veriety(cursor.getString(16));
                p.set_Plantation(cursor.getString(17));
                p.set_Note(cursor.getString(18));
                p.set_imei(cursor.getString(19));
                p.set_filename(cursor.getString(20));
                p.set_filename2(cursor.getString(21));
                p.set_filename3(cursor.getString(22));
                p.set_filename4(cursor.getString(23));
                p.set_flage(cursor.getString(24));
                PartyList.add(p);
            } while (cursor.moveToNext());
        }

        return PartyList;
    }

    public List<GPS> getAllGPS(String mob_id) {
        List<GPS> P = new ArrayList<GPS>();
        String selectQuery = "SELECT * FROM " + TABLE_GPS + " WHERE " + KEY_Mob_id + "  Like '%" + mob_id + "%'";
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            do {
                GPS p = new GPS();
                p.set_mob_id(cursor.getString(1));
                p.set_Lat(cursor.getString(2));
                p.set_lang(cursor.getString(3));
                p.set_imei(cursor.getString(4));
                p.set_Tran_date(cursor.getString(5));
                p.set_serila(cursor.getString(6));

                P.add(p);
            } while (cursor.moveToNext());
        }

        return P;
    }

    public List<GPS> getMob_id() {
        List<GPS> P = new ArrayList<GPS>();
        String selectQuery = "SELECT " + KEY_Mob_id + " FROM " + TABLE_GPS + " WHERE " + KEY_Flag + "  Like '%No%'";
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            do {
                GPS p = new GPS();
                p.set_mob_id(cursor.getString(1));
                p.set_Lat(cursor.getString(2));
                p.set_lang(cursor.getString(3));
                p.set_imei(cursor.getString(4));
                p.set_Tran_date(cursor.getString(5));
                p.set_serila(cursor.getString(6));

                P.add(p);
            } while (cursor.moveToNext());
        }

        return P;
    }

    public List<GPS> get_AllGPS() {
        List<GPS> P = new ArrayList<GPS>();
        String selectQuery = "SELECT  * FROM " + TABLE_GPS + " WHERE " + KEY_Flag + "  Like '%" + "No" + "%'";
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            do {
                GPS p = new GPS();
                p.set_mob_id(cursor.getString(1));
                p.set_Lat(cursor.getString(2));
                p.set_lang(cursor.getString(3));
                p.set_imei(cursor.getString(4));
                p.set_Tran_date(cursor.getString(5));
                p.set_serila(cursor.getString(6));

                P.add(p);
            } while (cursor.moveToNext());
        }

        return P;
    }

    public int INSERT_FLAG(Master S) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_Flag, S.get_flage());
        return db.update(TABLE_Master, values, KEY_Mob_id + " LIKE ?",
                new String[]{String.valueOf(S.get_mob_id())});
    }


    public void INSERT_TOTAL_AREA(String mobId, String total_area) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_MAP_AREA, total_area);
        db.update(TABLE_Master, values, KEY_Mob_id + " LIKE ?",
                new String[]{String.valueOf(mobId)});
    }

    public int INSERT_FLAG2(GPS S) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_Flag, S.get_flage());
        return db.update(TABLE_GPS, values, KEY_Mob_id + " LIKE ? AND " + KEY_No + " LIKE ?",
                new String[]{String.valueOf(S.get_mob_id().toString()), String.valueOf(S.get_serial().toString())});


    }


    public void deleteRow(int value) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DELETE FROM " + TABLE_Master + " WHERE " + KEY_Mob_id + "='" + value + "'");
        db.close();
    }

}
