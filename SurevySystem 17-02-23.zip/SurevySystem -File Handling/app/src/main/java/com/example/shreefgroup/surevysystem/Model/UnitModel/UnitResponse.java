
package com.example.shreefgroup.surevysystem.Model.UnitModel;

import java.io.Serializable;
import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class UnitResponse    implements Serializable  {

    @SerializedName("Result")
    @Expose
    private List<UnitResult> result = null;
    @SerializedName("status")
    @Expose
    private String status;

    public List<UnitResult> getResult() {
        return result;
    }

    public void setResult(List<UnitResult> result) {
        this.result = result;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

}
