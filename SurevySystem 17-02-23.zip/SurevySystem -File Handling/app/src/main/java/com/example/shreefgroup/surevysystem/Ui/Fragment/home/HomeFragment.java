package com.example.shreefgroup.surevysystem.Ui.Fragment.home;


import static android.content.Context.LOCATION_SERVICE;
import static com.google.android.gms.location.LocationRequest.PRIORITY_HIGH_ACCURACY;

import android.Manifest;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import android.content.IntentFilter;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;


import com.example.shreefgroup.surevysystem.InterFace.LocationManagerInterface;
import com.example.shreefgroup.surevysystem.Model.CircleModel.CircleResult;
import com.example.shreefgroup.surevysystem.Model.Sync.SowingDistance;
import com.example.shreefgroup.surevysystem.Service.GPSTracker;
import com.example.shreefgroup.surevysystem.Ui.Activity.GrowerActivity;

import com.example.shreefgroup.surevysystem.DataBase.DatabaseHelper;
import com.example.shreefgroup.surevysystem.Model.CheckSurvey;
import com.example.shreefgroup.surevysystem.Model.Grower.GrowerModel;
import com.example.shreefgroup.surevysystem.Model.Grower.GrowerResult;
import com.example.shreefgroup.surevysystem.Model.Sync.CropCondtion;
import com.example.shreefgroup.surevysystem.Model.Sync.CropVarrity;
import com.example.shreefgroup.surevysystem.Model.Sync.Plantation;
import com.example.shreefgroup.surevysystem.Model.Sync.SurveyType;
import com.example.shreefgroup.surevysystem.Model.Sync.SyncModel;
import com.example.shreefgroup.surevysystem.Model.Sync.Village;
import com.example.shreefgroup.surevysystem.Network.ServerCallback;
import com.example.shreefgroup.surevysystem.Network.ServerError;
import com.example.shreefgroup.surevysystem.Network.ServerTask;
import com.example.shreefgroup.surevysystem.R;
import com.example.shreefgroup.surevysystem.Service.GpsUtils;
import com.example.shreefgroup.surevysystem.Ui.Activity.TakeSurveyActivity;
import com.example.shreefgroup.surevysystem.Utils.Constants;
import com.example.shreefgroup.surevysystem.Utils.NetworkUtil;
import com.example.shreefgroup.surevysystem.Utils.SmartLocationManager;
import com.example.shreefgroup.surevysystem.databinding.FragmentHomeBinding;

import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResult;
import com.google.android.gms.location.LocationSettingsStatusCodes;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.isapanah.awesomespinner.AwesomeSpinner;
import com.preference.PowerPreference;


import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Timer;
import java.util.TimerTask;

import fr.quentinklein.slt.LocationTracker;
import fr.quentinklein.slt.ProviderError;
import retrofit2.Call;


public class HomeFragment extends Fragment  {

    private FragmentHomeBinding binding;
    DatabaseHelper db_helper;
    protected static final int REQUEST_CHECK_SETTINGS = 0x1;

    public static double LAT = 0.0, LNG = 0.0;
    public GPSTracker gps;

    public LocationTracker locationTracker;



    private BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        // we will receive data updates in onReceive method.
        @Override
        public void onReceive(Context context, Intent intent) {
            // Get extra data included in the Intent
            String message = intent.getStringExtra("message");
            // on below line we are updating the data in our text view.
            binding.userNoticeBoard.setText(message);
        }
    };


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();


        locationTracker = new LocationTracker(
                1000L,
                1f,
                true,
                true,
                true);

        if (ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_COARSE_LOCATION);
        }
        locationTracker.startListening(getContext());

        locationTracker.addListener(new LocationTracker.Listener() {
            @Override
            public void onLocationFound(@NonNull Location location) {

                Log.d("new_value",location.toString());
              //  Toast.makeText(getContext(),"loaction"+location.toString(),Toast.LENGTH_LONG).show();
                LAT = location.getLatitude();
                LNG = location.getLongitude();
                binding.userNoticeBoard.setText(getCompleteAddressString(LAT,LNG,getContext()));
            }

            @Override
            public void onProviderError(@NonNull ProviderError providerError) {

            }
        });


/*

        LocationManager locationManager = (LocationManager) requireContext().getSystemService(LOCATION_SERVICE);
        assert locationManager != null;
        locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);

*/


      /*
            mLocationManager = new SmartLocationManager
                    (getContext(),
                            getActivity(),
                            this,
                            SmartLocationManager.ALL_PROVIDERS,
                            PRIORITY_HIGH_ACCURACY,
                            10 * 1000,
                            1000,
                            SmartLocationManager.LOCATION_PROVIDER_RESTRICTION_NONE
                    );
*/



       /*  gps = new GPSTracker(getContext());

        LocalBroadcastManager.getInstance(getContext()).registerReceiver(broadcastReceiver, new IntentFilter("custom-action-local-broadcast"));


        Timer myTimer = new Timer();
        myTimer.schedule(new TimerTask()
        {
            @Override
            public void run()
            {
                if(gps.canGetLocation()) {
                    Log.d("yahoo","yahoo");
                    LAT = gps.getLatitude();
                    LNG = gps.getLongitude();
                    String add = getCompleteAddressString(LAT, LNG, getContext());


                    Intent intent = new Intent("custom-action-local-broadcast");
                    intent.putExtra("message", add);
                    LocalBroadcastManager.getInstance(getContext()).sendBroadcast(intent);
                   // binding.userNoticeBoard.setText(add);
                }else {
                    gps.showSettingsAlert();
                }
            }

        }, 0, 8000);*/



        db_helper = new DatabaseHelper(getContext());

        binding.homeSyncView.setOnClickListener(view -> {

            if(NetworkUtil.isNetworkAvailable(getContext())) {
                SyncData();
                SyncGrower(getContext());
            }else {
                Toast.makeText(getContext(), "No InterNet Available", Toast.LENGTH_SHORT).show();
            }

        });

        binding.homeNewGrower.setOnClickListener(view ->
                startActivity(new Intent(getContext(), GrowerActivity.class))
        );

        binding.homeNewSurvey.setOnClickListener(view -> {

            if(LAT!= 0.0 && LNG != 0.0) {
                
                viewpopUp();

            //    check_survey(String.valueOf(LAT), String.valueOf(LNG));
            }
        });






        return root;
    }

    private void viewpopUp() {



        final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(getContext());
        bottomSheetDialog.setContentView(R.layout.check_survey_type);

        Button cancle = bottomSheetDialog.findViewById(R.id.pop_cancle);
        Button submit = bottomSheetDialog.findViewById(R.id.pop_submit);
        AwesomeSpinner spinner = bottomSheetDialog.findViewById(R.id.pop_spinner);

        DatabaseHelper databaseHelper = new DatabaseHelper(getContext());
        List<SurveyType> surveyTypeList = databaseHelper.get_survey_type_List();
        List<String> categories = new ArrayList<String>();


        for(int  i = 0 ; i<surveyTypeList.size(); i++) {
            categories.add(surveyTypeList.get(i).getDescription());
        }

        ArrayAdapter<String> categoriesAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_item, categories);
        Objects.requireNonNull(spinner).setAdapter(categoriesAdapter);


        spinner.setOnSpinnerItemClickListener((position, itemAtPosition) -> {

            try {
                String  survey_type = surveyTypeList.get(position).getDescription();


            }catch (Exception e){e.printStackTrace();}
        });


        assert cancle != null;
        cancle.setOnClickListener(v -> bottomSheetDialog.dismiss());

        assert submit != null;
        submit.setOnClickListener(v -> {

            if(NetworkUtil.isNetworkAvailable(getContext())){

                try {
                    String type = spinner.getSelectedItem().toString();
                    Constants.SURVEY_TYPE = type;

                    if (LAT != 0.0 && LNG != 0.0 && !type.equals("")) {
                        check_survey(String.valueOf(LAT), String.valueOf(LNG), type,bottomSheetDialog);
                    } else {
                        Toast.makeText(getContext(), "LAT, LNG is null", Toast.LENGTH_SHORT).show();
                    }
                }catch (Exception e){e.printStackTrace();}
            }else{
                Toast.makeText(getContext(), "No Internet Connection Available", Toast.LENGTH_SHORT).show();

            }
        });






        bottomSheetDialog.show();



    }

    private void SyncData(){

        final ProgressDialog pDialog = new ProgressDialog(getContext());
        pDialog.setMessage("Data Sync...");
        pDialog.setCancelable(false);
        pDialog.show();
                String unit_id = PowerPreference.getDefaultFile().getString(Constants.USER_UNIT,"");
        Call<SyncModel> getAPIData = ServerTask.getInstance().getServices().sync_data(unit_id,"6","9","10","7","8");


        getAPIData.enqueue(new ServerCallback<>() {
            @Override
            public void onFailure(ServerError restError) {
                pDialog.dismiss();
            }

            @Override
            public void onSuccess(retrofit2.Response<SyncModel> response) {

            }

            @Override
            public void onResponse(retrofit2.Response<SyncModel> response) {
                 pDialog.dismiss();

                try {

                    assert response.body() != null;
                    String status = response.body().getStatus();


                    if (status.equals("true")) {

                         db_helper.delete_Sync_data();

                         List<CropCondtion> cropCondtion = response.body().getResult().getCropCondtion();
                         List<Village> village = response.body().getResult().getVillage();
                         List<CropVarrity> cropVarrities = response.body().getResult().getCropVarrity();
                         List<Plantation> plantation = response.body().getResult().getPlantation();
                         List<SurveyType> surveyType = response.body().getResult().getSurveyTypes();
                         List<CircleResult> circleList = response.body().getResult().getCircles();
                         List<SowingDistance> sowingDistances = response.body().getResult().getSowingDistance();

                         for( int i =0; i< village.size(); i++){
                             String circle_name = village.get(i).getCircle();
                             String desc = village.get(i).getDescription();
                             String lookupCode  = village.get(i).getLookupCode();

                              db_helper.insertVillage(circle_name,desc,lookupCode);

                         }


                        for( int i =0; i< circleList.size(); i++){
                            String desc = circleList.get(i).getDescription();
                            String lookupCode  = circleList.get(i).getLookupCode();

                            db_helper.insertCircle(desc,lookupCode);

                        }





                        for( int i =0; i< cropCondtion.size(); i++){
                            String desc = cropCondtion.get(i).getDescription();
                            String lookupCode  = cropCondtion.get(i).getLookupCode();
                            db_helper.insert_crop_condition(desc,lookupCode);

                        }

                        for( int i =0; i< cropVarrities.size(); i++){
                            String desc = cropVarrities.get(i).getDescription();
                            String lookupCode  = cropVarrities.get(i).getLookupCode();
                            db_helper.insert_crop_varrity(desc,lookupCode);

                        }

                        for( int i =0; i< plantation.size(); i++){
                            String desc = plantation.get(i).getDescription();
                            String lookupCode  = plantation.get(i).getLookupCode();
                            db_helper.insert_plantation(desc,lookupCode);

                        }

                        for( int i =0; i < surveyType.size(); i++){
                            String desc = surveyType.get(i).getDescription();
                            String lookupCode  = surveyType.get(i).getLookupCode();
                            db_helper.insert_survey_type(desc,lookupCode);

                        }


                        for( int i =0; i < sowingDistances.size(); i++){
                            String desc = sowingDistances.get(i).getSowingDistance();
                            db_helper.insert_sowing(desc);

                        }


                          alertDialog("Data Sync Successfully");


                    } else {
                        Toast.makeText(getContext(), "NO Data Found", Toast.LENGTH_SHORT).show();
                    }

                } catch (Exception e) {
                    Toast.makeText(getContext(), "No crash  Found", Toast.LENGTH_SHORT).show();
                    e.printStackTrace();
                }
            }
        });
    }




    public static void SyncGrower(Context context){



                String unit_id = PowerPreference.getDefaultFile().getString(Constants.USER_UNIT,"");
        Call<GrowerModel> getAPIData = ServerTask.getInstance().getServices().get_grower_info(unit_id);


        getAPIData.enqueue(new ServerCallback<>() {
            @Override
            public void onFailure(ServerError restError) {

            }

            @Override
            public void onSuccess(retrofit2.Response<GrowerModel> response) {

            }

            @Override
            public void onResponse(retrofit2.Response<GrowerModel> response) {

                try {

                    assert response.body() != null;
                    String status = response.body().getStatus();


                    if (status.equals("true")) {

                        DatabaseHelper db_helper = new DatabaseHelper(context);
                         db_helper.delete_all_grower();


                         List<GrowerResult> growerResults =  response.body().getGrowerResult();


                        for( int i =0; i < growerResults.size(); i++){
                            GrowerResult result = growerResults.get(i);
                            db_helper.insert_growerInfo(result);

                        }



                    } else {
                        Toast.makeText(context, "NO Grower data Found", Toast.LENGTH_SHORT).show();
                    }

                } catch (Exception e) {
                    Toast.makeText(context, "No crash  Found", Toast.LENGTH_SHORT).show();
                    e.printStackTrace();
                }
            }
        });
    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }


    private void alertDialog(String msg) {

        try {
            AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
            builder.setTitle("Survey ")
                    .setMessage(msg)
                    .setCancelable(false)
                    .setPositiveButton("OKEY", (dialog, id) -> {

                    });
            AlertDialog alert = builder.create();
            alert.show();
        }catch (Exception e){e.printStackTrace();}
    }

    public static void turnGPSOn(Context context) {
        GpsUtils gpsUtils = new GpsUtils(context);
        gpsUtils.turnGPSOn(isGPSEnable -> {
            if (!isGPSEnable) {
                Toast.makeText(context, "location is OFF", Toast.LENGTH_SHORT).show();

            }
        });


    }

    @Override
    public void onStart() {
        super.onStart();
        turnGPSOn(getContext());

    }






    public static String getCompleteAddressString(double LATITUDE, double LONGITUDE, Context context) {
        String strAdd = "";

        try {
            Geocoder geocoder = new Geocoder(context, Locale.getDefault());
            List<Address> addresses = geocoder.getFromLocation(LATITUDE, LONGITUDE, 1);
            if (addresses != null) {
                Address returnedAddress = addresses.get(0);
                StringBuilder strReturnedAddress = new StringBuilder("");

                for (int i = 0; i <= returnedAddress.getMaxAddressLineIndex(); i++) {
                    strReturnedAddress.append(returnedAddress.getAddressLine(i)).append("\n");
                }
                strAdd = strReturnedAddress.toString();
                Log.d("address", strReturnedAddress.toString());
            } else {
                Log.d("address", "No Address returned!");
            }
        } catch (Exception e) {
            e.printStackTrace();
            Log.d("address", "Canont get Address!");
        }
        return strAdd;
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        binding = null;

    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();

    }



    private void check_survey(String lat, String lng, String type, BottomSheetDialog bottomSheetDialog) {


        if(NetworkUtil.isNetworkAvailable(getContext())) {

            final ProgressDialog pDialog = new ProgressDialog(getContext());
            pDialog.setMessage("Checking Survey ...");
            pDialog.setCancelable(false);
            pDialog.show();

            Call<CheckSurvey> data =  ServerTask.getInstance().getServices().check_survey1(lat,lng,type);

            data.enqueue(new com.example.shreefgroup.surevysystem.Network.ServerCallback<CheckSurvey>() {
                @Override
                public void onFailure(ServerError restError) {
                   pDialog.dismiss();
                   bottomSheetDialog.dismiss();
                }

                @Override
                public void onSuccess(retrofit2.Response<CheckSurvey> response) {

                }

                @Override
                public void onResponse(retrofit2.Response<CheckSurvey> response) {

                    pDialog.dismiss();
                    bottomSheetDialog.dismiss();

                    String status  = response.body().getStatus();


                    if(status.equals("false")){

                        Constants.SURVEY_TYPE = type;

                        Intent  intent  = new Intent(getContext(),TakeSurveyActivity.class);
                         startActivity(intent);


                    }else {


                    String  surveyResult = response.body().getSurveyResult().getPolyResult();

                    if(surveyResult.equals("true")){
                        Toast.makeText(getContext(),"your current Location survey is  Already done ",Toast.LENGTH_LONG).show();

                    }else if(surveyResult.equals("false")) {
                        startActivity(new Intent(getContext(), TakeSurveyActivity.class));

                    }
               }
         }

            });


        }else {
            Toast.makeText(getContext(), "You do not have internet for  Send request ", Toast.LENGTH_SHORT).show();
        }
    }












}