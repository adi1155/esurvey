
package com.example.shreefgroup.surevysystem.Model.Sync;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class CropCondtion {

    @SerializedName("LOOKUP_CODE")
    @Expose
    private String lookupCode;
    @SerializedName("DESCRIPTION")
    @Expose
    private String description;

    public String getLookupCode() {
        return lookupCode;
    }

    public void setLookupCode(String lookupCode) {
        this.lookupCode = lookupCode;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

}
