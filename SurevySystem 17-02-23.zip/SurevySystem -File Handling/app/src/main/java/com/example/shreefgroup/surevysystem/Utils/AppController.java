package com.example.shreefgroup.surevysystem.Utils;

/**
 * Created by ashfaq on 11/14/2016.
 */

import android.annotation.SuppressLint;
import android.app.Application;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Environment;
import android.os.Handler;
import android.provider.Settings;
import android.text.TextUtils;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.Volley;

import java.util.ArrayList;
import java.util.LinkedList;


public class AppController extends Application {
    public Handler handler;
    public java.lang.Runnable runnable;
    public int globle_flag=0;
    public int position=0;
    public static final String TAG = AppController.class.getSimpleName();
    public static final String KEY_CompanyCode="COMPANY_CODE";
    public static final String KEY_SurveyorCode="Surveyor_Code";
    public static final String KEY_IME = "IMEI";
    public static final String KEY_IMEI_NO = "IMEI_NO";
    public static final String KEY_KPI_CELLID = "CELL_ID";
    public static final  String KEY_file="FILENAME";
    public static final  String KEY_file2="FILENAME2";
    public static final  String KEY_file3="FILENAME3";
    public static final  String KEY_file4="FILENAME4";
    public static final String KEY_LAT = "gps_latitude";
    public static final String KEY_LNG = "gps_longitude";
    public static final String KEY_Survey_type = "Survey_type";
    public static final String KEY_NIC= "CNIC_NO";
    public static final String KEY_Grower_code= "Grower_code";
    public static final String KEY_Name= "Grower_Name";
    public static final String KEY_Father_name= "Father_name";
    public static final String KEY_Caste= "Caste";
    public static final String KEY_Circle= "CIRCLE_NAME";
    public static final String KEY_Village= "VILLAGE_NAME";
    public static final String KEY_Totale_Acreage = "Total_Acr";
    public static final String KEY_Total_yield= "Total_yield";
    public static final String KEY_Killa = "Killa";
    public static final String KEY_Suqure_No = "Square_No";
    public static final String KEY_Crop_Condition = "Crop_Condition";
    public static final String KEY_Variety = "Variety";
    public static final String KEY_Plantation = "Plantation";
    public static final String KEY_Note = "Note";
    public static final String KEY_MPP_AERA_MOB = "MAP_AREA_MOB";
    public static String baseUrl ="http://scorpio.sgroup.pk:8085";
    public static String port = "";

    public static final String get_circle = "/servey_system/circle_view.php";
    public static final String get_village = "/servey_system/viewVillage.php";
    public static final String get_cropcond = "/servey_system/CROPCONDITION.php";
    public static final String get_variety = "/servey_system/viewVariety.php";
    public static final String get_plantation = "/servey_system/viewPlantation.php";
    public static final String strURLUpload = "/servey_system/upload.php";
    public static final String strUrlServer = "/servey_system/upload.php";
    public static final String GetCircleCode = "/servey_system/GetCircleCode.php";
    public static final String GetVillageCode= "/servey_system/GetVillageCode.php";
    public static final String URL2 =  "/Esurvey_22.1/Save_NewSurveydata.php";
    public static final String GetGps=  "/Esurvey_22.1/GetGps.php";
    public static final String GrowerInfo = "/Esurvey_22.1/getGrowerInfo.php";
    public static final String survey_id =   "/servey_system/check_survey_id.php";
    public static final String get_survey_info= "/servey_system/view_survey_info.php";
    public static final String detail = "/servey_system/Grower_detail_information.php";
    public static final String gps = "/servey_system/Get_Gps_by_Survey_id.php";
    public static final String IMEI =  "/servey_system/IMEI_NO.PHP";
    public static final String IMEI_NEW =  "/servey_system/IMEI_NO_REGISTER.PHP";
    public static final String DELETE_LIST_ITEM = "/servey_system/DELETE_REG.php";
    public static final String getsurvey_responce =  "/servey_system/GET_REGNO.php";
    public static final String get_sowing_distance =  "/servey_system/get_sowing_distance.php";


    private static AppController mInstance;
    public static String KEY_survey_id="SURVEY_ID";
    public static String KEY_sowing_distance="SOWING_DISTANCE";
    public static String KEY_distance="MAP_AREA";
    public static String KEY_id="GPS_SERIAL";
    public static String KEY_serialno="SERIAL_NO";
    public static String KEY_date="TRAN_DATE";

    int counter=1;
    int cc=0;

    public static  ArrayList<String> arrayList_variety= new ArrayList<String>();
    public static ArrayList<String> arrayList_plantation= new ArrayList<String>();
    public static  ArrayList<String> myArraylist = new ArrayList<String>();
    public static   ArrayList<String> arrayList5 = new ArrayList<String>();
    public static   ArrayList<String> arrayListVillage = new ArrayList<String>();
    private RequestQueue mRequestQueue;
    public String tv1="";
    public String tv2="";
    public String tv3="";
    public String tv4="";
    public String tv5="";
    public String tv6="";
    private ImageLoader mImageLoader;
    public String circlecode;
    public String villagecode;
    public String  circle_code="";
    public String  village_code="";
    public int save_id;
    public static LinkedList<String> arraydetail=new LinkedList<String>();
    public String lat="";
    public String lng="";
    public String SurveyId="";
    public String SURVEY_ID="";
  //  public static String path  = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM)+ "";
    public static String path  = Environment.getExternalStorageDirectory().toString()+ "";

    public static synchronized AppController getInstance() {
        return mInstance;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        mInstance = this;
    }

    public RequestQueue getRequestQueue() {
        if (mRequestQueue == null) {
            mRequestQueue = Volley.newRequestQueue(getApplicationContext());
        }

        return mRequestQueue;
    }


    public <T> void addToRequestQueue(Request<T> req, String tag) {
        req.setTag(TextUtils.isEmpty(tag) ? TAG : tag);
        getRequestQueue().add(req);
    }

    public <T> void addToRequestQueue(Request<T> req) {
        req.setTag(TAG);
        getRequestQueue().add(req);
    }

    public void cancelPendingRequests(Object tag) {
        if (mRequestQueue != null) {
            mRequestQueue.cancelAll(tag);
        }
    }

    public void myArraylist(String ss) {
        myArraylist.add(ss);
    }

    public void arrayList5(String singleWord) {
        myArraylist.add(singleWord);
    }


    public void SurveyId(String survey_id) {
    }



    @SuppressLint("HardwareIds")
    public static  String getUuid(Context g){
       return Settings.Secure.getString(g.getContentResolver(), Settings.Secure.ANDROID_ID);
    }

}