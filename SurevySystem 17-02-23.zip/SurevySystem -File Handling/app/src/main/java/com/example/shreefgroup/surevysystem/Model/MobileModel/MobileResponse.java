package com.example.shreefgroup.surevysystem.Model.MobileModel;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class MobileResponse {

    @SerializedName("Result")
    @Expose
    private List<MobileResult> result = null;
    @SerializedName("status")
    @Expose
    private String status;

    public List<MobileResult> getResult() {
        return result;
    }

    public void setResult(List<MobileResult> result) {
        this.result = result;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

}