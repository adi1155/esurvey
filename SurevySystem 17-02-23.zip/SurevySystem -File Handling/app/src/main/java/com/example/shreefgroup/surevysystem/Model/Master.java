package com.example.shreefgroup.surevysystem.Model;


public class Master {
    int _id;
    String _mob_id;
    String _flage;
    String _CNIC;
    String _Code;
    String _Name;
    String _Fathername;
    String _survey_type;
    String _Village;
    String _circle;
    String _acrage;
    String _killa;
    String _swing;
    int _searialno;
    String _plantation;
    String _veriety;
    String _note;
    String _caste;
    String _sqrno;
    String _yield;
    String _imei;
    String _crop_cond;
    String totalArea;
    private String _filename;
    private String _filename2;
    private String _filename3;
    private String _filename4;
public Master(){

}
public Master(String flag,String mob_id){
    this._flage=flag;
    this._mob_id=mob_id;
}

    public Master(int count, String mob_id, String _filename) {
        this._id = count;
        this._mob_id = mob_id;
        if (this._id == 1) {
            this._filename = _filename;
        }
        if (this._id == 2) {
            this._filename2 = _filename;

        }
        if (this._id == 3) {
            this._filename3 = _filename;

        }
        if (this._id == 4) {
            this._filename4 = _filename;

        }
    }

    public Master(String mob_id,
                  String _survey_type,
                  String _CNIC,
                  String _code,
                  String _Name,
                  String _Fathername,
                  String _caste,
                  String _circle,
                  String _Village,
                  String _acrage,
                  String _yield,
                  String _killa,
                  String _sqrno,
                  String _swing,
                  String _crop_cond,
                  String _veriety,
                  String _plantation,
                  String _note,
                  String Deviceid,
                  String flag,
                  String totalArea

                  ) {

        this._mob_id = mob_id;
        this._survey_type = _survey_type;
        this._CNIC = _CNIC;
        this._Code = _code;
        this._Name = _Name;
        this._Fathername = _Fathername;
        this._caste = _caste;
        this._circle = _circle;
        this._Village = _Village;
        this._acrage = _acrage;
        this._yield = _yield;
        this._killa = _killa;
        this._sqrno = _sqrno;
        this._swing = _swing;
        this._crop_cond = _crop_cond;
        this._veriety = _veriety;
        this._plantation = _plantation;
        this._note = _note;
        this._imei =Deviceid;
        this._flage =flag;
        this.totalArea =totalArea;


    }

    public String getTotalArea() {
        return totalArea;
    }

    public void setTotalArea(String totalArea) {
        this.totalArea = totalArea;
    }

    public int get_ID() {
        return this._id;
    }

    public void setID(int id) {
        this._id = id;
    }

    public void set_searialno(int srno) {
        this._id = srno;
    }

    public void set_flage(String _flage) {
         this._flage=_flage;
    }

    public int get_serial() {
        return this._searialno;
    }

    public String get_mob_id() {
        return this._mob_id;
    }

    public void set_mob_id(String id) {
        this._mob_id = id;
    }

    public String get_survey_type() {
        return this._survey_type;
    }

    public String get_imei() {
        return this._imei;
    }

    public String get_cnic() {
        return this._CNIC;
    }

    public String get_Grower_code() {
        return this._Code;
    }

    public String get_name() {
        return this._Name;
    }

    public String get_father_name() {
        return this._Fathername;
    }

    public String get_cast() {
        return this._caste;
    }

    public String get_circle() {
        return this._circle;
    }

    public void set_circle(String circle) {
        this._circle = circle;
    }

    public String get_village() {
        return this._Village;
    }

    public String get_acrage() {
        return this._acrage;
    }

    public void set_acrage(String acrage) {
        this._acrage = acrage;
    }

    public String get_yield() {
        return this._yield;
    }

    public void set_yield(String yield) {
        this._yield = yield;
    }

    public String get_killa() {
        return this._killa;
    }

    public String get_sqr_no() {
        return this._sqrno;
    }

    public String get_sowing() {
        return this._swing;
    }

    public String get_crop_cond() {
        return this._crop_cond;
    }

    public String get_veriety() {
        return this._veriety;
    }

    public String get_plantation() {
        return this._plantation;
    }

    public String get_note() {
        return this._note;
    }

    public String get_flage() {
        return this._flage;
    }

    public void set_suvey_type(String suvey_type) {
        this._survey_type = suvey_type;
    }

    public void setCNIC(String CNIC) {
        this._CNIC = CNIC;
    }

    public void set_Name(String _Name) {
        this._Name = _Name;
    }

    public void set_Fathername(String fathername) {
        this._Fathername = fathername;
    }

    public void set_caste(String caste) {
        this._caste = caste;
    }

    public void set_sqrno(String sqrno) {
        this._sqrno = sqrno;
    }

    public void set_swing(String swing) {
        this._swing = swing;
    }

    public void set_Village(String village) {
        this._Village = village;
    }

    public String get_filename() {
        return this._filename;
    }

    public String get_filename2() {
        return this._filename2;
    }

    public String get_filename3() {
        return this._filename3;
    }

    public String get_filename4() {
        return this._filename4;
    }

    public void set_killa(String _killa) {
        this._killa = _killa;
    }

    public void set_crop(String _crop) {
        this._crop_cond = _crop;
    }

    public void set_veriety(String _veriety) {
        this._veriety = _veriety;
    }

    public void set_Plantation(String _Plantation) {
        this._plantation = _Plantation;
    }

    public void set_Note(String _Note) {
        this._note = _Note;
    }

    public void set_code(String code) {
        this._Code = code;
    }

    public void set_imei(String _imei) {
        this._imei = _imei;
    }

    public void set_filename(String filename) {
        this._filename = filename;
    }

    public void set_filename2(String filename2) {
        this._filename2 = filename2;
    }

    public void set_filename3(String filename3) {
        this._filename3 = filename3;
    }

    public void set_filename4(String filename4) {
        this._filename4 = filename4;
    }
}