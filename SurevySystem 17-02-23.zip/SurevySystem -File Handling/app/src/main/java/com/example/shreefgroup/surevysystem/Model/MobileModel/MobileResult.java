package com.example.shreefgroup.surevysystem.Model.MobileModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class MobileResult {



    @SerializedName("DEVICE_ID")
    @Expose
    private String deviceId;
    @SerializedName("MOBILE_MODEL")
    @Expose
    private String mobileModel;

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public String getMobileModel() {
        return mobileModel;
    }

    public void setMobileModel(String mobileModel) {
        this.mobileModel = mobileModel;
    }

}
