
package com.example.shreefgroup.surevysystem.Model.Sync;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class SyncModel {

    @SerializedName("Result")
    @Expose
    private SyncResult result;
    @SerializedName("status")
    @Expose
    private String status;

    public SyncResult getResult() {
        return result;
    }

    public void setResult(SyncResult result) {
        this.result = result;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

}
