package com.example.shreefgroup.surevysystem.Model.Sync;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class SowingDistance {

    @SerializedName("SOWING_DISTANCE")
    @Expose
    private String sowingDistance;

    public String getSowingDistance() {
        return sowingDistance;
    }

    public void setSowingDistance(String sowingDistance) {
        this.sowingDistance = sowingDistance;
    }
}