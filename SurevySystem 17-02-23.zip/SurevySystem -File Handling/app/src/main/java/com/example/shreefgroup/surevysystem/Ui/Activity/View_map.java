package com.example.shreefgroup.surevysystem.Ui.Activity;

import static com.example.shreefgroup.surevysystem.Utils.AppController.TAG;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.example.shreefgroup.surevysystem.R;
import com.example.shreefgroup.surevysystem.Utils.AppController;
import com.example.shreefgroup.surevysystem.Utils.FileHelper_GrowerDetaile;
import com.example.shreefgroup.surevysystem.Utils.FileHelper_Survey_id;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

public abstract class View_map extends AppCompatActivity {
    final static String fileSID = "SURVEY_ID";
    final static String fileName = "Grower_Name";
    final static String path = AppController.getInstance().path+ "/ESurvey" + "/";
    static AppController application;
    public String TYPE;
    public String NAME;
    public String CODE;
    public String FATER_NAME;
    public String CASTE;
    public String VILLAGE;
    public String CIRCLE;
    public String YIELD;
    public String ACR;
    public String SQUARE;
    public String KILLA;
    public String VARIETY;
    public String CR_COND;
    public String PLANTATION;
    public String GROWER_NAME;
    ArrayList<String> arraylist = new ArrayList<String>();
    ArrayList<String> array_listName = new ArrayList<String>();
    private String grower_name;
    private ListView list1;
    private String S_id;
    private String CNIC_NO;
    public  JSONObject jObj;

    public String ReadFile_GrowerName(Context context) {
        String line = null;
        array_listName.clear();
        try {
            FileInputStream fileInputStream = new FileInputStream(new File(path + fileName));
            InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream);
            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
            StringBuilder stringBuilder = new StringBuilder();

            while ((line = bufferedReader.readLine()) != null) {
                array_listName.add(line);
                stringBuilder.append(line + System.getProperty("line.separator"));

            }
            fileInputStream.close();
            line = stringBuilder.toString();

            bufferedReader.close();
        } catch (FileNotFoundException ex) {
            Log.d(TAG, ex.getMessage());
        } catch (IOException ex) {
            Log.d(TAG, ex.getMessage());
        }
        return line;
    }

    public void clearFile() throws IOException {
        FileWriter fwOb = new FileWriter(GrowerDetail_Info.path + GrowerDetail_Info.file_growerdetail, false);
        PrintWriter pwOb = new PrintWriter(fwOb, false);
        pwOb.flush();
        pwOb.close();
        fwOb.close();
    }

    public void clearfile_Survey_id() throws IOException {
        FileWriter fwOb = new FileWriter(path + fileSID, false);
        PrintWriter pwOb = new PrintWriter(fwOb, false);
        pwOb.flush();
        pwOb.close();
        fwOb.close();
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_survey);
        if (android.os.Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }
        application = (AppController) getApplicationContext();
        TelephonyManager telephonyManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
        //DeviceId = telephonyManager.getDeviceId();
        ReadFile_GrowerName(this);
        list1 = (ListView) findViewById(R.id.sp1);
        final ArrayAdapter adapt = new ArrayAdapter<String>(this, R.layout.spinlist2, R.id.name,  array_listName);
        list1.setAdapter(adapt);
        list1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @TargetApi(Build.VERSION_CODES.M)
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                grower_name = parent.getItemAtPosition(position).toString();
                try {
                    get_grower_detail_info(grower_name);
                } catch (JSONException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                Intent I = new Intent(View_map.this, GrowerDetail_Info.class);
                startActivity(I);
            }


        });
    }

    private void get_grower_detail_info(String value) throws JSONException, IOException {
        clearfile_Survey_id();
        clearFile();
        String url = application.baseUrl + application.detail + "?GROWER_NAME=" + URLEncoder.encode(value, "UTF-8");
        try {
            JSONObject object = new JSONObject(String.valueOf((getJSONUrl(url))));
            JSONArray Jarray = object.getJSONArray("Result");
            for (int i = 0; i < Jarray.length(); i++) {
                JSONObject jsonObject = Jarray.getJSONObject(i);
                TYPE = jsonObject.getString("SURVEY_TYPE");
                CODE = jsonObject.getString("GROWER_CODE");
                CNIC_NO = jsonObject.getString("CNIC_NO");
                NAME = jsonObject.getString("GROWER_NAME");
                FATER_NAME = jsonObject.getString("FATHER_NAME");
                CASTE = jsonObject.getString("CASTE");
                VILLAGE = jsonObject.getString("VILLAGE_NAME");
                CIRCLE = jsonObject.getString("CIRCLE_NAME");
                ACR = jsonObject.getString("TOTAL_ACR");
                YIELD = jsonObject.getString("TOTAL_YIELD");
                KILLA = jsonObject.getString("KILLA");
                SQUARE = jsonObject.getString("SQUARE_NO");
                CR_COND = jsonObject.getString("CROP_CONDITION");
                VARIETY = jsonObject.getString("VARIETY");
                PLANTATION = jsonObject.getString("PLANTATION");
                S_id = jsonObject.getString("SURVEY_ID");
                if (FileHelper_Survey_id.saveToFile(S_id.toString())) {
                }
                if (FileHelper_GrowerDetaile.saveToFile(TYPE.toString())) {
                }
                if (FileHelper_GrowerDetaile.saveToFile(CODE.toString())) {

                }
                if (FileHelper_GrowerDetaile.saveToFile(CNIC_NO.toString())) {
                }
                if (FileHelper_GrowerDetaile.saveToFile(NAME.toString())) {
                }
                if (FileHelper_GrowerDetaile.saveToFile(FATER_NAME.toString())) {
                }
                if (FileHelper_GrowerDetaile.saveToFile(CASTE.toString())) {
                }
                if (FileHelper_GrowerDetaile.saveToFile(VILLAGE.toString())) {
                }
                if (FileHelper_GrowerDetaile.saveToFile(CIRCLE.toString())) {
                }
                if (FileHelper_GrowerDetaile.saveToFile(ACR.toString())) {
                }
                if (FileHelper_GrowerDetaile.saveToFile(YIELD.toString())) {
                }
                if (FileHelper_GrowerDetaile.saveToFile(VARIETY.toString())) {
                }
                if (FileHelper_GrowerDetaile.saveToFile(SQUARE.toString())) {
                }
                if (FileHelper_GrowerDetaile.saveToFile(CR_COND.toString())) {
                }
                if (FileHelper_GrowerDetaile.saveToFile(PLANTATION.toString())) {
                }


            }
        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    public JSONObject getJSONUrl(String url1) throws IOException {
        URL url = new URL(url1);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        InputStream is = (InputStream) conn.getContent();
        String json ="";
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(
                    is, "iso-8859-1"), 8);
            StringBuilder sb = new StringBuilder();
            String line = null;

            while ((line = reader.readLine()) != null) {
                sb.append(line + "\n");

            }

            is.close();
             json = sb.toString();

        } catch (Exception e) {
            Log.e("Buffer Error", "Error converting result " + e.toString());
        }

        try {
            jObj = new JSONObject(json);
        } catch (JSONException e) {
            Log.e("JSON Parser", "Error parsing data " + e.toString());


        }

        // return JSON String
        return jObj;

    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    public void arrayListGROWER_NAME(String GROWER_NAME) {
        arraylist.add(GROWER_NAME);
    }


}

