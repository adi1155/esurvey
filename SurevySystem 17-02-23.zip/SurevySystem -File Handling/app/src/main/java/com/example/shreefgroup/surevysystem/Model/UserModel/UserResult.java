package com.example.shreefgroup.surevysystem.Model.UserModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class UserResult   implements Serializable {

    @SerializedName("USER_ID")
    @Expose
    private String userId;
    @SerializedName("USER_LOGIN")
    @Expose
    private String userLogin;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserLogin() {
        return userLogin;
    }

    public void setUserLogin(String userLogin) {
        this.userLogin = userLogin;
    }


}
